SET echo OFF

REM ============================================================================
REM SET varaible with the database UserName.
REM ============================================================================

SET termout OFF
DEFINE dbName = '&1';
PROMPT Used the user name: &dbName
SET termout ON

REM ============================================================================
REM Grant privileges to the user (&dbName).
REM 	Where dbName is a name of db which was used during installation of MN.
REM ============================================================================

ALTER USER &dbName QUOTA UNLIMITED ON SYSTEM;
ALTER USER &dbName QUOTA UNLIMITED ON SYSAUX;
GRANT CREATE SESSION TO &dbName;
GRANT CREATE TABLE TO &dbName;
GRANT CREATE TABLESPACE TO &dbName;
GRANT UNLIMITED TABLESPACE TO &dbName;
GRANT SELECT_CATALOG_ROLE TO &dbName;
GRANT EXECUTE_CATALOG_ROLE TO &dbName;
GRANT CREATE SEQUENCE TO &dbName;
GRANT DBA TO &dbName;
GRANT EXECUTE on DBMS_CDC_PUBLISH TO &dbName;
EXECUTE DBMS_STREAMS_AUTH.GRANT_ADMIN_PRIVILEGE(GRANTEE => '&dbName');

BEGIN

	DBMS_CDC_PUBLISH.CREATE_CHANGE_SET(
    change_set_name => 'NETMETER_SET',
    description => 'Change set for NetMeter',
    change_source_name => 'HOTLOG_SOURCE',
    stop_on_ddl => 'n',
    begin_date => sysdate,
    end_date => NULL);

	DBMS_CDC_PUBLISH.ALTER_CHANGE_SET(
		change_set_name => 'NETMETER_SET',
		enable_capture => 'y');

END;
/
COMMIT;

SELECT CAPTURE_ENABLED FROM ALL_CHANGE_SETS WHERE SET_NAME='NETMETER_SET';

show errors;
EXIT