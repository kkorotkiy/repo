SET echo OFF

REM ============================================================================
REM Set the database initialization parameters.
REM ============================================================================

ALTER SYSTEM SET JAVA_POOL_SIZE=50000000 SCOPE=spfile;
ALTER SYSTEM SET JOB_QUEUE_PROCESSES=2 SCOPE=spfile;
ALTER SYSTEM SET PARALLEL_MAX_SERVERS=9 SCOPE=spfile;
ALTER SYSTEM SET PROCESSES=1007 SCOPE=spfile;
ALTER SYSTEM SET SESSIONS=2 SCOPE=spfile;
ALTER SYSTEM SET STREAMS_POOL_SIZE=71m SCOPE=spfile;
ALTER SYSTEM SET UNDO_RETENTION=3600 SCOPE=spfile;
ALTER SYSTEM SET GLOBAL_NAMES=TRUE SCOPE=spfile;

REM ============================================================================
REM Alter the database and enable the ArchiveLog.
REM ============================================================================

SHUTDOWN immediate;
STARTUP mount;
ALTER DATABASE archivelog;
ALTER DATABASE OPEN;
ALTER SYSTEM SWITCH logfile;
ALTER DATABASE FORCE LOGGING;
ALTER DATABASE ADD SUPPLEMENTAL LOG DATA;

ARCHIVE LOG LIST

SHOW ERRORS;
EXIT