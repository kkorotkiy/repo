USE [NetMeter]
GO
/* set 32 bit IDs with 10 digit values */
UPDATE [dbo].[t_current_id]
SET id_current = 1000000000
WHERE (id_current < 1000000000)
GO
/* set 64 bit IDs with 19 digit values */
UPDATE [dbo].[t_current_long_id]
SET id_current = 1000000000000000000
WHERE (id_current < 1000000000000000000)
GO
