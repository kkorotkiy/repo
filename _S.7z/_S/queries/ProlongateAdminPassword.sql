USE [NetMeter]
GO
DECLARE
    @now AS DATETIME,
    @user_name AS NVARCHAR(255),
    @user_nameSpace AS NVARCHAR(40)
    ;
SELECT
    @now = GETUTCDATE(),
    @user_name = 'Admin',
    @user_nameSpace = 'system_user'
    ;
UPDATE [dbo].[t_user_credentials]
SET [dt_expire] = DATEADD(MONTH, 4, @now),
    [dt_last_login] = @now,
    [dt_last_logout] = DATEADD(SECOND, 4, @now),
    [num_failures_since_login] = 0
WHERE (([nm_login] = @user_name)
    AND ([nm_space] = @user_nameSpace)
);
INSERT INTO [dbo].[t_user_credentials_history] (
    [nm_login],
    [nm_space],
    [tx_password],
    [tt_end]
) SELECT
    uc.[nm_login],
    uc.[nm_space],
    uc.[tx_password],
    uc.[dt_last_login]
FROM [dbo].[t_user_credentials] AS uc
WHERE ((uc.[nm_login] = @user_name)
    AND ([nm_space] = @user_nameSpace)
);
GO
