<#
.SYNOPSIS
Replace a temporary parameters in templates.

.DESCRIPTION
Replace a temporary parameters in templates.

This script requires to set a new parameters like HostName for Oracle server.

You can run this script from an old-style cmd.exe prompt using the
following:

powershell.exe -ExecutionPolicy Unrestricted -File "%filePathTmp%\ReplaceHostName.ps1" 
	"%filePathTmp%\ntp.conf.template" "%servHosName%" "%filePathTmp%\ntp.conf"

.PARAMETER inputFileName
Name of the template file which need to change.

.PARAMETER oldValue and newValue
Name of the parameter which will be replaced.

.PARAMETER outputFileName
Name of the new file after replacing. It's optional parameter.
In case outputFile parameter is empty, the initial file will be rewritten with new values.
#>
PARAM(
	[Parameter(Position=0, Mandatory=$true)]
	[string]$inputFileName,
	[Parameter(Position=1, Mandatory=$false)]
	[string]$outputFileName,
	[Parameter(Position=2, Mandatory=$true)]
	[string]$oldValue,
	[Parameter(Position=3, Mandatory=$true)]
	[string]$newValue
)

#### ToDo: add logic to define of outputFileName parameter (is it empty or not)
Get-Content $inputFileName | ForEach-Object { $_ -replace $oldValue, $newValue } | Set-Content $outputFileName
