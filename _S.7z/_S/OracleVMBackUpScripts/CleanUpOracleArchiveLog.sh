#!/bin/sh
 rm /u01/app/oracle/product/11.2.0/dbhome_1/dbs/arch*
