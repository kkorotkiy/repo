#!/bin/bash
#This script run every 2 seconds

while (sleep 2 && ntpdate -u NTPSERVERIP) &
do
  wait $!
done
