﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetraTech.TestSystem.Interaction;
using MetraTech.TestComponents;
using MetraTech.TestComponents.MetraNet;
using MetraTech.WebComponents.WebForms;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class SubscribeAccount : MetraNetTestSuite
    {
        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies ability of subscribing a Corporate account to a product offering, i.e. add subscription to the account.")]
        public void SubscribeCorporateAccountTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpSubscribe");
            var corpAccDisplayName = AccountManager.FormatDisplayName(corpAcc);

            var poName = "Subscribe and Unsubscribe Charges PO - Localized";
            var poStartDate = @Today(addDays: 5);

            var mainPage = WebSite.LogInAsAdmin();
            var subscriptionsFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: corpAcc.UserName,
                        dropdownValue: corpAccDisplayName
                    ).NavigateAccountToolbarToFrame(
                        "Subscriptions",
                        "Subscriptions"
                    );
            var subscriptionCreatedFrame =
                AddSubscription(
                    subscriptionsFrame,
                    poName,
                    poStartDate
                    );
            ValidateSubscription(
                subscriptionCreatedFrame,
                subscriptionsFrame,
                poName,
                poStartDate
                );            
            //====- BEGIN: ADD UDRC SUBSCRIPTION -========

            var udrcPoName = "UDRC_60M3_DailyAdvTapNoProPart_PO";
            var udrcPoStartDate = @Today(addDays: 14);
            var udrcPiName = "UDRC_60M3_DailyAdvTapNoProPart";

            subscriptionCreatedFrame =
                AddUdrcSubscription(
                    subscriptionsFrame,
                    udrcPoName,
                    udrcPoStartDate,
                    udrcPiName
                    );
            ValidateSubscription(
                subscriptionCreatedFrame,
                subscriptionsFrame,
                udrcPoName,
                udrcPoStartDate
                );
            //====- END: ADD UDRC SUBSCRIPTION -========
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies ability of subscribing a Department account to a product offering, i.e. add subscription to the account.")]
        public void SubscribeDepartmentAccountTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpDepSubscribe");
            var depAcc = AccountManager.AddNewAccount("DepartmentAccount.xml", userNamePrefix: "depSubscribe", ancestor:corpAcc);
            var depAccDisplayName = AccountManager.FormatDisplayName(depAcc);

            var poName = "GROUP_USAGE_Simple_PO display name";
            var poStartDate = @Today(addDays: 8);

            var mainPage = WebSite.LogInAsAdmin();
            var subscriptionsFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: depAcc.UserName,
                        dropdownValue: depAccDisplayName
                    ).NavigateAccountToolbarToFrame(
                        "Subscriptions",
                        "Subscriptions"
                    );
            var subscriptionCreatedFrame =
                AddSubscription(
                    subscriptionsFrame,
                    poName,
                    poStartDate
                    );
            ValidateSubscription(
                subscriptionCreatedFrame,
                subscriptionsFrame,
                poName,
                poStartDate
                );
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies ability of subscribing a CoreSubscriber account to a product offering., i.e. add subscription to the account.")]
        public void SubscribeCoreSubscriberAccountTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpSubAccSubscribe");
            var depAcc = AccountManager.AddNewAccount("DepartmentAccount.xml", userNamePrefix: "depSubAccSubscribe", ancestor: corpAcc);
            var subscrAcc = AccountManager.AddNewAccount("SubscriberAccount.xml", userNamePrefix: "subSubscribe", ancestor: depAcc);
            var subscrAccDisplayName = AccountManager.FormatDisplayName(subscrAcc);

            var poName = "Localized Audio Conference Product Offering USD";
            var poStartDate = @Today(addDays: 11);

            var mainPage = WebSite.LogInAsAdmin();
            var subscriptionsFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: subscrAcc.UserName,
                        dropdownValue: subscrAccDisplayName
                    ).NavigateAccountToolbarToFrame(
                        "Subscriptions",
                        "Subscriptions"
                    );
            var subscriptionCreatedFrame =
                AddSubscription(
                    subscriptionsFrame,
                    poName,
                    poStartDate
                    );
            ValidateSubscription(
                subscriptionCreatedFrame,
                subscriptionsFrame,
                poName,
                poStartDate
                );
            WebSite.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private static WebForm
            AddSubscription(
                WebForm subscriptionsFrame,
                string poName,
                string startDate
            ) {
            var subscriptionDetailsFrame =
                SelectProductOffering(
                    subscriptionsFrame,
                    poName
                    );
            PopulateSubscriptionDetails(
                subscriptionDetailsFrame,
                poName,
                startDate
                );

            var subscriptionCreatedFrame =
                subscriptionDetailsFrame.
                    Page().GetFrame("Subscription Created Successfully");

            return subscriptionCreatedFrame;
        }

        private static WebForm
            SelectProductOffering(
                WebForm subscriptionsFrame,
                string poName
            ) {
            var subscribeToProductOfferingFrame =
                subscriptionsFrame.
                    ExpandForm(mt.DataPane, "Subscriptions").
                    Click(_.Button, "Add Subscription").
                    Page().GetFrame("Subscribe to Product Offering");

            var selectProductOfferingDataPane =
                subscribeToProductOfferingFrame.
                    ExpandForm(mt.DataPane, "Select Product Offering");

            var subscriptionDetailsFrame =
                selectProductOfferingDataPane.
                    SelectSingleGridRow(Cell("Product Offering Name", poName)).
                    Click(_.Button, "OK").
                    Page().GetFrame("Subscription Details");

            return subscriptionDetailsFrame;
        }

        private static void
            PopulateSubscriptionDetails(
                WebForm subscriptionDetailsFrame,
                string poName,
                string startDate,
                string endDate = null
            ) {
            subscriptionDetailsFrame.
                GetForm(mt.DataPane, "Details").
                ValidateTextFieldValue(caption: "Subscription", expectedValue: poName).
                EnterTextBoxValue(caption: "Start Date", value: startDate).
                EnterTextBoxValue(caption: "End Date", value: endDate);

            subscriptionDetailsFrame.Click(_.Button, "OK");
        }

        private WebForm
            AddUdrcSubscription(
                WebForm subscriptionsFrame,
                string poName,
                string startDate,
                string piName
            ) {
            var udrcValueStartDate = @Today(addDays: 16);
            var udrcValueEndDate = @Today(addDays: 64);

            var subscriptionDetailsFrame =
                SelectProductOffering(
                    subscriptionsFrame,
                    poName
                    );
            PopulateSubscriptionDetails(
                subscriptionDetailsFrame,
                poName,
                startDate
                );

            var setUdrcValuesFrame =
                subscriptionDetailsFrame.
                    Page().GetFrame("Set Unit Dependent Recurring Charge Values");

            AddUnitDependentRecurringChargeValue(
                setUdrcValuesFrame,
                piName,
                value: 1.00M
                );
            AddUnitDependentRecurringChargeValue(
                setUdrcValuesFrame,
                piName,
                value: 10.00M,
                startDate: udrcValueStartDate,
                endDate: udrcValueEndDate
                );

            var subscriptionCreatedFrame =
                setUdrcValuesFrame.
                    WaitLoad().
                    Click(_.Button, "OK").
                    Page().GetFrame("Subscription Created Successfully");

            return subscriptionCreatedFrame;
        }

        private static void
            AddUnitDependentRecurringChargeValue(
                WebForm setUdrcValuesFrame,
                string piName,
                decimal value,
                string startDate = null,
                string endDate = null
            ) {
            setUdrcValuesFrame.
                GetForm(mt.Menu, piName).
                Click(_.Button, "Add");

            var addValueDialogCaption = ("Add "+piName);
            var addValueDialog =
                setUdrcValuesFrame.
                    GetForm(mt.Dialog, addValueDialogCaption);

            addValueDialog.
                ValidateTextBoxValue(control: mt.TextBox_1, caption: "Name", expectedValue: piName).
                EnterTextBoxValue(control: mt.TextBox_1, caption: "Start Date", value: startDate).
                EnterTextBoxValue(control: mt.TextBox_1, caption: "End Date", value: endDate).
                EnterComboBoxValue(control: mt.TextBox_1, caption: "Value", value: value, mode: DataInputMode.Enter).
                DisposeByClick(_.Button, "OK");
        }


        private static void
            ValidateSubscription(
                WebForm subscriptionCreatedFrame,
                WebForm subscriptionsFrame,
                string poName,
                string startDate
            ) {
            ValidateSubscriptionCreatedFrame(
                subscriptionCreatedFrame,
                poName
                );
            subscriptionsFrame.
                ExpandForm(mt.DataPane, "Subscriptions").
                FindGridRow(Cell("Subscription Name", poName)).
                ValidateGridRow(Cell("Start Date", startDate));
        }

        private static void
            ValidateSubscriptionCreatedFrame(
                WebForm subscriptionCreatedFrame,
                string poName
            ) {
            subscriptionCreatedFrame.
                GetForm(mt.DataPane, "Subscriptions").
                ValidateTextFieldValue(caption: "The following Subscription was created successfully", expectedValue: poName);

            subscriptionCreatedFrame.
                Click(_.Button, "Manage Subscriptions");
        }

        #endregion TestHelpers
    }
}
