﻿using System;
using MetraTech.DomainModel.AccountTypes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UtilityComponents;
using WebComponents.WebForms;
using MetraTech.TestSystem.Interaction;
using MetraTech.TestComponents;
using MetraTech.TestComponents.MetraNet;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class ManageSecurity : MetraNetTestSuite
    {
        #region Constants

        private const string CsrRoleName = "CSR (MetraCare)";
        private const string CsrRoleDescription = "CSR User: Authorizes a user to perform routine CSR tasks in MetraCare";

        #endregion Constants

        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies the following MetraControl capabilities:
                      ""Manage Backouts and Reruns"",
                      ""Manage Payment Server"",
                      ""Update Runtime Configuration"",
                      ""Manage Usage Processing"",
                      ""Manage Scheduled Adapters"",
                      ""Manage EOP Adapters"".")]
        public void CheckMetraControlCapabilitiesTest()
        {
            var sysAcc = AccountManager.AddNew<SystemAccount>("SystemAccount.xml");
            CapabilityManager.GrantApplicationLogonCapability(sysAcc._AccountID.Value, "MOM");
            CapabilityManager.GrantCapability("Manage Backouts and Reruns", sysAcc._AccountID.Value);
            CapabilityManager.GrantCapability("Manage Payment Server", sysAcc._AccountID.Value);
            CapabilityManager.GrantCapability("Update Runtime Configuration", sysAcc._AccountID.Value);
            CapabilityManager.GrantCapability("Manage Usage Processing", sysAcc._AccountID.Value);
            CapabilityManager.GrantCapability("Manage Scheduled Adapters", sysAcc._AccountID.Value);
            CapabilityManager.GrantCapability("Manage EOP Adapters", sysAcc._AccountID.Value);

            //====- VALIDATION STAFF -========

            var loginPage = WebSite.LogIn(sysAcc, changePassword: true);
            var metraSidebar = loginPage.ExpandForm(mn.Sidebar, "west");
            var metraControlMenu = metraSidebar.ExpandForm(mt.Menu, "MetraControl");
            CheckMetraControlMenu(metraControlMenu, "Backout Management");
            CheckMetraControlMenu(metraControlMenu, "Payments");
            CheckMetraControlMenu(metraControlMenu, "Administration");
            CheckMetraControlMenu(metraControlMenu, "Usage Processing");
            CheckMetraControlMenu(metraControlMenu, "Scheduled Adapters");
            CheckMetraControlMenu(metraControlMenu, "Billing");
            TakeScreenshot("MetraControl Menu");
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies that a capability can be granted to a CSR account.")]
        public void GrantCapabilityToCsrAccountTest()
        {
            var sysAcc = AccountManager.AddNewAccount("SystemAccount.xml", userNamePrefix: "sysGrantCpbl");
            var sysAccDisplayName = AccountManager.FormatDisplayName(sysAcc);

            var mainPage = WebSite.LogInAsAdmin();
            var securityPermissionsFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: sysAcc.UserName,
                        dropdownValue: sysAccDisplayName
                    ).NavigateAccountToolbarToFrame_1(
                        menu: "Security",
                        menuItem: "Security",
                        caption: "Security Permissions",
                        timeout: 60000UL
                    );
            AddCapability(
                securityPermissionsFrame,
                "Unlimited Capability:"
                );
            securityPermissionsFrame.
                CheckGridRow_1(
                    Cell("Capability Description", "Unlimited Capability:"),
                    exists: true
                );
            securityPermissionsFrame.Click(_.Button, "Close");
            mainPage.WaitLoad();

            //====- VALIDATION STAFF -========

            var metraSidebar =
                mainPage
                    .LogOut().LogIn(sysAcc, changePassword: true)
                    .ExpandForm(mn.Sidebar, "west");

            metraSidebar.ExpandForm(mt.Menu, "MetraCare", switchToForm: false);
            TakeScreenshot("MetraCare Menu");

            var metraControlMenu = metraSidebar.ExpandForm(mt.Menu, "MetraControl");
            TakeScreenshot("MetraControl Menu");
            metraControlMenu.GetFocus(mt.Menu, "File Processing");
            TakeScreenshot("MetraControl Menu");

            metraSidebar.ExpandForm(mt.Menu, "MetraOffer", switchToForm: false);
            TakeScreenshot("MetraOffer Menu");

            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies that a capability can be granted to a Corporate account.")]
        public void GrantCapabilityToCorporateAccountTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpGrantCpbl");
            var corpAccDisplayName = AccountManager.FormatDisplayName(corpAcc);

            var mainPage = WebSite.LogInAsAdmin();
            var securityPermissionsFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: corpAcc.UserName,
                        dropdownValue: corpAccDisplayName
                    ).NavigateAccountToolbarToFrame_1(
                        menu: "Security",
                        menuItem: "Manage Security",
                        caption: "Security Permissions"
                    );
            AddCapability(
                securityPermissionsFrame,
                "MetraView Admin:"
                );
            securityPermissionsFrame.
                CheckGridRow_1(
                    Cell("Capability Description", "MetraView Admin:"),
                    exists: true
                );

            //====- BEGIN EDIT CAPABILITY: "Manage Account Hierarchies:" -========
            var editCapabilityFrame =
                LoadEditCapabilityFrame(
                    securityPermissionsFrame,
                    capabilityName: "Manage Account Hierarchies:"
                    );
            EditManageAccountHierarchiesCapability(editCapabilityFrame);
            securityPermissionsFrame.WaitLoad();
            //====- END EDIT CAPABILITY: "Manage Account Hierarchies:" -========

            securityPermissionsFrame.Click(_.Button, "Close");
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies that a role can be assigned to a CSR.")]
        public void AssignRoleToCsrAccountTest()
        {
            var sysAcc = AccountManager.AddNewAccount("SystemAccount.xml", userNamePrefix: "sysAssignRole");
            var sysAccDisplayName = AccountManager.FormatDisplayName(sysAcc);

            var mainPage = WebSite.LogInAsAdmin();
            var securityPermissionsFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: sysAcc.UserName,
                        dropdownValue: sysAccDisplayName
                    ).NavigateAccountToolbarToFrame_1(
                        menu: "Security",
                        menuItem: "Security",
                        caption: "Security Permissions"
                    );
            AddRole(securityPermissionsFrame, roleName: CsrRoleName);
            securityPermissionsFrame
                .FindGridRow_1(Cell("Role Name", CsrRoleName))
                .ValidateGridRow_1(Cell("Role Description", CsrRoleDescription))
                ;
            securityPermissionsFrame.Click(_.Button, "Close");
            WebSite.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private void
            CheckMetraControlMenu(
                WebForm metraControlMenu,
                string menuName
            ) {
            try {
                metraControlMenu.ExpandForm(mt.Menu, menuName, switchToForm: false);
            } catch (Exception exception) {
                LogUnhandledException(exception, "Failed to check menu 'MetraControl/{0}'.", menuName);
                var fileName = PathExt.NormalizeFileName(menuName);
                TakeScreenshot(fileName);
            }
        }        

        private static void
            AddCapability(
                WebForm securityPermissionsFrame,
                string capabilityName
            ) {
            securityPermissionsFrame.
                Click(_.Button, "Add Capability");

            var addCapabilityFrame =
                securityPermissionsFrame.
                    Page().GetFrame_1("Add Capability");

            addCapabilityFrame.
                SelectSingleGridRow_1((Cell("Capability Description", capabilityName))).
                Click(_.Button, "OK").
                WaitLoad();
        }

        private static WebForm
            LoadEditCapabilityFrame(
                WebForm securityPermissionsFrame,
                string capabilityName,
                string caption = null
            ) {
            if (caption == null) {
                caption = capabilityName;
            }
            var capabilityGrid =
                securityPermissionsFrame.
                    WithPositioning(arg: 1).
                    GetForm(mt.Grid_1);

            securityPermissionsFrame.
                ClearPositioning();

            var capabilityGridCellActions =
                capabilityGrid.
                    FindGridRow_1(Cell("Capability Description", capabilityName)).
                    GetGridRowCell_1(Cell(columnName: "Action"));

            capabilityGridCellActions.
                WithPositioning(arg: 1).Click(_.img);

            var editCapabilityFrame =
                securityPermissionsFrame.
                    Page().GetFrame_1(caption);

            return editCapabilityFrame;
        }

        private static void
            EditManageAccountHierarchiesCapability(
                WebForm editCapabilityFrame
            ) {
            editCapabilityFrame.
                ClickWithReload(_.Button, "Add");

            editCapabilityFrame.WithPositioning(arg: 2);
            editCapabilityFrame.
                EnterDropBoxValue(
                    control: mt.DropBox_1,
                    caption: "Manage Account Hierarchies: Specify access level - Read or Write (where Write includes Read access)",
                    value: "WRITE",
                    dropDown: false
                ).EnterTextBoxValue(
                    control: mt.TextBox_1,
                    caption: "Specify access to hierarchy branches",
                    value: "All Corporate Accounts (1)"
                ).EnterCheckBoxValue(
                    control: mt.CheckBox_1,
                    caption: "All Descendants",
                    value: true
                );
            editCapabilityFrame.ClearPositioning();
            editCapabilityFrame.Click(_.Button, "OK");
        }


        private static void
            AddRole(
                WebForm securityPermissionsFrame,
                string roleName
            ) {
            securityPermissionsFrame.
                Click(_.Button, "Add Role");

            var addRoleFrame =
                securityPermissionsFrame.
                    Page().GetFrame_1(caption: "Add Role");

            addRoleFrame.
                SelectSingleGridRow_1(Cell("Role Name", roleName)).
                Click(_.Button, "OK").
                WaitLoad();
        }

        #endregion TestHelpers
    }
}
