﻿using MetraTech.DomainModel.AccountTypes;
using MetraTech.DomainModel.BaseTypes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UtilityComponents;
using WebComponents.WebForms;
using MetraTech.TestSystem.Interaction;
using MetraTech.TestComponents;
using MetraTech.TestComponents.MetraNet;
using MetraTech.WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class FindAccount : MetraNetTestSuite
    {
        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(
            @"Verifies that a CoreSubscriber account can be loaded directly from MetraNet main page via ""Account Quick Search"" find box." +
            @"Verifies that account hierarchy of the loaded CoreSubscriber account correctly displayed on ""Properties"" tab in ""Account"" sidebar." +
            @"Verifies that link to CoreSubscriber account is displayed on ""Recent Accounts"" panel after account was closed on ""Properties"" tab in ""Account"" sidebar."
            )]
        public void LoadCoreSubscriberAccountTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpLoadSubAcc");
            var depAcc = AccountManager.AddNewAccount("DepartmentAccount.xml", userNamePrefix: "depLoadSubAcc", ancestor: corpAcc);
            var subscrAcc = AccountManager.AddNew<CoreSubscriber>("SubscriberAccount.xml", userNamePrefix: "subAccLoad", ancestor: depAcc);

            var subscrAccContactView = subscrAcc.LDAP[0];
            var depAccDisplayName = AccountManager.FormatDisplayName(depAcc, friendly: true);
            var subscrAccFriendlyUserName = AccountManager.FormatFriendlyUserName(subscrAcc);
            var subscrAccDisplayName = AccountManager.FormatDisplayName(subscrAcc);
            var subscrAccFriendlyDisplayName = AccountManager.FormatDisplayName(subscrAcc, friendly: true);

            var mainPage = WebSite.LogInAsAdmin();

            var accountSummaryFrame =
                mainPage.LoadAccountSummaryFrame(
                    enterValue: subscrAcc.UserName,
                    dropdownValue: subscrAccDisplayName
                    );
            var accountDetailsFrame =
                accountSummaryFrame.
                    NavigateAccountToolbarToFrame(
                        menu: "Account",
                        menuItem: "Account Details",
                        caption: "Account Summary"
                    );
            ValidateAccountDetailsFrame(
                accountDetailsFrame,
                subscrAcc,
                subscrAcc.Internal,
                subscrAccContactView,
                subscrAccFriendlyDisplayName,
                depAccDisplayName
                );
            mainPage.SwitchToForm();
            accountSummaryFrame =
                mainPage
                    .Click(_.Button, subscrAccDisplayName)
                    .Page().GetFrame("Account 360")
                    ;
            ValidateAccountSummaryFrame(
                accountSummaryFrame,
                subscrAccFriendlyUserName,
                subscrAccDisplayName,
                subscrAccContactView
                );
            mainPage.SwitchToForm();
            var accountSidebarHierarchyTab =
                mainPage.NavigateAccountSidebar(
                    tab: "Hierarchy"
                    );
            ValidateAccountSidebarHierarchyTab(
                accountSidebarHierarchyTab,
                subscrAccFriendlyUserName,
                subscrAccDisplayName,
                subscrAccContactView
                );
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies that ""Account Advanced Find"" correctly returns and lists all records that match the specified criteria.")]
        public void AdvancedFindAccountTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpAdvFnd");
            var depAcc = AccountManager.AddNewAccount("DepartmentAccount.xml", userNamePrefix: "depAdvFnd", ancestor: corpAcc);
            var subscrAcc = AccountManager.AddNew<CoreSubscriber>("SubscriberAccount.xml", userNamePrefix: "subAccAdvFnd", ancestor: depAcc);
            subscrAcc.AncestorAccountID = depAcc._AccountID;

            var corpAccDisplayName = AccountManager.FormatDisplayName(corpAcc);
            var subscrAccContactView = subscrAcc.LDAP[0];

            var mainPage = WebSite.LogInAsAdmin();
            var advancedFindFrame = mainPage.LoadAdvancedFindFrame();
            TakeScreenshot("Advanced Find Frame");

            // ============-- BEGIN CHECK: "Search by 'User Name' and improper 'Account Type'" --==========================
            var searchFiltersDataPane =
                advancedFindFrame.
                    ExpandForm(mt.DataPane, "Search Filters").
                    EnterTextBoxValue(caption: "User name", value: corpAcc.UserName).
                    EnterComboBoxValue(control: mt.ComboBox_Condition, caption: "Account Type", value: "=").
                    EnterComboBoxValue(control: mt.ComboBox_ByCondition, caption: @Array("Account Type", "="), value: "DepartmentAccount").
                    Click(_.Button, "Search");

            var accountsDataPane =
                advancedFindFrame.
                    WaitLoad().
                    ExpandForm(mt.DataPane, "Accounts").
                    CheckDisplayed(_.Label, "No records found.");
            // ============-- END CHECK: "Search by 'User Name' and improper 'Account Type'" --============================

            // ============-- BEGIN CHECK: "Search by 'Parent Id' and 'Account Type'" --===================================
            searchFiltersDataPane.
                ClearTextBoxValue(caption: "User name").
                EnterFindBoxValue(caption: "Parent Id", value: corpAccDisplayName, mode: DataInputMode.Enter).
                Click(_.Button, "Search");

            accountsDataPane.
                WaitLoad().
                CheckGridRow(Cell("User name", depAcc.UserName), exists: true);
            // ============-- END CHECK: "Search by 'Parent Id' and 'Account Type'" --=====================================

            // ============-- BEGIN CHECK: "Search by 'Parent Id'" --======================================================
            searchFiltersDataPane.
                ClearComboBoxValue(mt.ComboBox_ByCondition, @Array("Account Type", "=")).
                EnterFindBoxValue(caption: "Parent Id", value: depAcc.UserName).
                Click(_.Button, "Search");

            var subscrAccGridRow =
                accountsDataPane.
                    WaitLoad().
                    FindGridRow(Cell("User name", subscrAcc.UserName));

            ValidateAccountGridRow(
                subscrAccGridRow,
                subscrAcc,
                subscrAcc.Internal,
                subscrAccContactView
                );
            // ============-- END CHECK: "Search by 'Parent Id'" --========================================================

            // ============-- BEGIN CHECK: "Search by 'User Name' and 'Account Type' non equal to improper one" --=========
            searchFiltersDataPane.
                ClearFindBoxValue(caption: "Parent Id").
                EnterTextBoxValue(caption: "User name", value: corpAcc.UserName.Substring(0, 8)).
                EnterComboBoxValue(control: mt.ComboBox_Condition, caption: "Account Type", value: "!=").
                EnterComboBoxValue(control: mt.ComboBox_ByCondition, caption: @Array("Account Type", "!="), value: "SystemAccount").
                Click(_.Button, "Search");

            accountsDataPane.
                WaitLoad().
                CheckGridRow(Cell("User name", corpAcc.UserName), exists: true);
            // ============-- END CHECK: Search by 'User Name' and 'Account Type' non equal to improper one --=============

            WebSite.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private void
            ValidateAccountDetailsFrame(
                WebForm accountDetailsFrame,
                Account account,
                InternalView accountInternalView,
                ContactView accountContactView,
                string subscrAccFriendlyDisplayName,
                string depAccDisplayName
            ) {
            accountDetailsFrame.
                ExpandForm(mt.DataPane, "Billing Information").
                ValidateTextBoxValue(caption: "First Name", expectedValue: accountContactView.FirstName).
                ValidateTextBoxValue(caption: "Last Name", expectedValue: accountContactView.LastName).
                ValidateTextBoxValue(caption: "Company", expectedValue: accountContactView.Company).
                ValidateTextBoxValue(caption: "City", expectedValue: accountContactView.City).
                ValidateTextFieldValue(caption: "Country", expectedValue: accountContactView.CountryValueDisplayName).
                Collapse();

            accountDetailsFrame.
                ExpandForm(mt.DataPane, "Login Information").
                ValidateTextFieldValue(caption: "Authentication Type", expectedValue: account.AuthenticationTypeValueDisplayName).
                ValidateTextBoxValue(caption: "User name", expectedValue: account.UserName).
                ValidateTextBoxValue(caption: "Name space", expectedValue: account.Name_Space).
                ValidateTextFieldValue(caption: "Parent Id", expectedValue: depAccDisplayName).
                ValidateTextBoxValue(caption: "Hierarchy start date", expectedValue: @FormatDateTime(account.Hierarchy_StartDate.Value.Date)).
                Collapse();

            accountDetailsFrame.
                ExpandForm(mt.DataPane, "Account Information").
                ValidateTextFieldValue(caption: "Currency", expectedValue: accountInternalView.Currency).
                ValidateTextBoxValue(caption: "Billable", expectedValue: accountInternalView.Billable).
                ValidateTextFieldValue(caption: "Language", expectedValue: accountInternalView.LanguageValueDisplayName).
                ValidateTextFieldValue(caption: "Timezone", expectedValue: accountInternalView.TimezoneIDValueDisplayName).
                ValidateTextFieldValue(caption: "Payer Id", expectedValue: subscrAccFriendlyDisplayName).
                ValidateTextFieldValue(caption: "Billing Cycles", expectedValue: accountInternalView.UsageCycleTypeValueDisplayName).
                ValidateTextFieldValue(caption: "End Day of Month", expectedValue: account.DayOfMonth).
                ValidateTextBoxValue(caption: "Security Answer", expectedValue: accountInternalView.SecurityAnswer).
                Collapse();

            accountDetailsFrame.
                ExpandForm(mt.DataPane, "Tax").
                ValidateTextBoxValue(caption: "MetraTax Has Override Band", expectedValue: accountInternalView.MetraTaxHasOverrideBand).
                ValidateTextBoxValue(caption: "Use Standard Inclusive Tax Calculation", expectedValue: accountInternalView.UseStdImpliedTaxAlg).
                ValidateTextBoxValue(caption: "Tax Exempt Start Date", expectedValue: @FormatDateTime(accountInternalView.TaxExemptStartDate.Value.Date)).
                ValidateTextBoxValue(caption: "Tax Exempt End Date", expectedValue: @FormatDateTime(accountInternalView.TaxExemptEndDate.Value.Date)).
                ValidateTextBoxValue(caption: "Tax Exempt End Date", expectedValue: @FormatDateTime(accountInternalView.TaxExemptEndDate.Value.Date)).
                ValidateTextBoxValue(caption: "Tax Exempt Id", expectedValue: accountInternalView.TaxExemptID).
                ValidateTextBoxValue(caption: "Tax Registry Reference", expectedValue: accountInternalView.TaxRegistryReference).
                Collapse();
        }

        private static void
            ValidateAccountSummaryFrame(
                WebForm accountSummaryFrame,
                string accountFriendlyUserName,
                string accountDisplayName,
                ContactView accountContactView
            ) {
            accountSummaryFrame.
                CheckDisplayed(_.Label, accountFriendlyUserName).
                CheckDisplayed(_.Label, accountContactView.Company).
                CheckDisplayed(_.Label, accountDisplayName);
        }

        private static void
            ValidateAccountSidebarHierarchyTab(
                WebForm accountSidebarHierarchyTab,
                string accountFriendlyUserName,
                string accountDisplayName,
                ContactView accountContactView
            ) {
            accountSidebarHierarchyTab.
                CheckDisplayed(_.Label, accountDisplayName).
                CheckDisplayed(_.Label, accountFriendlyUserName).
                CheckDisplayed(_.Label, accountContactView.Company).
                CheckDisplayed(_.Label, string.Format("{0}, {1} {2}", accountContactView.City, accountContactView.State, accountContactView.Zip)).
                CheckDisplayed(_.Label, accountContactView.CountryValueDisplayName).
                CheckDisplayed(_.Link, accountContactView.Email).
                Collapse();
        }


        private void
            ValidateAccountGridRow(
                WebForm subscrAccGridRow,
                Account account,
                InternalView accountInternalView,
                ContactView accountContactView
            ) {
            subscrAccGridRow.
                ValidateGridRow(Cell("First Name", accountContactView.FirstName)).
                ValidateGridRow(Cell("Last Name", accountContactView.LastName)).
                ValidateGridRow(Cell("Account Status", account.AccountStatusValueDisplayName)).
                Expand();

            subscrAccGridRow.
                CheckDisplayed(_.Label, "Billing Information").
                ValidateTextFieldValue(caption: "First Name", expectedValue: accountContactView.FirstName).
                ValidateTextFieldValue(caption: "Last Name", expectedValue: accountContactView.LastName).
                ValidateTextFieldValue(caption: "Phone Number", expectedValue: accountContactView.PhoneNumber).
                ValidateTextFieldValue(caption: "Fax", expectedValue: accountContactView.FacsimileTelephoneNumber).
                ValidateTextFieldValue(caption: "Company", expectedValue: accountContactView.Company);

            subscrAccGridRow.
                CheckDisplayed(_.Label, "Login Information").
                ValidateTextFieldValue(caption: "Account Id", expectedValue: account._AccountID).
                ValidateTextFieldValue(caption: "User name", expectedValue: account.UserName).
                ValidateTextFieldValue(caption: "Name space", expectedValue: account.Name_Space).
                ValidateTextFieldValue(caption: "Parent Id", expectedValue: account.AncestorAccountID).
                ValidateTextFieldValue(caption: "Parent Name", expectedValue: account.AncestorAccount).
                ValidateTextFieldValue(caption: "Hierarchy start date", expectedValue: @FormatDate(account.Hierarchy_StartDate.Value.Date)).
                ValidateTextFieldValue(caption: "Hierarchy end date", expectedValue: @FormatDate(account.Hierarchy_EndDate.Value.Date));

            subscrAccGridRow.
                CheckDisplayed(_.Label, "Account Information").
                ValidateTextFieldValue(caption: "Currency", expectedValue: accountInternalView.Currency).
                ValidateTextFieldValue(caption: "Billable", expectedValue: accountInternalView.Billable.AsString("Yes", "No")).
                ValidateTextFieldValue(caption: "Tax Exempt", expectedValue: accountInternalView.TaxExempt).
                ValidateTextFieldValue(caption: "Language", expectedValue: accountInternalView.LanguageValueDisplayName).
                ValidateTextFieldValue(caption: "Billing Cycle", expectedValue: accountInternalView.UsageCycleTypeValueDisplayName);

            subscrAccGridRow.Collapse();
        }

        #endregion TestHelpers
    }
}
