﻿using System;
using System.Linq;
using System.Threading;
using MetraTech.DomainModel.AccountTypes;
using MetraTech.DomainModel.BaseTypes;
using MetraTech.DomainModel.Enums.Core.Metratech_com_billingcycle;
using MetraTech.TestSystem.Interaction;
using MetraTech.UsageServer;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetraTech.TestComponents;
using MetraTech.TestComponents.MetraNet;
using MetraTech.WebComponents.WebForms;
using WebComponents.WebForms;
using CycleType = MetraTech.UsageServer.CycleType;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;
using WebFormExtBase = WebComponents.WebForms.WebFormExt;
using usm = MetraTech.TestSystem.Interaction.UsageServerManager;
using RecurringEventInstance = MetraTech.TestSystem.Interaction.UsageServerManager.RecurringEventInstance;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class EventProcessing : MetraNetTestSuite
    {
        #region Constants

        internal const int EventRunTimeout = 600000; //10 mins.
        private const string ScheduledEventFirstRunStartDate = ("10/01/2002 12:00:00 AM");

        #endregion Constants

        #region Tests

        /// <remarks>
        /// HardCloseIntervalEopProcessingTest fails on Dev Environment 
        /// as Tax adapters and Reporting adapters are not configured on Dev Env.
        /// </remarks>
        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Hard close all past intervals and execute hard close interval EOP processing.")]
        public void HardCloseIntervalEopProcessingTest()
        {
            var monthAgo = DateTime.UtcNow.AddDays(-32);

            var corpAcc = AccountManager.
                AddNew<CorporateAccount>(
                    "CorporateAccount.xml",
                    userNamePrefix: "corpEop",
                    startDate: monthAgo,
                    usageCycleType: UsageCycleType.Daily
                );
            SubscriptionManager.SubscribeAccount(corpAcc, "Localized Audio Conference Product Offering USD");
            var intervalId = MeterUsages(corpAcc);

            var mainPage = WebSite.LogInAsAdmin();

            RunScheduledAdapter(
                mainPage,
                "Aggregate Metrics Processor (Scheduled)",
                "NonRecurring Charge Adapter"
                );
            var billableIntervalsFrame =
                mainPage.NavigateMetraSidebarToFrame(
                    metraMenu: "MetraControl",
                    menu: "Billing",
                    menuItem: "Billable Intervals"
                    );
            var billingGroupsFrame = NavigateToBillingGroupsFrame(mainPage, billableIntervalsFrame, intervalId);
            CreateBillingGroups(billingGroupsFrame);
            var billingGroupFrame = SoftCloseInterval(billingGroupsFrame);

            var adapterList = usm.GetRecurringEventInstances(intervalId).ToArray();

            var checkpoint = 1;
            var checkpointAdapterList = GetAdapterList(checkpoint, adapterList);
            RunEopAdapter(billingGroupFrame, checkpointAdapterList);

            ++checkpoint;
            checkpointAdapterList = GetAdapterList(checkpoint, adapterList);
            RunEopAdapter(billingGroupFrame, checkpointAdapterList);

            ++checkpoint;
            checkpointAdapterList = GetAdapterList(checkpoint, adapterList);
            RunEopAdapter(billingGroupFrame, checkpointAdapterList);

            // NOTE: uncomment this block before run test on DEV environment
            /*++checkpoint;
            checkpointAdapterList = GetAdapterList(checkpoint, adapterList);
            RunEopAdapter(billingGroupFrame, checkpointAdapterList);*/

            //========- VALIDATION STAFF -===============

            billingGroupFrame.Click(_.Button, "Back to Interval");
            WaitBillingGroupHardClosed(billingGroupsFrame);
            usm.Client.HardCloseUsageInterval(intervalId, ignoreBillingGroups: true);
            CheckIntervalHardClosed(mainPage, intervalId);
            WebSite.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private static int MeterUsages(Account account)
        {
            usm.HardCloseAllPastUsageIntervals(
                endDate: DateTime.UtcNow,
                ignoreBillingGroups: true,
                ignoreCycleTypes: CycleType.Daily
                );
            usm.HardCloseAllPastUsageIntervals(
                endDate: account.AccountStartDate.Value.Date,
                ignoreBillingGroups: true
                );

            var interval = usm.GetFirstOpenUsageInterval(CycleType.Daily);
            var intervalId = interval.IntervalID;
            var intervalStartDate = interval.StartDate;

            usm.Client.OpenUsageInterval(intervalId, ignoreDeps: true);
            MeteringManager.Meter(ComposeMeteringSession.AudioConfCall(account.UserName, intervalStartDate));

            return intervalId;
        }

        private static WebForm
            NavigateToBillingGroupsFrame(
                WebPage mainPage,
                WebForm billableIntervalsFrame,
                int intervalId
            ) {
            billableIntervalsFrame.
                ExpandForm(mt.DataPane, "Search Filters").
                EnterComboBoxValue(control: mt.ComboBox_Condition, caption: "Interval ID", value: "=").
                EnterTextBoxValue(control: mt.ComboBox_ByCondition, caption: @Array("Interval ID", "="), value: intervalId).
                EnterComboBoxValue(control: mt.ComboBox_Condition, caption: "Usage Cycle Type", value: "=").
                EnterComboBoxValue(control: mt.ComboBox_ByCondition, caption: @Array("Usage Cycle Type", "="), value: "Daily").
                Click(_.Button, "Search");

            billableIntervalsFrame.
                WaitLoad().
                ExpandForm(mt.DataPane, "Billable Intervals").
                FindGridRow(Cell("Interval ID", intervalId)).
                Click(_.Link, intervalId);

            var billingGroupsFrame =
                mainPage.GetFrame_1(
                    caption: "Billing Groups for Interval",
                    framePath: @Array<object>("BillingGroupsIFrame")
                    );

            return billingGroupsFrame;
        }
        
        private static void CreateBillingGroups(WebForm billingGroupsFrame)
        {
            var materializeBillingGroupsButtonCaption =
                (billingGroupsFrame.Displayed(_.Button, "Recreate Billing Groups for Interval")
                     ? "Recreate Billing Groups for Interval"
                     : "Create Billing Groups for Interval"
                );
            billingGroupsFrame.
                ClickWithReload(
                    _.Button, materializeBillingGroupsButtonCaption,
                    timeout: 32000UL, force: true
                );
        }

        private static WebForm
            SoftCloseInterval(
                WebForm billingGroupsFrame,
                string billingGroupName = "Default"
            ) {
            var billingGroupFrame =
                billingGroupsFrame.
                    FindGridRow_1(Cell("Billing Group", billingGroupName)).
                    Click(_.Link, billingGroupName).
                    Page().GetFrame_1("Billing Management: "+billingGroupName).
                    GetForm(_.Any_ById, caption: "mainDiv");

            billingGroupFrame.
                Click(_.Link, "Change State").
                Site().WaitPageOpened(alias: "Billing Group State").
                Click(mt.CheckBox, "Soft Closed").
                Page().CloseByClick(_.Button, "OK").
                SwitchToMainPage();

            var billingGroupStatus =
                billingGroupFrame.
                    WaitLoad().
                    ReadTextFieldValue<string>(caption: "Status");
            if (billingGroupStatus != null) {
                billingGroupStatus = billingGroupStatus.Trim();
            }
            WebFormExtBase.
                ValidateValue(
                    expectedValue: "Soft Closed  Change State",
                    actualValue: billingGroupStatus,
                    equals: true,
                    message: WebFormExtBase.ValidateValueMessageFormat,
                    parameters: (new object[] {billingGroupFrame.FullName, mt.TextField, "Status"})
                );

            return billingGroupFrame;
        }

        private static RecurringEventInstance[]
            GetAdapterList(
                int checkpoint,
                RecurringEventInstance[] adapterList
            ) {
            var checkpointAdapterList =
                adapterList
                    .TakeWhile(adapter => (adapter.Type != RecurringEventType.Checkpoint))
                    .ToArray()
                    ;
            var checkpointAdapterListLength = checkpointAdapterList.Length;
            while (--checkpoint > 0) {
                checkpointAdapterList =
                    adapterList
                        .Skip(++checkpointAdapterListLength)
                        .TakeWhile(adapter => (adapter.Type != RecurringEventType.Checkpoint))
                        .ToArray()
                        ;
                checkpointAdapterListLength += checkpointAdapterList.Length;
            }
            return checkpointAdapterList;
        }

        private void
            RunScheduledAdapter(
                WebPage mainPage,
                params string[] adapterNames
            ) {
            var scheduledAdaptersDataPane =
                mainPage
                    .NavigateMetraSidebarToFrame(
                        metraMenu: "MetraControl",
                        menu: "Scheduled Adapters",
                        menuItem: "Run Scheduled Adapter Now"
                    ).ExpandForm(
                        mt.DataPane, "Scheduled Adapters"
                    );
            foreach (var adapterName in adapterNames) {
                scheduledAdaptersDataPane.SelectGridRow(Cell("Adapter Name", adapterName));
            }
            var startDate =
                GetScheduledAdapterStartDate(
                    scheduledAdaptersDataPane,
                    adapterNames
                    );
            var argStartDate = FormatDateTime(startDate);
            var scheduledAdapterRunListFrame =
                scheduledAdaptersDataPane
                    .Click(_.Button, "Run")
                    .Page(waitLoad:true, timeout:120000UL) // 2 mins
                    .GetFrame_1("Scheduled Adapter Run List", timeout: 120000UL)
                    ;
            scheduledAdapterRunListFrame
                .EnterDropBoxValue("ArgStartDate")
                .EnterDropBoxValue(">=")
                .EnterTextBoxValue(control: mt.TextBox_GridPageFilter_1, caption: @Array("ArgStartDate", ">=", 1), value: argStartDate)
                .ClickWithReload(_.Button, "Go")
                ;
            WaitScheduledAdapterFinished(scheduledAdapterRunListFrame, adapterNames);
        }

        private static DateTime
            GetScheduledAdapterStartDate(
                WebForm scheduledAdaptersDataPane,
                params string[] adapterNames
            ) {
            var startDate = DateTime.MaxValue;
            foreach (var adapterName in adapterNames) {
                var adapterStartDateStr =
                    scheduledAdaptersDataPane
                        .FindGridRow(Cell("Adapter Name", adapterName))
                        .GetGridRowCell(Cell("Start Date For New Instance"))
                        .ReadElementValue<string>(_.self)
                        ;
                if (string.IsNullOrWhiteSpace(adapterStartDateStr)) {
                    adapterStartDateStr = ScheduledEventFirstRunStartDate;
                }
                adapterStartDateStr = adapterStartDateStr.Trim();
                var adapterStartDate = DateTime.Parse(adapterStartDateStr);
                if (adapterStartDate < startDate) {
                    startDate = adapterStartDate;
                }
            }
            return startDate;
        }

        private static void
            WaitScheduledAdapterFinished(
                WebForm scheduledAdapterRunListFrame,
                params string[] adapterNames
            ) {
            var now = DateTime.Now;
            do {
                scheduledAdapterRunListFrame.ClickWithReload(_.LinkImage_ByTooltip, "Refresh Page");
                var adaptersFinished = CheckScheduledAdapterStatus(scheduledAdapterRunListFrame, adapterNames);
                if (adaptersFinished) {
                    break;
                }
                var timeout = (DateTime.Now - now).TotalMilliseconds;
                Assert.IsTrue((timeout < EventRunTimeout), "Scheduled adapters not finished in timeout of '{0}' milliseconds.", timeout);
                Thread.Sleep(1600);
            } while (true);
        }

        private static bool
            CheckScheduledAdapterStatus(
                WebForm scheduledAdapterRunListFrame,
                params string[] adapterNames
            ) {
            foreach (var adapterName in adapterNames) {
                var adapterStatus =
                    scheduledAdapterRunListFrame.
                        FindGridRow_1(Cell("EventDisplayName", adapterName)).
                        GetGridRowCell_1(Cell("Status")).
                        ReadElementValue<string>(_.self);
                var adapterFailed = (adapterStatus == "Failed");
                Assert.IsFalse(adapterFailed, "'{0}' Scheduled adapter has '{1}' status.", adapterName, adapterStatus);
                var adapterFinished = ((adapterStatus != "ReadyToRun") && (adapterStatus != "Running"));
                if (!adapterFinished) {
                    return false;
                }
            }
            return true;
        }

        private static void
            RunEopAdapter(
                WebForm billingGroupFrame,
                params RecurringEventInstance[] adapters
            ) {
            foreach (var adapter in adapters) {
                var adapterDisplayName = adapter.DisplayName;
                billingGroupFrame.EnterCheckBoxValue(caption: adapterDisplayName, value: true);
            }
            billingGroupFrame.ClickWithReload(_.Button, "Run Adapter");
            WaitAdapterFinished(billingGroupFrame, adapters);
            billingGroupFrame.WithPositioning(1).ClickWithReload(_.Button, "Acknowledge").ClearPositioning();
        }

        private static void
            WaitAdapterFinished(
                WebForm billingGroupFrame,
                params RecurringEventInstance[] adapters
            ) {
            var now = DateTime.Now;
            do {
                billingGroupFrame.ClickWithReload(_.Button, "Refresh");
                var adaptersFinished = CheckAdapterStatus(billingGroupFrame, adapters);
                if (adaptersFinished) {
                    break;
                }
                var timeout = (DateTime.Now - now).TotalMilliseconds;
                Assert.IsTrue((timeout < EventRunTimeout), "EOP adapters not finished in timeout of '{0}' milliseconds.", timeout);
                Thread.Sleep(1600);
            } while (true);
        }

        private static bool
            CheckAdapterStatus(
                WebForm billingGroupFrame,
                params RecurringEventInstance[] adapters
            ) {
            PopulateAdapterStatus(billingGroupFrame, adapters);
            foreach (var adapter in adapters) {
                var adapterFailed = (adapter.DisplayStatus == "Failed");
                Assert.IsFalse(adapterFailed, "'{0}' EOP adapter has '{1}' status.", adapter.DisplayName, adapter.DisplayStatus);
                var adapterFinished = ((adapter.DisplayStatus != "Ready To Run") && (adapter.DisplayStatus != "Running"));
                if (!adapterFinished) {
                    return false;
                }
            }
            return true;
        }

        private static void
            PopulateAdapterStatus(
                WebForm billingGroupFrame,
                params RecurringEventInstance[] adapters
            ) {
            const string adapterStatusXPath = "//*[(normalize-space(text())='{0}') or ./strong[normalize-space(text())='{0}']]/following-sibling::td[2]";
            foreach (var adapter in adapters) {
                var adapterStatus = billingGroupFrame.ReadElementValue<string>(adapterStatusXPath, adapter.DisplayName);
                if (adapterStatus != null) {
                    adapterStatus = adapterStatus.Trim();
                }
                adapter.DisplayStatus = adapterStatus;
            }
        }

        private static void
            WaitBillingGroupHardClosed(
                WebForm billingGroupsFrame,
                string billingGroupName = "Default"
            ) {
            var billingGroupGridRowCell =
                billingGroupsFrame.
                    WaitLoad().
                    FindGridRow_1(Cell("Billing Group", billingGroupName)).
                    GetGridRowCell_1(Cell("Status"));

            var now = DateTime.Now;
            do {
                billingGroupsFrame.ClickWithReload(_.LinkImage_ByTooltip, "Refresh Page");
                var billingGroupHardClosed = billingGroupGridRowCell.Displayed(_.Label, "Hard Closed");
                if (billingGroupHardClosed) {
                    break;
                }
                var timeout = (DateTime.Now - now).TotalMilliseconds;
                Assert.IsTrue((timeout < EventRunTimeout), "'{0}' billing group not 'Hard Closed' in timeout of '{1}' milliseconds.", billingGroupName, timeout);
                Thread.Sleep(1600);
            } while (true);
        }

        private static void CheckIntervalHardClosed(WebPage mainPage, int intervalId)
        {
            CheckIntervalGridRow(mainPage, intervalId, exists: false, caption: "Billable Intervals");
            CheckIntervalGridRow(mainPage, intervalId, exists: false, caption: "Active Intervals");
            CheckIntervalGridRow(mainPage, intervalId, exists: true, caption: "Completed Intervals");
        }

        private static void
            CheckIntervalGridRow(
                WebPage mainPage,
                int intervalId,
                bool exists,
                string caption
            ) {
            mainPage
                .NavigateMetraSidebarToFrame(metraMenu: "MetraControl", menu: "Billing", menuItem: caption)
                .ExpandForm(mt.DataPane, "Search Filters")
                .EnterComboBoxValue(control: mt.ComboBox_Condition, caption: "Interval ID", value: "=")
                .EnterTextBoxValue(control: mt.ComboBox_ByCondition, caption: @Array("Interval ID", "="), value: intervalId)
                .EnterComboBoxValue(control: mt.ComboBox_Condition, caption: "Usage Cycle Type", value: "=")
                .EnterComboBoxValue(control: mt.ComboBox_ByCondition, caption: @Array("Usage Cycle Type", "="), value: "Daily")
                .Click(_.Button, "Search")
                .SwitchToParentForm()
                .WaitLoad()
                .ExpandForm(mt.DataPane, caption)
                .CheckGridRow(Cell("Interval ID", intervalId), exists: exists)
                ;
        }

        #endregion TestHelpers
    }
}
