﻿using System;
using System.Linq;
using LogComponents;
using MetraTech.DomainModel.Enums.Core.Metratech_com_billingcycle;
using MetraTech.UsageServer;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetraTech.DomainModel.BaseTypes;
using MetraTech.DomainModel.ProductCatalog;
using MetraTech.TestComponents.MetraView;
using MetraTech.WebComponents.WebForms;
using MetraTech.TestSystem.Interaction;
using WebComponents.WebForms;
using CycleType = MetraTech.UsageServer.CycleType;
using dbq = MetraTech.TestSystem.Interaction.DbQueries;
using db = MetraTech.TestSystem.Interaction.DatabaseManager;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mv = MetraTech.WebComponents.WebControls.MetraView;
using usm = MetraTech.TestSystem.Interaction.UsageServerManager;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class MetraViewBillingReports : MetraViewTestSuite
    {
        #region TestSuite Setup

        [ClassInitialize]
        public static void SetupTestSuite(TestContext testContext)
        {
            var testSuiteName = FormatQualifiedTestSuiteName(testContext);
            LogManager.LogInfo("BEGIN setup test suite '{0}'.", testSuiteName);
            SetupAccountHierarchy();
            CreateSubscriptions();

            var intervalId = MeterUsages();
            usm.Client.MaterializeBillingGroups(intervalId);
            usm.Client.SoftCloseUsageInterval(intervalId);
            GenerateInvoice(_corp._AccountID.Value, intervalId);
            usm.Client.HardCloseUsageInterval(intervalId, ignoreBillingGroups: true);

            env.ProlongatePassword(_corp);
            LogManager.LogInfo("END setup test suite '{0}'.", testSuiteName);
        }

        #region Account Hierarchy

        private const string AudioConfPoName = "Localized Audio Conference Product Offering USD";
        private const string NrcPoName = "Localized Non Reccuring Charge Product Offering USD";
        private const string RcPoName = "RC_DailyArrNoProPerPart_PO_USD";

        private static Account _corp;
        private static Account _dep;
        private static Account _subscr;

        private static Subscription _nrcSubscription;
        private static Subscription _rcSubscription;

        private static void SetupAccountHierarchy()
        {
            var monthAgo = DateTime.Today.AddDays(-32);

            _corp = AccountManager.AddNewAccount(
                "CorporateAccount.xml",
                userNamePrefix: "CorpMvBillRpt",
                startDate: monthAgo,
                usageCycleType: UsageCycleType.Daily
                );
            CapabilityManager.GrantApplicationLogonCapability(_corp._AccountID.Value, "MPS");

            _dep = AccountManager.AddNewAccount(
                "DepartmentAccount.xml",
                userNamePrefix: "DepMvBillRpt",
                ancestor: _corp,
                payer: _corp,
                startDate: monthAgo,
                usageCycleType: UsageCycleType.Daily
                );
            _subscr = AccountManager.AddNewAccount(
                "SubscriberAccount.xml",
                userNamePrefix: "SubscrMvBillRpt",
                ancestor: _dep,
                payer: _corp,
                startDate: monthAgo,
                usageCycleType: UsageCycleType.Daily
                );
        }

        private static void CreateSubscriptions()
        {
            SubscriptionManager.SubscribeAccount(_corp, AudioConfPoName);

            SubscriptionManager.SubscribeAccount(_dep, AudioConfPoName);
            _rcSubscription = SubscriptionManager.SubscribeAccount(_dep, RcPoName);

            SubscriptionManager.SubscribeAccount(_subscr, AudioConfPoName);
            _nrcSubscription = SubscriptionManager.SubscribeAccount(_subscr, NrcPoName);
        }

        private static int MeterUsages()
        {
            usm.HardCloseAllPastUsageIntervals(
                endDate: DateTime.UtcNow,
                ignoreBillingGroups: true,
                ignoreCycleTypes: CycleType.Daily
                );
            usm.HardCloseAllPastUsageIntervals(
                endDate: _corp.AccountStartDate.Value.Date,
                ignoreBillingGroups: true
                );

            var interval = usm.GetFirstOpenUsageInterval(CycleType.Daily);
            var intervalId = interval.IntervalID;
            _intervalDate = interval.StartDate;

            usm.Client.OpenUsageInterval(intervalId, ignoreDeps: true);

            var nrcPi = SubscriptionManager.GetPriceableItemInstance(NrcPoName, "Sub Non Rec Charge");
            var rcPi = SubscriptionManager.GetPriceableItemInstance(RcPoName, "RC_DailyArrNoProPerPart_PI");

            MeteringManager.Meter(
                ComposeMeteringSession.AudioConfCall(_corp.UserName, _intervalDate),
                ComposeMeteringSession.AudioConfCall(_dep.UserName, _intervalDate),
                ComposeMeteringSession.FlatDailyRc(_intervalDate, _dep, _rcSubscription, rcPi),
                ComposeMeteringSession.AudioConfCall(_subscr.UserName, _intervalDate),
                ComposeMeteringSession.NonRecurringCharge(_intervalDate, _subscr._AccountID.Value, _nrcSubscription, nrcPi)
                );

            return intervalId;
        }

        #endregion Account Hierarchy

        #region Generate Invoice

        private static string _invoiceNum;
        private static DateTime _intervalDate;
        
        private static void
            GenerateInvoice(
                int accountId,
                int intervalId,
                string billingGroupName = "Default"
            ) {
            var recEventInstances = usm.GetRecurringEventInstances(intervalId, billingGroupName);
            var invoiceAdapter = recEventInstances.Single(i => (i.DisplayName == "Invoice Adapter"));
            usm.RunAdapter(invoiceAdapter.Id);
            invoiceAdapter.WaitStatus(RecurringEventInstanceStatus.Succeeded, EventProcessing.EventRunTimeout);
            var invoice =
                db.ReadDbSingleRow(
                    dbq.GetInvoice_ByIntervalIdAndAccountId,
                    db.GetDbParameter("interval_Id", intervalId),
                    db.GetDbParameter("account_Id", accountId)
                    );
            _invoiceNum = ((string) invoice["invoice_string"]);
        }

        private string FormatInvoiceBillingInterval()
        {
            var intervalDateFormat = FormatDate(_intervalDate);
            var billingInterval = string.Format("{0} - {0} #Invoice:{1}", intervalDateFormat, _invoiceNum);
            return billingInterval;
        }
        
        #endregion Generate Invoice

        #endregion TestSuite Setup

        #region Tests

        /// <remarks>
        /// BillAndPaymentsDetailedViewTest fails on Dev Environment 
        /// as Tax adapters and Reporting adapters are not configured on Dev Env.
        /// </remarks>
        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies that in MetraView different charges are displayed properly in [Detailed View] on ""Bill & Payments"" page.")]
        public void BillAndPaymentsDetailedViewTest()
        {
            var invoiceBillingInterval = FormatInvoiceBillingInterval();

            var homePage = WebSite.LogIn(_corp);

            var billPaymentsPage =
                homePage.NavigateMetraView(tab: "Bill & Payments");

            billPaymentsPage.
                GetForm(mv.DataPane, "Payments, Credits, & Adjustments").
                EnterDropBoxValue(invoiceBillingInterval).
                WaitLoad();
            
            billPaymentsPage.
                GetForm(mv.DataPane, "Charge").
                Click(_.Link, "Detailed View");

            var chargeDetailsDataPane =
                billPaymentsPage.
                    GetForm(mv.DataPane, "Charge");

            // =======-- BEGIN: VALIDATION STAFF --========================================================================

            var corpNode = chargeDetailsDataPane.ValidateTreeNodeValue("$ 519.50", AccountManager.FormatFriendlyUserName(_corp));
            corpNode.NavigateTreeLeaf("Localized Audio Conference Product Offering USD");
            corpNode.ValidateTreeLeafValue("$ 171.50", "AudioConfCall-Localized");

            var depNode = corpNode.ValidateTreeNodeValue("$ 348.00", AccountManager.FormatFriendlyUserName(_dep));
            depNode.NavigateTreeLeaf("Localized Audio Conference Product Offering USD");
            depNode.ValidateTreeLeafValue("$ 171.50", "AudioConfCall-Localized");
            depNode.NavigateTreeLeaf("RC_DailyArrNoProPerPart_PO_USD");
            depNode.ValidateTreeLeafValue("$ 1.00", "RC_DailyArrNoProPerPart_PI");

            var coreSubscrNode = depNode.ValidateTreeNodeValue("$ 175.50", AccountManager.FormatFriendlyUserName(_subscr));
            coreSubscrNode.NavigateTreeLeaf("Localized Audio Conference Product Offering USD");
            coreSubscrNode.ValidateTreeLeafValue("$ 171.50", "AudioConfCall-Localized");
            coreSubscrNode.NavigateTreeLeaf("Subscribe and Unsubscribe Charges PO - Localized");
            coreSubscrNode.ValidateTreeLeafValue("$ 4.00", "Subscribe Nonrecurring Charges");

            // =======-- END: VALIDATION STAFF --==========================================================================

            billPaymentsPage.LogOut();
        }

        /// <remarks>
        /// BillAndPaymentsSummaryViewTest fails on Dev Environment 
        /// as Tax adapters and Reporting adapters are not configured on Dev Env.
        /// </remarks>
        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies that in MetraView different charges are displayed properly in [Summary View] on ""Bill & Payments"" page.")]
        public void BillAndPaymentsSummaryViewTest()
        {
            var invoiceBillingInterval = FormatInvoiceBillingInterval();

            var homePage = WebSite.LogIn(_corp);

            var billPaymentsPage =
                homePage.NavigateMetraView(tab: "Bill & Payments");

            billPaymentsPage
                .GetForm(mv.DataPane, "Payments, Credits, & Adjustments")
                .EnterDropBoxValue(invoiceBillingInterval)
                .WaitLoad()
                ;
            var chargesDataPane =
                billPaymentsPage.
                    GetForm(mv.DataPane, "Charge").
                    CheckDisplayed(_.Link, "Detailed View");

            // =======-- BEGIN: VALIDATION STAFF --========================================================================

            chargesDataPane.CheckDisplayed(_.Label, "Localized Audio Conference Product Offering USD");
            chargesDataPane.ValidateTextFieldValue(expectedValue:"$ 514.50", caption:"AudioConfCall-Localized");

            chargesDataPane.CheckDisplayed(_.Label, "RC_DailyArrNoProPerPart_PO_USD");
            chargesDataPane.ValidateTextFieldValue(expectedValue: "$ 1.00", caption: "RC_DailyArrNoProPerPart_PI");

            chargesDataPane.CheckDisplayed(_.Label, "Subscribe and Unsubscribe Charges PO - Localized");
            chargesDataPane.ValidateTextFieldValue(expectedValue:"$ 4.00", caption:"Subscribe Nonrecurring Charges");

            chargesDataPane.ValidateTextFieldValue(expectedValue:"$ 519.50", caption:"Sub-Total");
            chargesDataPane.ValidateTextFieldValue(expectedValue:"$ 0.00", caption:"Prebill Adjustments");
            chargesDataPane.ValidateTextFieldValue(expectedValue:"$ 519.50", caption:"Total Charges");
            chargesDataPane.ValidateTextFieldValue(expectedValue:"$ 519.50", caption:"Total");

            // =======-- END: VALIDATION STAFF --==========================================================================

            billPaymentsPage.LogOut();
        }
        
        #endregion Tests
    }
}