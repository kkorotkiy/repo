﻿using System;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UtilityComponents;
using MetraTech.TestSystem.Interaction;
using MetraTech.TestComponents;
using MetraTech.TestComponents.MetraNet;
using MetraNet.AcceptanceTests.Properties;
using System.Collections.Generic;
using MetraTech.DomainModel.BaseTypes;
using MetraTech.DomainModel.ProductCatalog;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class MeterUsage : MetraNetTestSuite
    {
        #region Constants

        public const string AccountUsageValidationMessage = ("Count usages for account[{0}].");

        #endregion Constants

        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies ability of uploading usage via File Landing Service.")]
        [DeploymentItem(@"\FlsSettings", "FlsSettings")]
        public void MeterUsageViaFlsTest()
        {
            try {
                SetupFileLandingService();

                var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", "indepSdkUsg");
                SubscriptionManager.SubscribeAccount(corpAcc, "Localized Audio Conference Product Offering USD");

                string[] landedFiles;
                var controlNumber = LoadUsage(corpAcc.UserName, out landedFiles);
                AssertUsageProcessed(landedFiles);

                var mainPage = WebSite.LogInAsAdmin();

                //========-- BEGIN CHECK: Completed Jobs --========================
                var completedJobsFrame =
                    mainPage
                        .NavigateMetraSidebarToFrame(
                            metraMenu: "MetraControl",
                            menu: "File Processing",
                            menuItem: "Completed Jobs",
                            caption: "File Management Completed Jobs"
                        );
                completedJobsFrame.
                    FindGridRow(Cell("Control Number", controlNumber)).
                    ValidateGridRow(Cell("State", "COMPLETED")).
                    ValidateGridRow(Cell("Error Code", 0));
                //========-- END CHECK: Completed Jobs --==========================

                //========-- BEGIN CHECK: All Jobs --==============================
                var allJobsFrame =
                    mainPage
                        .NavigateMetraSidebarToFrame(
                            metraMenu: "MetraControl",
                            menu: "File Processing",
                            menuItem: "All Jobs",
                            caption: "File Management All Jobs"
                        );
                allJobsFrame.
                    FindGridRow(Cell("Control Number", controlNumber)).
                    ValidateGridRow(Cell("State", "COMPLETED")).
                    ValidateGridRow(Cell("Error Code", 0));
                //========-- END CHECK: All Jobs --================================

                WebSite.LogOut();
            }
            finally {
                RollbackFileLandingService();
            }
        }

        #endregion Tests

        #region TestHelpers

        private static readonly string
            BmeImportExportExe = Path.Combine(env.MtRmpBin, "BMEImportExport.exe");

        private string FlsBackupDirectory {
            get {
                if (_flsBackupDir == null) {
                    _flsBackupDir = Path.Combine(TestContext.DeploymentDirectory, "FlsBackup");
                    if (!Directory.Exists(_flsBackupDir)) {
                        Directory.CreateDirectory(_flsBackupDir).Refresh();
                    }
                }
                return _flsBackupDir;
            }
        }
        private string _flsBackupDir;

        private string FlsSettingsDirectory {
            get {
                if (_flsSettingsDir == null) {
                    _flsSettingsDir = Path.Combine(TestContext.DeploymentDirectory, "FlsSettings");
                }
                return _flsSettingsDir;
            }
        }
        private string _flsSettingsDir;

        private string FlsIncomingDirectory {
            get {
                if (_flsIncomingDir == null) {
                    _flsIncomingDir = Path.Combine(TestContext.TestRunDirectory, "IncomingFLS");
                    if (!Directory.Exists(_flsIncomingDir)) {
                        Directory.CreateDirectory(_flsIncomingDir).Refresh();
                    }
                }
                return _flsIncomingDir;
            }
        }
        private string _flsIncomingDir;

        private void RollbackFileLandingService()
        {
            ImportFlsSettings(FlsBackupDirectory);
            RestartService("metratech.fileservice");
        }

        private void SetupFileLandingService()
        {
            ExportFlsSettings(FlsBackupDirectory);
            ConfigureFlsSettings();
            ImportFlsSettings(FlsSettingsDirectory);
            RestartService("metratech.fileservice");
            AssertFlsIncomingDirectoryCreated("new", "inprogress", "done");
        }

        private void ConfigureFlsSettings()
        {
            ReplaceFlsSettingsContent(
                "Core#FileLandingService#TargetBE.csv",
                "MTRMPBIN", env.MtRmpBin
                );
            ReplaceFlsSettingsContent(
                "Core#FileLandingService#ConfigurationBE.csv",
                @"C:\IncomingFLS", FlsIncomingDirectory
                );
            var wobatchFilePath = Path.Combine(FlsIncomingDirectory, "wobatch.mfs");
            ReplaceFlsSettingsContent(
                "Core#FileLandingService#ArgumentBE.csv",
                @"C:\wobatch.mfs", wobatchFilePath
                );
            File.WriteAllText(wobatchFilePath, Resources.wobatch);
        }

        private void ReplaceFlsSettingsContent( string fileName, string oldValue, string newValue)
        {
            var filePath = Path.Combine(FlsSettingsDirectory, fileName);
            var content = File.ReadAllText(filePath);
            content = content.Replace(oldValue, newValue);
            File.WriteAllText(filePath, content);
        }

        private static void ImportFlsSettings(string importDirectory)
        {
            var args = @Array("imp", "-E", "Core.FileLandingService.*", "-I", "-M", "replace", importDirectory);
            StartProcessAndWaitForExit(BmeImportExportExe, args);
        }

        private static void ExportFlsSettings(string exportDirectory)
        {
            var args = @Array("exp", "-E", "Core.FileLandingService.*", exportDirectory);
            StartProcessAndWaitForExit(BmeImportExportExe, args);
        }

        private string LoadUsage(string userName, out string[] landedFiles)
        {
            // The only date format FLS supports is yyyy-MM-dd hh:mm:ss tt
            const string dateTimeFormat = "yyyy-MM-dd hh:mm:ss tt";
            var usageStartDate = DateTime.Now.AddMonths(-2).ToString(dateTimeFormat);
            var usageEndDate = DateTime.Now.ToString(dateTimeFormat);

            var controlNumber = ("fls"+env.@TimeStamp());
            landedFiles = (new string[2]);

            // Land usage files to the IncomingFls folder
            var fileName = (controlNumber + ".wobatch.audioconf.txt");
            landedFiles[0] = LandUsageFile(fileName, Resources.fls001_wobatch_audioconf, userName, usageStartDate,
                                           usageEndDate);

            fileName = (controlNumber + ".wobatch.audioleg.txt");
            landedFiles[1] = LandUsageFile(fileName, Resources.fls001_wobatch_audioleg, userName, usageStartDate,
                                           usageEndDate);

            return controlNumber;
        }

        private string LandUsageFile( string fileName, string contentFormat, params object[] args)
        {
            var filePath = Path.Combine(FlsIncomingDirectory, "new", fileName);
            var content = string.Format(contentFormat, args);
            File.WriteAllText(filePath, content);
            return filePath;
        }

        private void AssertUsageProcessed(params string[] landedFiles)
        {
            foreach (var landedFile in landedFiles)
            {
                var fileName = Path.GetFileName(landedFile);
                Assert.IsNotNull(fileName, @"File name of landed usage file[path:""{0}""]", landedFile);
                var processedFile = Path.Combine(FlsIncomingDirectory, "done", fileName);
                var isFileProcessed = PathExt.WaitFileExists(processedFile);
                Assert.IsTrue(isFileProcessed, @"FLS processed usage file[path:""{0}""].", processedFile);
            }
        }

        private void AssertFlsIncomingDirectoryCreated(params string[] names)
        {
            foreach (var name in names)
            {
                var directoryPath = Path.Combine(FlsIncomingDirectory, name);
                var directoryExists = PathExt.WaitDirectoryExists(directoryPath, exists: true);
                Assert.IsTrue(directoryExists, @"FLS created incoming directory[path:""{0}""].", directoryPath);
            }
        }

        #endregion TestHelpers
    }


    public class ComposeMeteringSession
    {   
        private const string OrderCookiesServiceDefinition = "cookies.com/OrderCookies";
        private const string FlatRecurringChargeServiceDefinition = "metratech.com/FlatRecurringCharge";
        private const string NonRecurringChargeServiceDefinition = "metratech.com/NonRecurringCharge";
        private const string AudioConfCallServiceDefinition = "metratech.com/audioConfCall";
        private const string AudioConfConnectionServiceDefinition = "metratech.com/audioConfConnection";
        private const string AudioConfFeatureServiceDefinition = "metratech.com/audioConfFeature";


        public static MeteringSession OrderCookies(string payer, int numberOfCookies, DateTime orderTime)
        {
            var parameters = (new Dictionary<string, object> {
                {"Payer", payer},
                {"NumCookies", numberOfCookies},
                {"CookieType", "chocolatechip"},
                {"Toppings", "MandMs"},
                {"OrderTime", orderTime}
            });
            return (new MeteringSession(OrderCookiesServiceDefinition, parameters));
        }

        public static MeteringSession AudioConfCall(string payer, DateTime usageTime)
        {
            var conferenceId = env.TimeStamp();
            var audioConfCallTime = usageTime.Date.AddHours(15);
            var confCallParameters = (new Dictionary<string, object> {
                {"ConferenceID", conferenceId},
                {"ConferenceName", conferenceId},
                {"ConferenceSubject", conferenceId},
                {"Payer", payer},
                {"AccountingCode", "GL99A"},
                {"OrganizationName", "Ericson"},
                {"SpecialInfo", "Auto start"},
                {"SchedulerComments", "Second conference for tradeshow"},
                {"ScheduledConnections", 1},
                {"ScheduledStartTime", audioConfCallTime},
                {"ScheduledTimeGMTOffset", 5},
                {"ScheduledDuration", 4},
                {"CancelledFlag", "N"},
                {"CancellationTime", audioConfCallTime},
                {"ServiceLevel", "Standard"},
                {"TerminationReason", "Normal"},
                {"SystemName", "Bridge1"},
                {"SalesPersonID", "Amy"},
                {"OperatorID", "Philip"}
            });
            var confCallMeterSession = (new MeteringSession(AudioConfCallServiceDefinition, confCallParameters));
            for (var i = 0; i < 10; i++) {
                var enteredConferenceTime = usageTime.Date.AddHours(15).AddMinutes(2).AddSeconds(3);
                var exitedConferenceTime = usageTime.Date.AddHours(15).AddMinutes(20).AddSeconds(7);
                var disconnectTime = usageTime.Date.AddHours(15).AddMinutes(32).AddSeconds(3);
                var confConnectionParameters = (new Dictionary<string, object> {
                    {"ConferenceID", conferenceId},
                    {"Payer", payer},
                    {"UserBilled", "N"},
                    {"UserName", "FTorres"},
                    {"UserRole", "CSR"},
                    {"OrganizationName", "Ericson"},
                    {"userphonenumber", "781 398 2242"},
                    {"specialinfo", "Expo update"},
                    {"CallType", "Dial-In"},
                    {"transport", "Toll"},
                    {"Mode", "Direct-Dialed"},
                    {"ConnectTime", enteredConferenceTime},
                    {"EnteredConferenceTime", enteredConferenceTime},
                    {"ExitedConferenceTime", exitedConferenceTime},
                    {"DisconnectTime", disconnectTime},
                    {"Transferred", "N"},
                    {"TerminationReason", "Normal"},
                    {"ISDNDisconnectCause", 0},
                    {"TrunkNumber", 10},
                    {"LineNumber", 35},
                    {"DNISDigits", "781 398 2000"},
                    {"ANIDigits", "781 398 2242"}
                });
                confCallMeterSession.AddChildSession(AudioConfConnectionServiceDefinition, confConnectionParameters);
            }
            var confFeatureParameters = (new Dictionary<string, object> {
                {"Payer", payer},
                {"FeatureType", "QA"},
                {"Metric", "33.556122"},
                {"StartTime", usageTime.Date.AddHours(15)},
                {"EndTime", usageTime.Date.AddHours(15).AddMinutes(11)},
                {"TransactionId", conferenceId}
            });
            confCallMeterSession.AddChildSession(AudioConfFeatureServiceDefinition, confFeatureParameters);
            return confCallMeterSession;
        }

        public static MeteringSession
            FlatDailyRc(
                DateTime chargeDate,
                Account account,
                Subscription subsctiption,
                BasePriceableItemInstance priceableItem
            ) {
            var rcStartDate = chargeDate.Date;
            var rcEndtDate = rcStartDate.AddHours(23).AddMinutes(59).AddSeconds(59);
            var parameters =
                (new Dictionary<string, object> {
                    {"RCActionType", "Advance"},
                    {"RCIntervalStart", rcStartDate},
                    {"RCIntervalEnd", rcEndtDate},
                    {"BillingIntervalStart", rcStartDate},
                    {"BillingIntervalEnd", rcEndtDate},
                    {"RCIntervalSubscriptionStart", rcStartDate},
                    {"RCIntervalSubscriptionEnd", rcEndtDate},
                    {"SubscriptionStart", subsctiption.SubscriptionSpan.StartDate.Value},
                    {"SubscriptionEnd", subsctiption.SubscriptionSpan.EndDate.Value},
                    {"Advance", true},
                    {"ProrateOnSubscription", false},
                    {"ProrateInstantly", false},
                    {"ProrateOnUnsubscription", false},
                    {"ProrationCycleLength", 0},
                    {"_AccountID", account._AccountID.Value},
                    {"_PayingAccount", account.PayerID.Value},
                    {"_PriceableItemInstanceID", priceableItem.ID.Value},
                    {"_PriceableItemTemplateID", priceableItem.PITemplate.ID.Value},
                    {"_ProductOfferingID", subsctiption.ProductOfferingId},
                    {"BilledRateDate", chargeDate},
                    {"_SubscriptionID", subsctiption.SubscriptionId.Value}
                });
            return (new MeteringSession(FlatRecurringChargeServiceDefinition, parameters));
        }

        public static MeteringSession
            NonRecurringCharge(
                DateTime chargeDate,
                int accountId,
                Subscription subscription,
                BasePriceableItemInstance priceableItem
            ) {
            var parameters =
                (new Dictionary<string, object> {
                    {"NRCEventType", 1},
                    {"NRCIntervalStart", chargeDate},
                    {"NRCIntervalEnd", chargeDate},
                    {"NRCIntervalSubscriptionStart", subscription.SubscriptionSpan.StartDate.Value},
                    {"NRCIntervalSubscriptionEnd", subscription.SubscriptionSpan.EndDate.Value},
                    {"_AccountID", accountId},
                    {"_PriceableItemInstanceID", priceableItem.ID.Value},
                    {"_PriceableItemTemplateID", priceableItem.PITemplate.ID.Value},
                    {"_ProductOfferingID", subscription.ProductOfferingId},
                    {"_SubscriptionID", subscription.SubscriptionId.Value}
                });
            return (new MeteringSession(NonRecurringChargeServiceDefinition, parameters));
        }        
    }
}