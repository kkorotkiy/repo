﻿using MetraTech.DomainModel.Enums.PaymentSvrClient.Metratech_com_paymentserver;
using MetraTech.DomainModel.MetraPay;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetraTech.TestSystem.Interaction;
using MetraTech.TestComponents;
using MetraTech.TestComponents.MetraNet;
using MetraTech.WebComponents.WebForms;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;
using CreditCardType = MetraTech.DomainModel.Enums.Core.Metratech_com.CreditCardType;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class PaymentMethods : MetraNetTestSuite
    {
        #region Properties and Fields

        private static readonly CreditCardPaymentMethod
            VisaCard = NewCreditCard("4222222222222", CreditCardType.Visa, 1);

        private static readonly CreditCardPaymentMethod
            MasterCard = NewCreditCard("5105105105105100", CreditCardType.MasterCard, 2);

        private static readonly ACHPaymentMethod
            SouthAmericaAch = NewAch("180970068", "South America", 3);

        private static readonly ACHPaymentMethod
            WestIndiaAch = NewAch("160045507", "West of India", 4);

        #endregion

        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraCare that credit card (CC) can be added to a user account.")]
        public void AddCreditCardTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpAddCC");
            var corpAccDisplayName = AccountManager.FormatDisplayName(corpAcc);
            var creditCard =
                (new CreditCardPaymentMethod {
                    CVNumber = "035",
                    CreditCardType = CreditCardType.MasterCard,
                    Priority = 1,
                    ExpirationDate = "09/2022",
                    FirstName = "Henrikh",
                    LastName = "Larson",
                    Street = "New Line Sity, st. 12",
                    City = "Dangaport",
                    ZipCode = "13522"
                });

            var mainPage = WebSite.LogInAsAdmin();
            var paymentMethodsFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: corpAcc.UserName,
                        dropdownValue: corpAccDisplayName,
                        caption: "Account Summary"
                    ).NavigateAccountToolbarToFrame(
                        "Payments",
                        "Payment Methods"
                    );
            var creditCardInfoDataPane =
                NavigateToAddPaymentMethodDataPane(
                    paymentMethodsFrame,
                    buttonCaption: "Add Credit Card",
                    frameCaption: "Add Credit Card",
                    dataPaneCaption: "Credit Card Information"
                    );
            paymentMethodsFrame = PopulateCreditCardProperties(creditCardInfoDataPane, creditCard);

            //====-- VALIDATION STAFF --========

            var creditCardGridRow = ValidateCreditCardGridRow(paymentMethodsFrame, creditCard);
            ValidateCreditCardGridRowDetails(creditCardGridRow, creditCard);
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraCare that credit card (CC) can be edited for a user account.")]
        public void EditCreditCardTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "CorpEditCC");
            var corpAccDisplayName = AccountManager.FormatDisplayName(corpAcc);
            PaymentManager.AssignPaymentMethodToAccount(corpAcc, VisaCard, MasterCard, SouthAmericaAch);
            var creditCard =
                (new CreditCardPaymentMethod {
                    AccountNumber = "5105105105105100", 
                    CreditCardType = CreditCardType.MasterCard,
                    Priority = 2,
                    ExpirationDate = "09/2022",
                });

            var mainPage = WebSite.LogInAsAdmin();
            var paymentMethodsFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: corpAcc.UserName,
                        dropdownValue: corpAccDisplayName,
                        caption: "Account Summary"
                    ).NavigateAccountToolbarToFrame(
                        "Payments",
                        "Payment Methods"
                    );
            var creditCardInfoDataPane =
                NavigateToEditPaymentMethodDataPane(
                    paymentMethodsFrame,
                    creditCard,
                    buttonCaption: "Edit Card",
                    frameCaption: "Update Credit Card",
                    dataPaneCaption: "Credit Card Information"
                    );
            paymentMethodsFrame = UpdateCreditCardProperties(creditCardInfoDataPane, creditCard);

            //====-- VALIDATION STAFF --========

            ValidateCreditCardGridRow(paymentMethodsFrame, creditCard);
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraCare that credit card (CC) can be deleted from a user account.")]
        public void DeleteCreditCardTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "CorpDelCC");
            var corpAccDisplayName = AccountManager.FormatDisplayName(corpAcc);
            PaymentManager.AssignPaymentMethodToAccount(corpAcc, VisaCard, MasterCard, SouthAmericaAch);
            var creditCard =
                (new CreditCardPaymentMethod {
                    AccountNumber = "5105105105105100",
                    CreditCardType = CreditCardType.MasterCard,
                });

            var mainPage = WebSite.LogInAsAdmin();
            var paymentMethodsFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: corpAcc.UserName,
                        dropdownValue: corpAccDisplayName,
                        caption: "Account Summary"
                    ).NavigateAccountToolbarToFrame(
                        "Payments",
                        "Payment Methods"
                    );
            var paymentMethodsDataPane = paymentMethodsFrame.ExpandForm(mt.DataPane, "Payment Methods");
            RemoveCreditCard(paymentMethodsDataPane, creditCard);

            //====-- VALIDATION STAFF --========

            paymentMethodsDataPane
                .WaitLoad()
                .CheckGridRow(
                    Cell("Account Number", creditCard.SafeAccountNumber),
                    exists: false
                );
            WebSite.LogOut();
        }

        
        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraCare that bank account (ACH) can be added to a user account.")]
        public void AddBankAccountTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpAddACH");
            var corpAccDisplayName = AccountManager.FormatDisplayName(corpAcc);
            var ach =
                (new ACHPaymentMethod {
                    RoutingNumber = "091803290",
                    AccountType = BankAccountType.Checking,
                    Priority = 1,
                    FirstName = "Henrikh",
                    LastName = "Larson",
                    Street = "New Line Sity, st. 12",
                    City = "Dangaport",
                    ZipCode = "13522"
                });

            var mainPage = WebSite.LogInAsAdmin();
            var paymentMethodsFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: corpAcc.UserName,
                        dropdownValue: corpAccDisplayName,
                        caption: "Account Summary"
                    ).NavigateAccountToolbarToFrame(
                        "Payments",
                        "Payment Methods"
                    );
            var achInfoDataPane =
                NavigateToAddPaymentMethodDataPane(
                    paymentMethodsFrame,
                    buttonCaption: "Add ACH",
                    frameCaption: "Add ACH",
                    dataPaneCaption: "ACH Information"
                    );
            paymentMethodsFrame = PopulateBankAccountProperties(achInfoDataPane, ach);

            //====-- VALIDATION STAFF --========

            var achGridRow = ValidateBankAccountGridRow(paymentMethodsFrame, ach);
            ValidateBankAccountGridRowDetails(achGridRow, ach);
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraCare that bank account (ACH) can be edited for a user account.")]
        public void EditBankAccountTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", "CorpEditACH");
            var corpAccDisplayName = AccountManager.FormatDisplayName(corpAcc);
            PaymentManager.AssignPaymentMethodToAccount(corpAcc, VisaCard, SouthAmericaAch, WestIndiaAch);
            var ach =
                (new ACHPaymentMethod {
                    AccountNumber = "180970068",
                    RoutingNumber = "180970068",
                    AccountType = BankAccountType.Checking,
                    Priority = 2,
                });

            var mainPage = WebSite.LogInAsAdmin();
            var paymentMethodsFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: corpAcc.UserName,
                        dropdownValue: corpAccDisplayName,
                        caption: "Account Summary"
                    ).NavigateAccountToolbarToFrame(
                        "Payments",
                        "Payment Methods"
                    );
            var achInfoDataPane =
                NavigateToEditPaymentMethodDataPane(
                    paymentMethodsFrame,
                    ach,
                    buttonCaption: "Edit ACH",
                    frameCaption: "Update ACH",
                    dataPaneCaption: "ACH Information"
                    );
            paymentMethodsFrame = UpdateBankAccountProperties(achInfoDataPane, ach);

            //====-- VALIDATION STAFF --========

            ValidateBankAccountGridRow(paymentMethodsFrame, ach);
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraCare that bank account (ACH) can be deleted from a user account.")]
        public void DeleteBankAccountTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", "CorpDelACH");
            var corpAccDisplayName = AccountManager.FormatDisplayName(corpAcc);
            PaymentManager.AssignPaymentMethodToAccount(corpAcc, MasterCard, SouthAmericaAch, WestIndiaAch);
            var ach =
                (new ACHPaymentMethod {
                    AccountNumber = "160045507",
                    RoutingNumber = "160045507",
                    AccountType = BankAccountType.Checking,
                });

            var mainPage = WebSite.LogInAsAdmin();
            var paymentMethodsFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: corpAcc.UserName,
                        dropdownValue: corpAccDisplayName,
                        caption: "Account Summary"
                    ).NavigateAccountToolbarToFrame(
                        "Payments",
                        "Payment Methods"
                    );
            var paymentMethodsDataPane = paymentMethodsFrame.ExpandForm(mt.DataPane, "Payment Methods");
            RemoveBankAccount(paymentMethodsDataPane,ach);

            //====-- VALIDATION STAFF --========

            paymentMethodsDataPane
                .WaitLoad()
                .CheckGridRow(Cell("Account Number", ach.SafeAccountNumber), exists: false)
                ;
            WebSite.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private static CreditCardPaymentMethod
            NewCreditCard(
                string accountNumber,
                CreditCardType creditCardType,
                int priority
            ) {
            return
                (new CreditCardPaymentMethod {
                    City = "City",
                    Country = PaymentMethodCountry.USA,
                    FirstName = "FirstName",
                    LastName = "LastName",
                    MiddleName = "M",
                    MaxChargePerCycle = 10000,
                    Priority = priority,
                    State = "MA",
                    Street = "Street",
                    Street2 = "Street2",
                    ZipCode = "12345",
                    CreditCardType = creditCardType,
                    AccountNumber = accountNumber,
                    CVNumber = "111",
                    ExpirationDate = "12/2017",
                    ExpirationDateFormat = MTExpDateFormat.MT_MM_slash_YYYY,
                    StartDate = "01/20/2013",
                });
        }

        private static ACHPaymentMethod
            NewAch(
                string number,
                string bankName,
                int priority
            ) {
            return
                (new ACHPaymentMethod {
                    City = "City",
                    Country = PaymentMethodCountry.USA,
                    FirstName = "FirstName",
                    LastName = "LastName",
                    MiddleName = "M",
                    MaxChargePerCycle = 10000,
                    Priority = priority,
                    State = "MA",
                    Street = "Street",
                    Street2 = "Street2",
                    ZipCode = "95345",
                    AccountNumber = number,
                    RoutingNumber = number,
                    AccountType = BankAccountType.Checking,
                    BankAddress = "BankAddress",
                    BankCity = "BankCity",
                    BankState = "BankState",
                    BankZipCode = "12345",
                    BankCountry = PaymentMethodCountry.USA,
                    BankName = bankName,
                });
        }


        private static WebForm
            NavigateToAddPaymentMethodDataPane(
                WebForm paymentMethodsFrame,
                string buttonCaption,
                string frameCaption,
                string dataPaneCaption
            ) {
            var addPaymentMethodFrame =
                paymentMethodsFrame.
                    ExpandForm(mt.DataPane, "Payment Methods").
                    Click(_.Button, buttonCaption).
                    Page().GetFrame(frameCaption);

            var paymentMethodInfoDataPane =
                addPaymentMethodFrame.
                    ExpandForm(mt.DataPane, dataPaneCaption);

            return paymentMethodInfoDataPane;
        }

        private static WebForm
            NavigateToEditPaymentMethodDataPane(
                WebForm paymentMethodsFrame,
                MetraPaymentMethod paymentMethod,
                string buttonCaption,
                string frameCaption,
                string dataPaneCaption
            ) {
            var paymentMethodGridRow =
                paymentMethodsFrame.
                    ExpandForm(mt.DataPane, "Payment Methods").
                    FindGridRow(Cell("Account Number", paymentMethod.AccountNumber));

            var paymentMethodInfoDataPane =
                paymentMethodGridRow.
                    Click(_.LinkImage_ByTooltip, buttonCaption).
                    Page().GetFrame(frameCaption).
                    ExpandForm(mt.DataPane, dataPaneCaption);

            return paymentMethodInfoDataPane;
        }

        
        private static WebForm
            PopulateCreditCardProperties(
                WebForm paymentMethodInfoDataPane,
                CreditCardPaymentMethod creditCard
            ) {
            string expirationMonth, expirationYear;
            PaymentManager.
                ParseExpirationDate(
                    creditCard.ExpirationDate,
                    out expirationMonth,
                    out expirationYear
                );
            var cardNumber = env.@TimeStamp("MMddHHmmssffssff");
            creditCard.AccountNumber = cardNumber;
            creditCard.Country = PaymentMethodCountry.US_Virgin_Islands;

            paymentMethodInfoDataPane
                .EnterComboBoxValue(caption: "Priority", value: creditCard.Priority)
                .EnterComboBoxValue(caption: "Credit Card Type", value: creditCard.CreditCardType)
                .EnterTextBoxValue(caption: "Card Number", value: cardNumber)
                .EnterTextBoxValue(caption: "CVN Number", value: creditCard.CVNumber)
                .EnterComboBoxValue(control: mt.ComboBox, caption: "Expiration Date", value: expirationMonth)
                .EnterComboBoxValue(control: mt.ComboBox, caption: "/", value: expirationYear)
                .EnterTextBoxValue(caption: "First Name", value: creditCard.FirstName)
                .EnterTextBoxValue(caption: "Last Name", value: creditCard.LastName)
                .EnterTextBoxValue(caption: "Address Line 1", value: creditCard.Street)
                .EnterTextBoxValue(caption: "City", value: creditCard.City)
                .EnterTextBoxValue(caption: "Zip/Postal Code", value: creditCard.ZipCode)
                .EnterComboBoxValue(caption: "Country", enterValue: "us", dropdownValue: creditCard.CountryValueDisplayName, mode: DataInputMode.Mixed)
                ;
            var paymentMethodsFrame =
                paymentMethodInfoDataPane
                    .SwitchToParentForm()
                    .Click(_.Button, "OK")
                    .Page().GetFrame("Payment Methods")
                    ;
            return paymentMethodsFrame;
        }

        private static WebForm
            UpdateCreditCardProperties(
                WebForm paymentMethodInfoDataPane,
                CreditCardPaymentMethod creditCard
            ) {
            string expirationMonth,expirationYear;
            PaymentManager.
                ParseExpirationDate(
                    creditCard.ExpirationDate,
                    out expirationMonth,
                    out expirationYear
                );
            creditCard.Country = PaymentMethodCountry.St_Helena;
            paymentMethodInfoDataPane
                .EnterComboBoxValue(control: mt.ComboBox, caption: "Expiration Date", value: expirationMonth)
                .EnterComboBoxValue(control: mt.ComboBox, caption: "/", value: expirationYear)
                .EnterComboBoxValue(caption: "Country", enterValue: "st", dropdownValue: creditCard.CountryValueDisplayName, mode: DataInputMode.Mixed)
                ;
            var paymentMethodsFrame =
                paymentMethodInfoDataPane
                    .SwitchToParentForm()
                    .Click(_.Button, "OK")
                    .Page().GetFrame("Payment Methods")
                    ;
            return paymentMethodsFrame;
        }

        private static void
            RemoveCreditCard(
                WebForm paymentMethodsDataPane,
                CreditCardPaymentMethod creditCard
            ) {
            var removeCreditCardFrame =
                paymentMethodsDataPane
                    .FindGridRow(Cell("Account Number", creditCard.AccountNumber))
                    .Click(_.LinkImage_ByTooltip, "Remove Card")
                    .Page().GetFrame("Remove Credit Card")
                    ;
            removeCreditCardFrame.
                CheckDisplayed(_.Label, "Are you sure you want to remove the credit card below?").
                CheckDisplayed(_.Label, creditCard.CreditCardType).
                CheckDisplayed(_.Label, creditCard.AccountNumber).
                Click(_.Button, "Yes");
        }


        private static WebForm
            PopulateBankAccountProperties(
                WebForm paymentMethodInfoDataPane,
                ACHPaymentMethod ach
            ) {
            var achNumber = env.@TimeStamp("MMddHHmmssf");
            ach.AccountNumber = achNumber;
            ach.Country = PaymentMethodCountry.US_Virgin_Islands;
            paymentMethodInfoDataPane
                .EnterComboBoxValue(caption: "Account Type", value: ach.AccountType)
                .EnterTextBoxValue(caption: "Account Number", value: achNumber)
                .EnterTextBoxValue(caption: "Routing Number", value: ach.RoutingNumber)
                .EnterTextBoxValue(caption: "First Name", value: ach.FirstName)
                .EnterTextBoxValue(caption: "Last Name", value: ach.LastName)
                .EnterTextBoxValue(caption: "Address Line 1", value: ach.Street)
                .EnterTextBoxValue(caption: "City", value: ach.City)
                .EnterTextBoxValue(caption: "Zip/Postal Code", value: ach.ZipCode)
                .EnterComboBoxValue(caption: "Country", enterValue: "us", dropdownValue:ach.CountryValueDisplayName, mode: DataInputMode.Mixed)
                ;
            var paymentMethodsFrame =
                paymentMethodInfoDataPane
                    .SwitchToParentForm()
                    .Click(_.Button, "OK")
                    .Page().GetFrame("Payment Methods")
                    ;
            return paymentMethodsFrame;
        }

        private static WebForm
            UpdateBankAccountProperties(
                WebForm paymentMethodInfoDataPane,
                ACHPaymentMethod ach
            ) {
            ach.Country = PaymentMethodCountry.Turkmenistan;
            paymentMethodInfoDataPane
                .EnterComboBoxValue(caption: "Priority", value: ach.Priority)
                .EnterComboBoxValue(caption: "Country", enterValue: "tu", dropdownValue:ach.CountryValueDisplayName, mode: DataInputMode.Mixed)
                ;
            var paymentMethodsFrame =
                paymentMethodInfoDataPane
                    .SwitchToParentForm()
                    .Click(_.Button, "OK")
                    .Page().GetFrame("Payment Methods")
                    ;
            return paymentMethodsFrame;
        }

        private static void
            RemoveBankAccount(
                WebForm paymentMethodsDataPane,
                ACHPaymentMethod ach
            ) {
            var removeAchFrame =
                paymentMethodsDataPane
                    .FindGridRow(Cell("Account Number", ach.SafeAccountNumber))
                    .Click(_.LinkImage_ByTooltip, "Remove ACH")
                    .Page().GetFrame("Remove ACH")
                    ;
            removeAchFrame.
                CheckDisplayed(_.Label, "Are you sure you want to remove the ACH account below?").
                CheckDisplayed(_.Label, ach.SafeAccountNumber).
                Click(_.Button, "Yes");
        }


        private static WebForm
            ValidateCreditCardGridRow(
                WebForm paymentMethodsFrame,
                CreditCardPaymentMethod creditCard
            ) {
            var creditCardInfoDataPane =
                paymentMethodsFrame
                    .ExpandForm(mt.DataPane, "Payment Methods")
                    ;
            var creditCardGridRow =
                creditCardInfoDataPane
                    .FindGridRow(Cell("Account Number", creditCard.AccountNumber))
                    ;
            creditCardGridRow
                .ValidateGridRow(Cell("Card Type", creditCard.CreditCardType))
                .ValidateGridRow(Cell("Exp. Date", creditCard.ExpirationDate))
                .ValidateGridRow(Cell("Priority", creditCard.Priority))
                .ValidateGridRow(Cell("Country", creditCard.CountryValueDisplayName))
                ;
            return creditCardGridRow;
        }

        private static void
            ValidateCreditCardGridRowDetails(
                WebForm creditCardGridRow,
                CreditCardPaymentMethod creditCard
            ) {
            creditCardGridRow.
                Expand().
                ValidateTextFieldValue(caption: "Account Number", expectedValue: creditCard.AccountNumber).
                ValidateTextFieldValue(caption: "Priority", expectedValue: creditCard.Priority).
                ValidateTextFieldValue(caption: "Card Type", expectedValue: creditCard.CreditCardType).
                ValidateTextFieldValue(caption: "Exp. Date", expectedValue: creditCard.ExpirationDate).
                ValidateTextFieldValue(caption: "First Name", expectedValue: creditCard.FirstName).
                ValidateTextFieldValue(caption: "Last Name", expectedValue: creditCard.LastName).
                ValidateTextFieldValue(caption: "Address Line 1", expectedValue: creditCard.Street).
                ValidateTextFieldValue(caption: "City", expectedValue: creditCard.City).
                ValidateTextFieldValue(caption: "Zip / Postal Code", expectedValue: creditCard.ZipCode).
                ValidateTextFieldValue(caption: "Country", expectedValue:creditCard.CountryValueDisplayName).
                Collapse();
        }


        private static WebForm
            ValidateBankAccountGridRow(
                WebForm paymentMethodsFrame,
                ACHPaymentMethod ach
            ) {
            var achInfoDataPane =
                paymentMethodsFrame
                    .ExpandForm(mt.DataPane, "Payment Methods")
                    ;
            var achGridRow =
                achInfoDataPane
                    .FindGridRow(Cell("Account Number", ach.SafeAccountNumber))
                    ;
            achGridRow
                .ValidateGridRow(Cell("Card Type", "ACH"))
                .ValidateGridRow(Cell("Priority", ach.Priority))
                .ValidateGridRow(Cell("Country", ach.CountryValueDisplayName))
                ;
            return achGridRow;
        }

        private static void
            ValidateBankAccountGridRowDetails(
                WebForm achGridRow,
                ACHPaymentMethod ach
            ) {
            achGridRow.
                Expand().
                ValidateTextFieldValue(caption: "Account Number", expectedValue: ach.SafeAccountNumber).
                ValidateTextFieldValue(caption: "Priority", expectedValue: ach.Priority).
                ValidateTextFieldValue(caption: "First Name", expectedValue: ach.FirstName).
                ValidateTextFieldValue(caption: "Last Name", expectedValue: ach.LastName).
                ValidateTextFieldValue(caption: "Address Line 1", expectedValue: ach.Street).
                ValidateTextFieldValue(caption: "City", expectedValue: ach.City).
                ValidateTextFieldValue(caption: "Zip / Postal Code", expectedValue: ach.ZipCode).
                ValidateTextFieldValue(caption: "Country", expectedValue: ach.CountryValueDisplayName).
                Collapse();
        }

        #endregion TestHelpers
    }
}
