﻿using System;
using LogComponents;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetraTech.DomainModel.Enums.Core.Metratech_com_billingcycle;
using MetraTech.DomainModel.BaseTypes;
using MetraTech.DomainModel.ProductCatalog;
using MetraTech.TestComponents.MetraView;
using MetraTech.WebComponents.WebForms;
using MetraTech.TestSystem.Interaction;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mv = MetraTech.WebComponents.WebControls.MetraView;
using usm = MetraTech.TestSystem.Interaction.UsageServerManager;
using CycleType = MetraTech.UsageServer.CycleType;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraNet.AcceptanceTests
{   
    [TestClass]
    public class MetraViewUsageReports : MetraViewTestSuite
    {
        #region TestSuite Setup

        [ClassInitialize]
        public static void SetupTestSuite(TestContext testContext)
        {
            var testSuiteName = FormatQualifiedTestSuiteName(testContext);
            LogManager.LogInfo("BEGIN setup test suite '{0}'.", testSuiteName);

            SetupAccountHierarchy();
            CreateSubscriptions();

            var intervalId = MeterUsages();
            usm.Client.MaterializeBillingGroups(intervalId);
            usm.Client.SoftCloseUsageInterval(intervalId);
            usm.Client.HardCloseUsageInterval(intervalId, ignoreBillingGroups: true);

            //Meter 1 additional AudiConf usage for deparment account in next open interval
            _nextBillingIntervalStartDate = _billingIntervalStartDate.AddDays(1);
            MeteringManager.Meter(ComposeMeteringSession.AudioConfCall(_dep.UserName, _nextBillingIntervalStartDate));

            env.ProlongatePassword(_corp);
            env.ProlongatePassword(_dep);
            LogManager.LogInfo("END setup test suite '{0}'.", testSuiteName);
        }

        #region Account Hierarchy

        private const string AudioConfPoName = "Localized Audio Conference Product Offering USD";
        private const string NrcPoName = "Localized Non Reccuring Charge Product Offering USD";
        private const string RcPoName = "RC_DailyArrNoProPerPart_PO_USD";

        private static Account _corp;
        private static Account _dep;
        private static Account _subscr;

        private static Subscription _nrcSubscription;
        private static Subscription _rcSubscription;

        private static void SetupAccountHierarchy()
        {
            var monthAgo = DateTime.Today.AddDays(-32);

            _corp = AccountManager.AddNewAccount(
                "CorporateAccount.xml",
                userNamePrefix: "CorpMvBillRpt",
                startDate: monthAgo,
                usageCycleType: UsageCycleType.Daily
                );
            CapabilityManager.GrantApplicationLogonCapability(_corp._AccountID.Value,"MPS");

            _dep = AccountManager.AddNewAccount(
                "DepartmentAccount.xml",
                userNamePrefix: "DepMvBillRpt",
                ancestor: _corp,
                payer: _corp,
                startDate: monthAgo,
                usageCycleType: UsageCycleType.Daily
                );
            CapabilityManager.GrantApplicationLogonCapability(_dep._AccountID.Value,"MPS");

            _subscr = AccountManager.AddNewAccount(
                "SubscriberAccount.xml",
                userNamePrefix: "SubscrMvBillRpt",
                ancestor: _dep,
                payer: _corp,
                startDate: monthAgo,
                usageCycleType: UsageCycleType.Daily
                );
        }

        private static void CreateSubscriptions()
        {
            SubscriptionManager.SubscribeAccount(_corp, AudioConfPoName);

            SubscriptionManager.SubscribeAccount(_dep, AudioConfPoName);
            _rcSubscription = SubscriptionManager.SubscribeAccount(_dep, RcPoName);

            SubscriptionManager.SubscribeAccount(_subscr, AudioConfPoName);
            _nrcSubscription = SubscriptionManager.SubscribeAccount(_subscr, NrcPoName);
        }

        #endregion Account Hierarchy

        #region Meter Usages

        private static DateTime _billingIntervalStartDate;
        private static DateTime _nextBillingIntervalStartDate;

        private static int MeterUsages()
        {
            usm.HardCloseAllPastUsageIntervals(
                endDate: DateTime.UtcNow,
                ignoreBillingGroups: true,
                ignoreCycleTypes: CycleType.Daily
                );
            usm.HardCloseAllPastUsageIntervals(
                endDate: _corp.AccountStartDate.Value.Date,
                ignoreBillingGroups: true
                );

            var interval = usm.GetFirstOpenUsageInterval(CycleType.Daily);
            var intervalId = interval.IntervalID;
            _billingIntervalStartDate = interval.StartDate;

            usm.Client.OpenUsageInterval(intervalId, ignoreDeps: true);

            var nrcPi = SubscriptionManager.GetPriceableItemInstance(NrcPoName, "Sub Non Rec Charge");
            var rcPi = SubscriptionManager.GetPriceableItemInstance(RcPoName, "RC_DailyArrNoProPerPart_PI");

            MeteringManager.Meter(
                ComposeMeteringSession.AudioConfCall(_corp.UserName, _billingIntervalStartDate),
                ComposeMeteringSession.AudioConfCall(_dep.UserName, _billingIntervalStartDate),
                ComposeMeteringSession.FlatDailyRc(_billingIntervalStartDate, _dep, _rcSubscription, rcPi),
                ComposeMeteringSession.AudioConfCall(_subscr.UserName, _billingIntervalStartDate),
                ComposeMeteringSession.NonRecurringCharge(_billingIntervalStartDate, _subscr._AccountID.Value, _nrcSubscription, nrcPi)
                );

            return intervalId;
        }

        #endregion Meter Usages

        #endregion TestSuite Setup

        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies that in MetraView different charges are displayed properly in [Detailed View] on ""My reports"" page.")]
        public void UsageReportDetailedViewTest()
        {
           // =======-- BEGIN: LOCAL VARIABLES --=================================================================
            var corpFriendlyUsername = AccountManager.FormatFriendlyUserName(_corp);
            var depFriendlyUsername = AccountManager.FormatFriendlyUserName(_dep);
            var subscrFriendlyUsername = AccountManager.FormatFriendlyUserName(_subscr);

            var usageDateFrom = FormatDateTime(_rcSubscription.SubscriptionSpan.StartDate.Value);
            var usageDateTo = FormatDateTime(_nextBillingIntervalStartDate);
            // =======-- END: LOCAL VARIABLES --===================================================================

            var homePage = WebSite.LogIn(_corp);
            var usageReportPage = homePage.NavigateMetraView(tab: "My Reports");

            //Select timespan for Usage Report starting from subscriptions start date 
            //This allow to see NRC charge because Usage Report shows usage according to day it was consumed, not billed
            //Select end date of timespan for Usage Report - first daily open interval 
            //It allows to see one extra AudiConf charge 
            usageReportPage.
                EnterTextBoxValue(caption: "View usage from", value: usageDateFrom).
                EnterTextBoxValue(caption: "to", value: usageDateTo).
                ClickWithReload(_.Button, caption: "Go");

            usageReportPage.
                GetForm(mv.DataPane, "Charges").
                Click(_.Link, "Detailed View");

            var chargeDetailsDataPane =
                usageReportPage.
                    GetForm(mv.DataPane, "Charge Details");

            // =======-- BEGIN: VALIDATION STAFF --========================================================================

            //For Corporate account one Audiconf charge from closed interval
            var corpNode = chargeDetailsDataPane.NavigateTreeNode(corpFriendlyUsername);
            corpNode.NavigateTreeLeaf("Localized Audio Conference Product Offering USD");
            corpNode.ValidateTreeLeafValue("$ 171.50", "AudioConfCall-Localized");

            //For Deprtment account one Audiconf charge from closed interval and one - metered for next open interval
            //Second charge is daily RC created by on demand trigger, 
            //where expRC - number of days(and accordingly RC charges) in timespan   
            var depNode = corpNode.NavigateTreeNode(depFriendlyUsername);
            depNode.NavigateTreeLeaf("Localized Audio Conference Product Offering USD");
            depNode.ValidateTreeLeafValue("$ 343.00", "AudioConfCall-Localized");
            depNode.NavigateTreeLeaf("RC_DailyArrNoProPerPart_PO_USD");
            depNode.ValidateTreeLeafValue("$ 1.00", "RC_DailyArrNoProPerPart_PI");

            //For CoreSubscriber account one Audiconf charge from closed interval 
            //Second charge is NRC charge created on the day of subscription
            var coreSubscrNode = depNode.NavigateTreeNode(subscrFriendlyUsername);
            coreSubscrNode.NavigateTreeLeaf("Localized Audio Conference Product Offering USD");
            coreSubscrNode.ValidateTreeLeafValue("$ 171.50", "AudioConfCall-Localized");
            coreSubscrNode.NavigateTreeLeaf("Subscribe and Unsubscribe Charges PO - Localized");
            coreSubscrNode.ValidateTreeLeafValue("$ 4.00", "Subscribe Nonrecurring Charges");

            // =======-- END: VALIDATION STAFF --==========================================================================

            usageReportPage.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies that in MetraView different charges are displayed properly in [Summary View] on ""My reports"" page.")]
        public void UsageReportSummaryViewTest()
        {
            var usageDate = FormatDateTime(_billingIntervalStartDate);

            var homePage = WebSite.LogIn(_dep);
            var usageReportPage = homePage.NavigateMetraView(tab: "My Reports");

            //Selected timespan is only for hardclosed interval
            usageReportPage.
                EnterTextBoxValue(caption: "View usage from", value: usageDate).
                EnterTextBoxValue(caption: "to", value: usageDate).
                ClickWithReload(_.Button, caption: "Go");

            var chargesDataPane =
                usageReportPage.
                    GetForm(mv.DataPane, "Charges").
                    CheckDisplayed(_.Link, "Detailed View");

            // =======-- BEGIN: VALIDATION STAFF --========================================================================

            //Two AudiConf charges shown in Summary View 
            //because these are aggregeated for Department and CoreSubscriber 
            chargesDataPane.CheckDisplayed(_.Label, "Localized Audio Conference Product Offering USD");
            chargesDataPane.ValidateTextFieldValue(expectedValue: "$ 343.00", caption: "AudioConfCall-Localized");

            //One RC charge for this particular interval 
            //NOTE!!! no NRC charge shown because it appears at the day of subscription 
            //not in the interval where this charge should be billed
            chargesDataPane.CheckDisplayed(_.Label, "RC_DailyArrNoProPerPart_PO_USD");
            chargesDataPane.ValidateTextFieldValue(expectedValue: "$ 1.00", caption: "RC_DailyArrNoProPerPart_PI");

            // =======-- BEGIN: VALIDATION STAFF --========================================================================

            usageReportPage.LogOut();
        }

        #endregion Tests
    }
}
