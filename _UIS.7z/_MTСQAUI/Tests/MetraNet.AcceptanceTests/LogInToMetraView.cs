﻿using System;
using MetraTech.DomainModel.AccountTypes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UtilityComponents;
using WebComponents;
using WebComponents.WebForms;
using MetraTech.TestSystem.Interaction;
using MetraTech.TestComponents.MetraView;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mv = MetraTech.WebComponents.WebControls.MetraView;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class LoginToMetraView : MetraViewTestSuite
    {
        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies simple MetraView log in operation.")]
        public void LoginToMetraViewTest()
        {
            bool passed;

            #region Check Page "Login"

            var loginPage = WebSite.LoadPage(mv.LoginPage);
            TakeScreenshot("Login Page");

            #endregion Check Page "Login"

            #region Check Page "Home"

            var mvPage =
                loginPage.LogIn(
                    userName: env.MetraViewAdmin.UserName,
                    password: env.MetraViewAdmin.Password_
                    );
            TakeScreenshot("Home Page");

            #endregion Check Page "Home"

            #region Check Page "Bill & Payments"

            passed = CheckMetraViewTab(ref mvPage, "Bill & Payments");
            passed = (CheckMetraViewNestedTab(ref mvPage, "Bill & Payments", "View Bill") && passed);
            passed = (CheckMetraViewNestedTab(ref mvPage, "Bill & Payments", "Billing History") && passed);
            passed = (CheckMetraViewNestedTab(ref mvPage, "Bill & Payments", "Payment Methods") && passed);
            passed = (CheckMetraViewNestedTab(ref mvPage, "Bill & Payments", "Payment History") && passed);
            passed = (CheckMetraViewNestedTab(ref mvPage, "Bill & Payments", "Downloads") && passed);

            #endregion Check Page "Bill & Payments"

            #region Check Page "My Reports"

            passed = (CheckMetraViewTab(ref mvPage, "My Reports") && passed);

            #endregion Check Page "My Reports"

            #region Check Page "Account Info"

            passed = (CheckMetraViewTab(ref mvPage, "Account Info") && passed);
            passed = (CheckMetraViewNestedTab(ref mvPage, "Account Info", "Change Password") && passed);
            passed = (CheckMetraViewNestedTab(ref mvPage, "Account Info", "Regional Settings") && passed);
            passed = (CheckMetraViewNestedTab(ref mvPage, "Account Info", "Invoice Method") && passed);
            passed = (CheckMetraViewNestedTab(ref mvPage, "Account Info", "Account Security") && passed);

            #endregion Check Page "Account Info"

            #region Check Page "My Subscriptions"

            passed = (CheckMetraViewTab(ref mvPage, "My Subscriptions") && passed);

            #endregion Check Page "My Subscriptions"

            #region Check Page "Admin"

            passed = (CheckMetraViewTab(ref mvPage, "Admin") && passed);
            passed = (CheckMetraViewNestedTab(ref mvPage, "Admin", "Configure Site") && passed);
            try {
                var logPage = mvPage.Click(mv.Tab, "Logs").Site().WaitPageOpened();
                TakeScreenshot("Admin.Logs Page");
                logPage.Close();
            } catch (Exception exception) {
                LogUnhandledException(exception);
            } finally {
                mvPage.SwitchToPage();
            }

            #endregion Check Page "Admin"

            #region Check Page "My Activity"

            passed = (CheckMetraViewTab(ref mvPage, "My Activity") && passed);

            #endregion Check Page "My Activity"

            #region Check Page "Logout"

            mvPage.LogOut();
            TakeScreenshot("Logout Page");

            #endregion Check Page "Logout"

            Assert.AreEqual(
                expected: true,
                actual: passed,
                message: @"Check ""MetraView"" website pages."
                );
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies MetraView Dashboard by means of executing test precondition setup and making screenshot for manual analysis.")]
        public void ValidateMetraViewDashboardTest()
        {
            var corpAcc = AccountManager.AddNew<CorporateAccount>("CorporateAccount.xml", userNamePrefix: "corpMvDashboard");
            CapabilityManager.GrantApplicationLogonCapability(corpAcc._AccountID.Value, "MPS");

            var depAcc1 = AccountManager.AddNewAccount("DepartmentAccount.xml", userNamePrefix: "dep1MvDashboard", ancestor: corpAcc);
            var depAcc2 = AccountManager.AddNewAccount("DepartmentAccount.xml", userNamePrefix: "dep2MvDashboard", ancestor: corpAcc);
            var subscrAcc = AccountManager.AddNewAccount("SubscriberAccount.xml", userNamePrefix: "subMvDashboard", ancestor: depAcc1);

            SubscriptionManager.SubscribeAccount(depAcc1, "GROUP_USAGE_Simple_PO");
            SubscriptionManager.SubscribeAccount(depAcc2, "GROUP_USAGE_Simple_PO");
            SubscriptionManager.SubscribeAccount(subscrAcc, "Localized Audio Conference Product Offering USD");

            var accInfo = corpAcc.LDAP[0];
            var expectedAccountInformation =
                (accInfo.FirstName+" "+accInfo.MiddleInitial+" "+accInfo.LastName
                 + "\r\n"+accInfo.Company
                 + "\r\n"+accInfo.Address1
                 + "\r\n"+accInfo.Address2
                 + "\r\n"+accInfo.Address3
                 + "\r\n"+accInfo.City+", "+accInfo.State+"  "+accInfo.Zip
                );          
            //metering usages in order to have data to be displayed on the widgets
            MeteringManager.Meter(
                ComposeMeteringSession.AudioConfCall(subscrAcc.UserName, DateTime.Now),
                ComposeMeteringSession.OrderCookies(depAcc1.UserName, 12, DateTime.Now),
                ComposeMeteringSession.OrderCookies(depAcc2.UserName, 36, DateTime.Now)
                );
            env.ProlongatePassword(corpAcc);

            var homePage = WebSite.LogIn(corpAcc);
            TakeScreenshot("MetraView Dashboard");

            homePage
                .GetForm(mv.DataPane, "Account Information")
                .ValidateElementValue(
                    control: mv.DataPaneInfo,
                    expectedValue: expectedAccountInformation
                );
            homePage.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private bool
            CheckMetraViewTab(
                ref WebPage currentPage,
                string tabName
            ) {
            var screenshotFileName = PathExt.NormalizeFileName(tabName + " Page");
            return LoadMetraViewPage(ref currentPage, tabName, screenshotFileName, isNestedTab: false);
        }

        private bool
            CheckMetraViewNestedTab(
                ref WebPage currentPage,
                string tabName,
                string nestedTabName
            ) {
            var screenshotFileName = PathExt.NormalizeFileName(tabName + "." + nestedTabName + " Page");
            return LoadMetraViewPage(ref currentPage, nestedTabName, screenshotFileName, isNestedTab: true);
        }

        private bool
            LoadMetraViewPage(
                ref WebPage currentPage,
                string tabName,
                string screenshotFileName,
                bool isNestedTab
            ) {
            bool loaded;
            var currentPageUrl = currentPage.PageUrl;
            var currentPageControl = currentPage.Control;
            try {
                if (isNestedTab) {
                    currentPage = currentPage.NavigateMetraView(nestedTab: tabName);
                } else {
                    currentPage = currentPage.NavigateMetraView(tab: tabName);
                }
                TakeScreenshot(screenshotFileName);
                loaded = true;
            } catch (Exception exception) {
                WebBrowser.StopLoading();
                TakeScreenshot(screenshotFileName);
                LogUnhandledException(exception);
                loaded = false;
                currentPage = WebSite.LoadPageFromUrl(currentPageUrl, currentPageControl);
            }
            return loaded;
        }

        #endregion TestHelpers
    }
}
