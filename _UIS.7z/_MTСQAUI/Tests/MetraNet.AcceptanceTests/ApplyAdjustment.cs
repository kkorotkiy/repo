﻿using System;
using MetraTech.DomainModel.AccountTypes;
using MetraTech.DomainModel.BaseTypes;
using MetraTech.DomainModel.Enums.Core.Metratech_com_billingcycle;
using MetraTech.Interop.MTAuth;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebComponents.WebForms;
using MetraTech.TestSystem.Interaction;
using MetraTech.TestComponents;
using MetraTech.TestComponents.MetraNet;
using MetraTech.WebComponents.WebForms;
using CycleType = MetraTech.UsageServer.CycleType;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;
using usm = MetraTech.TestSystem.Interaction.UsageServerManager;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class ApplyAdjustment : MetraNetTestSuite
    {
        #region Constants

        private const string
            MiscAdjustmentCreatedFrameCaption =
                ("A Pending Miscellaneous Adjustment has been created.");

        private const string
            MiscAdjustmentCreatedMessage =
                ("A Pending Miscellaneous Adjustment has been created because an amount greater than the authorized amount has been specified.");

        private const string
            MiscAdjustmentWithCreditNoteCreatedMessage =
                (MiscAdjustmentCreatedMessage+" A credit note for this Miscellaneous Adjustment will be created when this Miscellaneous Adjustment is approved.");

        #endregion Constants

        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies that a CSR account can apply Miscellaneous adjustment.")]
        public void ApplyMiscAdjustmentTest()
        {
            var corpAcc = AccountManager.
                New<CorporateAccount>(
                    "CorporateAccount.xml",
                    userNamePrefix: "corpAdjMisc"
                );
            corpAcc.DayOfMonth = 1;
            AccountManager.AddAccountWithoutWorkflow(ref corpAcc);
            
            var sysAcc = AccountManager.AddNewAccount("SystemAccount.xml", "sysAdjMisc");
            var sysAccId = sysAcc._AccountID.Value;
            CapabilityManager.GrantApplicationLogonCapability(sysAccId, "MAM");
            CapabilityManager.GrantApplyAdjustmentsCapability(sysAccId, MTOperatorType.OPERATOR_TYPE_LESS, 15, "USD");
            CapabilityManager.GrantManageAccountHierarchiesCapability(sysAccId, MTHierarchyPathWildCard.RECURSIVE, corpAcc._AccountID.Value, "WRITE");

            var miscAdjustment =
                (new MiscellaneousAdjustment(
                    status: "PENDING",
                    reasonCode: "DroppedCall",
                    billingPeriodStartDate: DateTime.UtcNow,
                    issueCreditNote: false,
                    creditNoteTemplate: "Credit Note Report",
                    amount: 0.91M,
                    taxFederal: 1.17M,
                    taxState: 2.21M,
                    taxCounty: 3.24M,
                    taxLocal: 4.35M,
                    taxOther: 3.13M
                    ));

            var createAdjustmentFrame =
                WebSite.LogIn(sysAcc, changePassword: true)
                    .LoadAccountSummaryFrame(
                        enterValue: corpAcc.UserName
                    ).NavigateAccountToolbarToFrame(
                        menu: "Adjustments / Charges",
                        menuItem: "Misc. Adjustments"
                    );
            var adjustmentCreatedFrame =
                IssueMiscAdjustment(
                    createAdjustmentFrame,
                    miscAdjustment
                    );

            //====- VALIDATION STAFF -========

            var miscAdjustmentCreatedMessage =
                (miscAdjustment.IssueCreditNote
                     ? MiscAdjustmentWithCreditNoteCreatedMessage
                     : MiscAdjustmentCreatedMessage
                );
            adjustmentCreatedFrame.
                CheckDisplayed(_.Label, miscAdjustmentCreatedMessage).
                DisposeByClick(_.Button, "OK");

            var manageAdjustmentsFrame =
                WebSite.Page().LogOut().LogIn(env.MetraNetAdmin)
                    .NavigateMetraSidebarToFrame(
                        metraMenu: "MetraCare",
                        menu: "Adjustments / Charges",
                        menuItem: "Misc. Adjustments"
                    );
            var adjustmentGridRow =
                manageAdjustmentsFrame.
                    ExpandForm(mt.DataPane, "Manage Miscellaneous Adjustments").
                    FindGridRow(Cell("Internal Description", miscAdjustment.DescriptionInternal));

            ValidateMiscAdjustmentGridRow(
                adjustmentGridRow,
                corpAcc,
                corpAcc.Internal,
                miscAdjustment
                );
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies that a Prebill adjustment could be provisioned to transactions in Open Billing interval.")]
        public void ApplyPrebillAdjustmentsTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpAdjPre");
            var depAcc = AccountManager.AddNewAccount("DepartmentAccount.xml", userNamePrefix: "depAdjPre", ancestor: corpAcc);
            var subscrAcc = AccountManager.
                AddNew<CoreSubscriber>(
                    "SubscriberAccount.xml",
                    userNamePrefix: "subAdjPre",
                    ancestor: depAcc,
                    usageCycleType: UsageCycleType.Daily
                );
            SubscriptionManager.SubscribeAccount(subscrAcc, "GROUP_USAGE_Simple_PO");
            MeteringManager.Meter(ComposeMeteringSession.OrderCookies(subscrAcc.UserName, 12, DateTime.Now));

            var description = ("Prebill Adjustment ("+env.@TimeStamp()+")");
            var startDate = @Today(addDays: -1);
            var endDate = @Today(addYears: 4);
            var amount = 5M;
            var pricableItem = "OrderCookies";

            var mainPage = WebSite.LogInAsAdmin();

            var transactionFinderFrame =
                mainPage.
                    LoadAccountSummaryFrame(
                        enterValue: subscrAcc.UserName
                    ).NavigateAccountToolbarToFrame_1(
                        menu: "Adjustments / Charges",
                        menuItem: "Bulk Adjustments"
                    );

            var foundTransactionFrame =
                transactionFinderFrame.
                    EnterDropBoxValue(control: mt.DropBox_1, caption: "Search for transactions where account ", value: "Payer", dropDown: false).
                    EnterCheckBoxValue(caption: "Fixed Date", value: true).
                    EnterTextBoxValue(control: mt.TextBox_1, caption: "Start Date", value: startDate).
                    EnterTextBoxValue(control: mt.TextBox_1, caption: "End Date", value: endDate).
                    EnterDropBoxValue(control: mt.DropBox_1, caption: "Priceable Item", value: pricableItem, dropDown: false).
                    WaitLoad().
                    ClickWithReload(_.Button, "OK");

            var createBulkAdjustmentFrame =
                foundTransactionFrame.
                    ClickWithReload(_.Button, "Select All").
                    ClickWithReload(_.Button, "Adjust Selected Transactions");

            var adjustmentCreatedFrame =
                createBulkAdjustmentFrame.
                    EnterTextBoxValue(control: mt.TextBox_1, caption: "Adjustment Amount For Total Cookies Cost", value: amount).
                    EnterTextBoxValue(control: mt.TextBox_1, caption: "Description", value: description).
                    ClickWithReload(_.Button, "Compute").
                    ClickWithReload(_.Button, "Save");

            //====- VALIDATION STAFF -========

            adjustmentCreatedFrame.
                CheckDisplayed(_.Label, "The Adjustment(s) have been approved").
                DisposeByClick(_.Button, "Close");

            var manageAdjustmentsFrame =
                mainPage.
                    NavigateMetraSidebarToFrame(
                        metraMenu: "MetraCare",
                        menu: "Adjustments / Charges",
                        menuItem: "Adjustments"
                    );
            var adjustmentGridRow =
                manageAdjustmentsFrame.
                    ExpandForm(mt.DataPane, "Search Filters").
                    Click(_.Button, "Search").
                    SwitchToParentForm(waitLoad:true).
                    ExpandForm(mt.DataPane, "Manage Adjustments").
                    FindGridRow(Cell("Adjustment Description", description));

            ValidateAdjustmentGridRow(
                adjustmentGridRow,
                subscrAcc,
                subscrAcc.Internal,
                "Prebill",
                description,
                amount,
                pricableItem
                );
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies that a Postbill adjustment could be provisioned to transactions in Hard Closed Billing interval.")]
        public void ApplyPostbillAdjustmentsTest()
        {
            var monthAgo = DateTime.UtcNow.AddDays(-32);

            var corpAcc = AccountManager.
                AddNew<CorporateAccount>(
                    "CorporateAccount.xml",
                    userNamePrefix: "corpAdjPost",
                    startDate: monthAgo,
                    usageCycleType: UsageCycleType.Daily
                );
            SubscriptionManager.SubscribeAccount(corpAcc, "Localized Audio Conference Product Offering USD");

            var intervalStartDate = BillUsageTransaction(corpAcc);

            var description = ("Postbill Adjustments ("+env.@TimeStamp()+")");
            var amount = 10M;
            var billingPeriod = FormatBillingPeriod(intervalStartDate);
            var pricableItem = "AudioConfCall";


            var mainPage = WebSite.LogInAsAdmin();

            var transactionFinderFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: corpAcc.UserName
                    ).NavigateAccountToolbarToFrame_1(
                        menu: "Adjustments / Charges",
                        menuItem: "Bulk Adjustments"
                    );
            var foundTransactionFrame =
                transactionFinderFrame.
                    EnterCheckBoxValue(caption: "Billing Interval", value: true).
                    EnterDropBoxValue(control: mt.DropBox_1, caption: "Search for transactions where account ", value: "Payer", dropDown: false).
                    EnterDropBoxValue(control: mt.DropBox_1, caption: "Period", value: billingPeriod, dropDown: false).
                    EnterDropBoxValue(control: mt.DropBox_1, caption: "Priceable Item", value: pricableItem, dropDown: false).
                    WaitLoad().
                    ClickWithReload(_.Button, "OK");

            var createBulkAdjustmentFrame =
                foundTransactionFrame.
                    ClickWithReload(_.Button, "Select All").
                    ClickWithReload(_.Button, "Adjust Selected Transactions");

            var adjustmentCreatedFrame =
                createBulkAdjustmentFrame.
                    EnterDropBoxValue(control: mt.DropBox_1, caption: "Adjustment Type", value: "Audio Conference Call Flat Adjustment Display").
                    EnterTextBoxValue(control: mt.TextBox_1, caption: "Adjustment Amount for Cancellation Charges", value: amount).
                    EnterTextBoxValue(control: mt.TextBox_1, caption: "Adjustment Amount for Overused Port Charges", value: amount).
                    EnterTextBoxValue(control: mt.TextBox_1, caption: "Adjustment Amount for Reservation Charges", value: amount).
                    EnterTextBoxValue(control: mt.TextBox_1, caption: "Adjustment Amount for Unused Port Charges", value: amount).
                    EnterTextBoxValue(control: mt.TextBox_1, caption: "Description", value: description).
                    ClickWithReload(_.Button, "Compute").
                    ClickWithReload(_.Button, "Save");

            //====- VALIDATION STAFF -========

            adjustmentCreatedFrame.
                CheckDisplayed(_.Label, "The Adjustment(s) have been approved").
                DisposeByClick(_.Button, "Close");

            var manageAdjustmentsFrame =
                mainPage.
                    NavigateMetraSidebarToFrame(
                        metraMenu: "MetraCare",
                        menu: "Adjustments / Charges",
                        menuItem: "Adjustments"
                    );
            var adjustmentGridRow =
                manageAdjustmentsFrame.
                    ExpandForm(mt.DataPane, "Search Filters").
                    Click(_.Button, "Search").
                    SwitchToParentForm(waitLoad: true).
                    ExpandForm(mt.DataPane, "Manage Adjustments").
                    FindGridRow(Cell("Adjustment Description", description));

            ValidateAdjustmentGridRow(
                adjustmentGridRow,
                corpAcc,
                corpAcc.Internal,
                "Postbill",
                description,
                amount,
                pricableItem
                );
            WebSite.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private struct MiscellaneousAdjustment {
            public readonly DateTime CreateDate;
            public readonly string Status;

            public readonly string ReasonCode;
            public readonly string DescriptionInternal;
            public readonly string DescriptionSubscriber;

            public readonly DateTime BillingPeriodStartDate;

            public readonly bool IssueCreditNote;
            public readonly string CreditNoteTemplate;
            public readonly string Comment;

            public readonly decimal Amount;
            public readonly decimal TaxFederal;
            public readonly decimal TaxState;
            public readonly decimal TaxCounty;
            public readonly decimal TaxLocal;
            public readonly decimal TaxOther;
            public readonly decimal Total;


            public MiscellaneousAdjustment(
                    string status,
                    string reasonCode,
                    DateTime billingPeriodStartDate,
                    bool issueCreditNote,
                    string creditNoteTemplate,
                    decimal amount,
                    decimal taxFederal,
                    decimal taxState,
                    decimal taxCounty,
                    decimal taxLocal,
                    decimal taxOther
                ) : this() {
                CreateDate = DateTime.UtcNow;
                Status = status;

                ReasonCode = reasonCode;

                var timeStamp = env.@TimeStamp();
                var description = ("Misc.Adjustment ("+timeStamp+")");
                DescriptionSubscriber = ("Subscriber "+description);
                DescriptionInternal = ("Internal "+description);

                BillingPeriodStartDate = CalculateBillingPeriodStartDate(billingPeriodStartDate);

                IssueCreditNote = issueCreditNote;
                CreditNoteTemplate = creditNoteTemplate;
                Comment = ("Comment ("+timeStamp+")");

                Amount = amount;
                TaxFederal = taxFederal;
                TaxState = taxState;
                TaxCounty = taxCounty;
                TaxLocal = taxLocal;
                TaxOther = taxOther;
                Total = (Amount + TaxFederal + TaxState + TaxCounty + TaxLocal + TaxOther);
            }


            private static DateTime
                CalculateBillingPeriodStartDate(
                    DateTime billingPeriodStartDate
                ) {
                int startDay = billingPeriodStartDate.Day, addDays, addMonths = 0;
                if (startDay < 2) {
                    addDays = 1;
                    addMonths = -1;
                } else {
                    addDays = (2-startDay);
                }
                billingPeriodStartDate = DateTime.UtcNow.AddDays(addDays).AddMonths(addMonths);
                return billingPeriodStartDate;
            }
        }

        
        private string FormatBillingPeriod(DateTime dailyIntervalDate)
        {
            var billingPeriod = FormatDate(dailyIntervalDate);
            var billingPeriodFormat = (billingPeriod+" Through "+billingPeriod);
            return billingPeriodFormat;
        }

        private DateTime BillUsageTransaction(Account account)
        {
            usm.HardCloseAllPastUsageIntervals(
                endDate: DateTime.UtcNow,
                ignoreBillingGroups: true,
                ignoreCycleTypes: CycleType.Daily
                );
            usm.HardCloseAllPastUsageIntervals(
                endDate: account.AccountStartDate.Value.Date,
                ignoreBillingGroups: true
                );
            var interval = usm.GetFirstOpenUsageInterval(CycleType.Daily);
            var intervalId = interval.IntervalID;
            var intervalStartDate = interval.StartDate;

            usm.Client.OpenUsageInterval(intervalId, ignoreDeps: true);
            MeteringManager.Meter(ComposeMeteringSession.AudioConfCall(account.UserName, intervalStartDate));
            usm.Client.MaterializeBillingGroups(intervalId);
            usm.Client.HardCloseUsageInterval(intervalId, ignoreBillingGroups: true);

            return intervalStartDate;
        }

        private WebForm
            IssueMiscAdjustment(
                WebForm createAdjustmentFrame,
                MiscellaneousAdjustment miscAdjustment
            ) {
            var billingPeriod = FormatDate(miscAdjustment.BillingPeriodStartDate);
            createAdjustmentFrame.
                ExpandForm(mt.DataPane, "Issue Miscellaneous Adjustment").
                EnterTextBoxValue(caption: "Amount", value: @Number(miscAdjustment.Amount)).
                EnterTextBoxValue(caption: "Federal Tax", value: @Number(miscAdjustment.TaxFederal)).
                EnterTextBoxValue(caption: "State Tax", value: @Number(miscAdjustment.TaxState)).
                EnterTextBoxValue(caption: "County Tax", value: @Number(miscAdjustment.TaxCounty)).
                EnterTextBoxValue(caption: "Local Tax", value: @Number(miscAdjustment.TaxLocal)).
                EnterTextBoxValue(caption: "Other Tax", value: @Number(miscAdjustment.TaxOther)).
                ValidateTextBoxValue(caption: "Total Adjustment Being Issued", expectedValue: @Number(miscAdjustment.Total)).
                EnterComboBoxValue(caption: "Reason Code", value: miscAdjustment.ReasonCode).
                EnterTextBoxValue(caption: "Internal Description", value: miscAdjustment.DescriptionInternal).
                EnterTextBoxValue(caption: "Invoice Description", value: miscAdjustment.DescriptionSubscriber).
                EnterComboBoxValue(caption: "Billing Period", value: billingPeriod);

            if (miscAdjustment.IssueCreditNote) {
                createAdjustmentFrame.
                    ExpandForm(mt.DataPane, "Issue Credit Note For This Adjustment").
                    EnterCheckBoxValue(caption: "Issue Credit Note For This Adjustment", value: true).
                    EnterComboBoxValue(caption: "Credit Note Template To Use", value: miscAdjustment.CreditNoteTemplate).
                    EnterTextBoxValue(caption: "Comment", value: miscAdjustment.Comment);
            }

            var adjustmentCreatedFrame =
                createAdjustmentFrame.
                    Click(_.Button, "OK").
                    Page().GetFrame(MiscAdjustmentCreatedFrameCaption);

            return adjustmentCreatedFrame;
        }

        private void
            ValidateMiscAdjustmentGridRow(
                WebForm miscAdjustmentGridRow,
                Account account,
                InternalView accountInternalView,
                MiscellaneousAdjustment miscAdjustment
              ) {
            var accountId = account._AccountID;
            var accountCurrency = accountInternalView.Currency;

            miscAdjustmentGridRow.
                ValidateGridRow(Cell("Subscriber Account Id", accountId)).
                ValidateGridRow(Cell("Internal Description", miscAdjustment.DescriptionInternal)).
                ValidateGridRow(Cell("Reason", miscAdjustment.ReasonCode)).
                ValidateGridRow(Cell("Amount", @Number(-1*miscAdjustment.Amount))).
                ValidateGridRow(Cell("Federal Tax", @Number(-1*miscAdjustment.TaxFederal))).
                ValidateGridRow(Cell("State Tax", @Number(-1*miscAdjustment.TaxState))).
                ValidateGridRow(Cell("County Tax", @Number(-1*miscAdjustment.TaxCounty))).
                ValidateGridRow(Cell("Local Tax", @Number(-1*miscAdjustment.TaxLocal))).
                ValidateGridRow(Cell("Other Tax", @Number(-1*miscAdjustment.TaxOther))).
                ValidateGridRow(Cell("Adjustment Create Date", FormatDate(miscAdjustment.CreateDate))).
                ValidateGridRow(Cell("Adjustment Amount", @Number(-1*miscAdjustment.Total))).
                ValidateGridRow(Cell("Currency", accountCurrency)).
                ValidateGridRow(Cell("Status", miscAdjustment.Status));

            miscAdjustmentGridRow.
                Expand().
                ValidateTextFieldValue(caption: "Subscriber Account Id", expectedValue: accountId).
                ValidateTextFieldValue(caption: "Currency", expectedValue: accountCurrency).
                ValidateTextFieldValue(caption: "Amount", expectedValue: @Number(-1*miscAdjustment.Amount)).
                ValidateTextFieldValue(caption: "Federal Tax", expectedValue: @Number(-1*miscAdjustment.TaxFederal)).
                ValidateTextFieldValue(caption: "State Tax", expectedValue: @Number(-1*miscAdjustment.TaxState)).
                ValidateTextFieldValue(caption: "County Tax", expectedValue: @Number(-1*miscAdjustment.TaxCounty)).
                ValidateTextFieldValue(caption: "Local Tax", expectedValue: @Number(-1*miscAdjustment.TaxLocal)).
                ValidateTextFieldValue(caption: "Other Tax", expectedValue: @Number(-1*miscAdjustment.TaxOther)).
                ValidateTextFieldValue(caption: "Adjustment Create Date", expectedValue: FormatDate(miscAdjustment.CreateDate)).
                ValidateTextFieldValue(caption: "Internal Description", expectedValue: miscAdjustment.DescriptionInternal).
                ValidateTextFieldValue(caption: "Reason", expectedValue: miscAdjustment.ReasonCode).
                ValidateTextFieldValue(caption: "Adjustment Amount", expectedValue: @Number(-1*miscAdjustment.Total)).
                ValidateTextFieldValue(caption: "Status", expectedValue: miscAdjustment.Status).
                Collapse();
        }

        private void
            ValidateAdjustmentGridRow(
                WebForm adjustmentGridRow,
                Account account,
                InternalView accountInternalView,
                string adjustmentType,
                string description,
                decimal amount,
                string pricableItem
            ) {
            var accountUserName = account.UserName;
            var accountCurrency = accountInternalView.Currency;

            var creationDate = TodayUtc();
            var amountValue = (-1*amount);
            var amountColumnName = (adjustmentType+" Adjustment Amount");


            adjustmentGridRow.
                ValidateGridRow(Cell("Adjustment Creation Date", creationDate)).
                ValidateGridRow(Cell(amountColumnName, amountValue)).
                ValidateGridRow(Cell("Payee Username", accountUserName)).
                ValidateGridRow(Cell("Priceable Item", pricableItem));

            adjustmentGridRow.
                Expand().
                ValidateTextFieldValue(caption: "AdjustmentCurrency", expectedValue: accountCurrency).
                ValidateTextFieldValue(caption: "Description", expectedValue: description).
                ValidateTextFieldValue(caption: "PITemplateDisplayName", expectedValue: pricableItem).
                ValidateTextFieldValue(caption: "UserNamePayee", expectedValue: accountUserName).
                Collapse();
        }

        #endregion TestHelpers
    }
}
