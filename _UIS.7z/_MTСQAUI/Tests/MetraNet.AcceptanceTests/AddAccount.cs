﻿using MetraTech.DomainModel.AccountTypes;
using MetraTech.DomainModel.BaseTypes;
using MetraTech.DomainModel.Enums.Core.Global;
using MetraTech.DomainModel.Enums.Core.Metratech_com_billingcycle;
using MetraTech.DomainModel.Enums.Tax.Metratech_com_tax;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebComponents.WebForms;
using MetraTech.TestSystem.Interaction;
using MetraTech.TestComponents.MetraNet;
using MetraTech.WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class AddAccount : MetraNetTestSuite
    {
        #region Constants

        private const string DefaultParentAccountDisplayName = "Hierarchy Root (1)";

        #endregion Constants

        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies that a CSR account can be added through UI.")]
        public void AddCsrAccountTest()
        {
            var userName = ("Csr"+env.@TimeStamp());

            var mainPage = WebSite.LogInAsAdmin();

            var addAccountFrame =
                mainPage.NavigateMetraSidebarToFrame(
                    metraMenu: "MetraCare",
                    menu: "Manage Accounts",
                    menuItem: "Add CSR",
                    caption: "Add System User"
                    );
            var accountCreatedFrame =
                PopulateAccountDefaults(
                    addAccountFrame,
                    userName,
                    validate: false
                    );

            //=========-- VALIDATION STAFF --==================

            var accountSummaryFrame = ValidateAccountCreatedFrame(accountCreatedFrame);
            ValidateAccountDefaults(accountSummaryFrame, userName);
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies that a Partition account can be added through UI.")]
        public void AddPartitionAccountTest()
        {
            var userName = ("Part"+env.@TimeStamp());

            var mainPage = WebSite.LogInAsAdmin();

            var addAccountFrame =
                mainPage.NavigateMetraSidebarToFrame(
                    metraMenu: "MetraCare",
                    menu: "Manage Accounts",
                    menuItem: "Add Partition",
                    caption: "Add Partition"
                    );
            PopulateAccountDefaults(
                    addAccountFrame,
                    userName,
                    validate: true,
                    submit: false
                    );
            addAccountFrame.
                ExpandForm(mt.DataPane, "Containers to be created").
                EnterCheckBoxValue(caption: "Resellers", value: true).
                EnterCheckBoxValue(caption: "Channels", value: true)
                ;
            var accountCreatedFrame =
                addAccountFrame.
                    Click(_.Button, "OK").
                    Page(waitLoad: true).GetFrame("Account Created");

            //=========-- VALIDATION STAFF --==================

            var accountSummaryFrame = ValidateAccountCreatedFrame(accountCreatedFrame);
            ValidateAccountDefaults(accountSummaryFrame, userName);

            var accountSidebar =
                accountSummaryFrame
                    .Page().Click(mn.ToolButton_HierarchyFind)
                    .GetForm(mn.Sidebar, "east")
                    ;
            accountSidebar
                .ExpandForm(mt.TreeNode, "Hierarchy")
                .ExpandForm(mt.TreeNode, userName)
                .CheckDisplayed(mt.TreeLeaf, "Resellers")
                .CheckDisplayed(mt.TreeLeaf, "Channels")
                .ExpandForm(mt.TreeNode, "System Users")
                .CheckDisplayed(mt.TreeLeaf, (userName+" Admin"))
                .Collapse()
                ;
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies that an Independent account can be added through UI.")]
        public void AddIndependentAccountTest()
        {
            var userName = ("Indep"+env.@TimeStamp());

            var mainPage = WebSite.LogInAsAdmin();

            var addAccountFrame =
                mainPage.NavigateMetraSidebarToFrame(
                    metraMenu: "MetraCare",
                    menu: "Manage Accounts",
                    menuItem: "Add Account"
                    );
            PopulateAccountType(
                addAccountFrame,
                accountType: "IndependentAccount"
                );
            var accountCreatedFrame =
                PopulateAccountDefaults(
                    addAccountFrame,
                    userName
                    );

            //=========-- VALIDATION STAFF --==================

            var accountSummaryFrame = ValidateAccountCreatedFrame(accountCreatedFrame);
            ValidateAccountDefaults(accountSummaryFrame, userName);
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies that a Corporate account can be added through UI.")]
        public void AddCorporateAccountTest()
        {
            var userName = ("Corp"+env.@TimeStamp());

            var mainPage = WebSite.LogInAsAdmin();

            var addAccountFrame =
                mainPage.NavigateMetraSidebarToFrame(
                    metraMenu: "MetraCare",
                    menu: "Manage Accounts",
                    menuItem: "Add Account"
                    );
            PopulateAccountType(
                addAccountFrame,
                accountType: "CorporateAccount"
                );
            var accountCreatedFrame =
                PopulateAccountDefaults(
                    addAccountFrame,
                    userName,
                    DefaultParentAccountDisplayName
                    );

            //=========-- VALIDATION STAFF --==================

            var accountSummaryFrame = ValidateAccountCreatedFrame(accountCreatedFrame);
            ValidateAccountDefaults(accountSummaryFrame, userName);
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies that a Department account can be added through UI.")]
        public void AddDepartmentAccountTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix:"corpAddDep");
            var corpAccDisplayName = AccountManager.FormatDisplayName(corpAcc, friendly:true);

            var userName = ("Dep"+env.@TimeStamp());

            var mainPage = WebSite.LogInAsAdmin();

            var addAccountFrame =
                mainPage.NavigateMetraSidebarToFrame(
                    metraMenu: "MetraCare",
                    menu: "Manage Accounts",
                    menuItem: "Add Account"
                    );
            PopulateAccountType(
                addAccountFrame,
                accountType: "DepartmentAccount"
                );
            var accountCreatedFrame =
                PopulateAccountDefaults(
                    addAccountFrame,
                    userName,
                    parentAccountDisplayName: corpAccDisplayName
                    );

            //=========-- VALIDATION STAFF --==================

            var accountSummaryFrame = ValidateAccountCreatedFrame(accountCreatedFrame);
            ValidateAccountDefaults(accountSummaryFrame, userName, corpAccDisplayName);
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies that a CoreSubscriber account can be added through UI.")]
        public void AddCoreSubscriberAccountTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpAddSubAcc");
            var depAcc = AccountManager.AddNewAccount("DepartmentAccount.xml", userNamePrefix: "depAddSubAcc", ancestor: corpAcc);
            var depAccDisplayName = AccountManager.FormatDisplayName(depAcc, friendly:true);

            var userName = ("Subscr"+env.@TimeStamp());

            var mainPage = WebSite.LogInAsAdmin();

            var addAccountFrame =
                mainPage.NavigateMetraSidebarToFrame(
                    metraMenu: "MetraCare",
                    menu: "Manage Accounts",
                    menuItem: "Add Account"
                    );
            PopulateAccountType(
                addAccountFrame,
                accountType: "CoreSubscriber"
                );
            PopulateAccountDefaults(
                addAccountFrame,
                userName,
                parentAccountDisplayName: depAccDisplayName,
                submit: false
                );
            var subscrAcc = PopulateAccountProperties(addAccountFrame);

            var accountCreatedFrame =
                addAccountFrame
                    .Click(_.Button, "OK")
                    .Page(waitLoad: true)
                    .GetFrame("Account Created");

            //=========-- VALIDATION STAFF --==================

            var accountSummaryFrame = ValidateAccountCreatedFrame(accountCreatedFrame);
            ValidateAccountDefaults(accountSummaryFrame, userName, depAccDisplayName);
            ValidateAccountProperties(accountSummaryFrame, subscrAcc);
            WebSite.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private static void PopulateAccountType(WebForm addAccountFrame, string accountType)
        {
            addAccountFrame
                .GetForm(mt.DataPane, "Select Account Type")
                .EnterComboBoxValue(caption: "Select account type to create", value: accountType)
                ;
            addAccountFrame.ClickWithReload(_.Button, "OK");
        }

        private static WebForm
            PopulateAccountDefaults(
                WebForm addAccountFrame,
                string userName,
                string parentAccountDisplayName = null,
                bool validate = true,
                bool submit = true
            ) {
            var loginInfoDataPane =
                addAccountFrame
                    .ExpandForm(mt.DataPane, "Login Information")
                    .EnterTextBoxValue(caption: "User Name", value: userName)
                    ;
            if (validate) {
                loginInfoDataPane.
                    Click(_.Button, "Validate").
                    CheckDisplayed(_.Label, "User Name OK");
            }
            loginInfoDataPane.Click(_.Button, "Generate");
            if (parentAccountDisplayName != null) {
                loginInfoDataPane.EnterFindBoxValue(caption: "Parent Account", value: parentAccountDisplayName, mode: DataInputMode.Enter);
            }
            if (submit) {
                var accountCreatedFrame =
                    addAccountFrame
                        .Click(_.Button, "OK")
                        .Page(waitLoad: true).GetFrame("Account Created")
                        ;
                return accountCreatedFrame;
            }
            return addAccountFrame;
        }

        private static Account PopulateAccountProperties(WebForm addAccountFrame)
        {
            var account = AccountManager.New<CoreSubscriber>("SubscriberAccount.xml", usageCycleType:UsageCycleType.Daily);
            var contactView = AccountManager.GetAccountContactView(account);
            contactView.FirstName = "Core Subscriber";
            contactView.Email = "corporate@mail.net";
            contactView.City = "New York";
            contactView.Country = CountryName.St__Vincent_Grenadines;
            account.Internal.TaxVendor = TaxVendor.VertexQ;
            account.Internal.MetraTaxHasOverrideBand = true;

            addAccountFrame
                .ExpandForm(mt.DataPane, "Billing Information")
                .EnterTextBoxValue(caption: "First Name", value: contactView.FirstName)
                .EnterTextBoxValue(caption: "Email", value:contactView.Email)
                .EnterTextBoxValue(caption: "City", value:contactView.City)
                .EnterComboBoxValue(caption: "Country", enterValue: "St.", dropdownValue: contactView.CountryValueDisplayName, mode: DataInputMode.Mixed)
                ;
            addAccountFrame
                .ExpandForm(mt.DataPane, "Account Information")
                .EnterComboBoxValue(caption: "Billing Cycles", value:account.Internal.UsageCycleTypeValueDisplayName)
                ;
            addAccountFrame
                .ExpandForm(mt.DataPane, "Tax")
                .EnterCheckBoxValue(caption: "MetraTax Has Override Band", value: account.Internal.MetraTaxHasOverrideBand)
                .EnterComboBoxValue(caption: "Tax Vendor", value: account.Internal.TaxVendorValueDisplayName, mode: DataInputMode.Submit)
                ;
            return account;
        }

        private static WebForm ValidateAccountCreatedFrame(WebForm accountCreatedFrame)
        {
            accountCreatedFrame
                .GetForm(mt.DataPane, "Account Created")
                .CheckDisplayed(_.Label, "The account was created successfully.")
                ;
            var accountSummaryFrame =
                accountCreatedFrame.
                    Click(_.Button, "Manage Newly Created Account").
                    Page(waitLoad: true).
                    GetFrame("Account 360").
                    NavigateAccountToolbarToFrame(
                        menu: "Account",
                        menuItem: "Account Details",
                        caption: "Account Summary"
                    );
            return accountSummaryFrame;
        }

        private static void
            ValidateAccountDefaults(
                WebForm accountSummaryFrame,
                string userName,
                string parentAccountDisplayName = DefaultParentAccountDisplayName
            ) {
            accountSummaryFrame.
                ExpandForm(mt.DataPane, "Login Information").
                ValidateTextBoxValue(caption: "User name", expectedValue:userName).
                ValidateTextFieldValue(caption: "Parent Id", expectedValue:parentAccountDisplayName);
        }

        private static void ValidateAccountProperties(WebForm accountSummaryFrame, Account account)
        {
            var internalView = AccountManager.GetAccountInternalView(account);
            var contactView = AccountManager.GetAccountContactView(account);

            accountSummaryFrame
                .ExpandForm(mt.DataPane, "Billing Information")
                .ValidateTextBoxValue(caption: "First Name", expectedValue:contactView.FirstName)
                .ValidateTextBoxValue(caption: "Email", expectedValue:contactView.Email)
                .ValidateTextBoxValue(caption: "City", expectedValue:contactView.City)
                .ValidateTextFieldValue(caption: "Country", expectedValue:contactView.CountryValueDisplayName)
                ;
            accountSummaryFrame
                .ExpandForm(mt.DataPane, "Account Information")
                .ValidateTextFieldValue(caption: "Billing Cycles", expectedValue:internalView.UsageCycleTypeValueDisplayName)
                ;
            accountSummaryFrame
                .ExpandForm(mt.DataPane, "Tax")
                .ValidateTextBoxValue(caption: "MetraTax Has Override Band",expectedValue:internalView.MetraTaxHasOverrideBand)
                .ValidateTextFieldValue<string>(caption: "Tax Vendor",expectedValue:internalView.TaxVendorValueDisplayName)
                ;
        }
        
        #endregion TestHelpers
    }
}