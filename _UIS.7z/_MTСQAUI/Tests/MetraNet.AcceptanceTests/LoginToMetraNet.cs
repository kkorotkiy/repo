﻿using System;
using System.Threading;
using MetraTech.WebComponents.WebForms;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UtilityComponents;
using LogComponents;
using MetraTech.TestSystem.Interaction;
using MetraTech.TestComponents.MetraNet;
using MetraTech.WebComponents;
using WebComponents;
using WebComponents.WebForms;
using dbq = MetraTech.TestSystem.Interaction.DbQueries;
using db = MetraTech.TestSystem.Interaction.DatabaseManager;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;
using mv = MetraTech.WebComponents.WebControls.MetraView;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class LoginToMetraNet : MetraNetTestSuite
    {
        #region TestSession Setup

        [AssemblyInitialize]
        [DeploymentItem(@"%MTRMPBIN%\en", "en")]
        public static void SetupTestSession(TestContext testContext)
        {
            InitializeTestSession(testContext);
            LogManager.LogInfo("BEGIN setup test session '{0}'.", TestSessionName);
            StartService("W3SVC", "IISADMIN", "MSMQ", "Pipeline", "ActivityServices", "MetraPay");
            SetupBillingServer();
            env.ProlongatePassword(env.MetraNetAdmin);
            env.ProlongatePassword(env.MetraViewAdmin);
            LaunchWebBrowser();
            PingListener();
            PingLoginPage(env.MetraNetWebSiteUrl, mn.LoginPage);
            PingLoginPage(env.MetraViewWebSiteUrl, mv.LoginPage);
            CORE_7483();
            LogManager.LogInfo("END setup test session '{0}'.", TestSessionName);
        }

        private static void SetupBillingServer()
        {
            var affectedRowCount = db.ExecuteDbNonQuery(dbq.SetupBillingServer);
            if (affectedRowCount > 0) {
                RestartService("BillingServer");
            } else {
                StartService("BillingServer");
            }
        }

        private static void LaunchWebBrowser()
        {
            WebBrowser.Launch();
            TakeScreenshot(TestSessionName, (WebBrowser.Type+" launched"));
        }

        private static void PingListener()
        {
            var machineName = db.GetDbParameter("machine_name", Environment.MachineName);
            var status = db.ReadDbValue<string>(dbq.GetListenerOnlineStatus, machineName);
            if (status == "1") {
                return;
            }
            WebBrowser.LoadWebSite(env.ListenerWebSiteUrl);
            WebBrowser.WebSite
                .LoadPageFromUrl(@"listener.dll")
                .CheckDisplayed(_.Any, "Listener process ID")
                ;
            TakeScreenshot(TestSessionName, "Listener pinged");
        }

        private static void PingLoginPage(string webSiteUrl, string loginPageControl)
        {
            sbyte attempt = -1;
            bool exceptionThrown;
            do {
                try {
                    exceptionThrown = false;
                    WebBrowser.LoadWebSite<MetraTechWebSite>(webSiteUrl);
                    WebBrowser.WebSite.LoadPage(loginPageControl);
                } catch (Exception exception) {
                    exceptionThrown = true;
                    LogManager.LogException(exception, takeScreenshot: true);
                    WebBrowser.Quit();
                    WebBrowser.Launch();
                }
            } while (exceptionThrown && (++attempt < 4));
        }

        /// <summary>
        /// https://jira.metratech.com/browse/CORE-7483
        /// </summary>
        private static void CORE_7483()
        {
            var indepAcc = AccountManager.AddNewAccount("IndependentAccount.xml", "indep_CORE-7483_");
            SubscriptionManager.SubscribeAccount(indepAcc, "Localized Audio Conference Product Offering USD");
            var indepAccId = indepAcc._AccountID;
            int usageCount;
            var count = -1;
            do {
                Thread.Sleep(4000);
                MeteringManager.Meter(ComposeMeteringSession.AudioConfCall(indepAcc.UserName, DateTime.Now));
                Thread.Sleep(16000);
                usageCount = db.ReadDbValue<int>(dbq.CountUsages_ByAccountId, db.GetDbParameter("account_id", indepAccId));
            } while ((++count < 4) && (usageCount < 12));
        }
        
        #endregion TestSession Setup

        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies simple MetraNet log in operation.")]
        public void LoginToMetraNetTest()
        {
            var loginPage = WebSite.LoadPage(mn.LoginPage);
            TakeScreenshot("Login Page");

            var mainPage =
                loginPage.LogIn(
                    userName: env.MetraNetAdmin.UserName,
                    password: env.MetraNetAdmin.Password_
                    );
            TakeScreenshot("Main Page");

            bool checkMenuPassed;

            var metraCareMenu =
                mainPage.
                    ExpandForm(mn.Sidebar, "west").
                    ExpandForm(mt.Menu, "MetraNet");

            #region Check Menu "Analytics"

            var analyticsMenu = metraCareMenu.ExpandForm(mt.Menu, "Analytics");

            checkMenuPassed =
                CheckMenuItem(
                    mainPage,
                    analyticsMenu,
                    itemName: "Reports"
                );
            /*checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    analyticsMenu,
                    itemName: "Operations Dashboard"
                     ) && checkMenuPassed
                );*/

            analyticsMenu.Collapse();

            #endregion Check Menu "Analytics"

            var helpDialog =
                mainPage.
                    Click(_.Button, "Help").
                    GetForm(mt.Dialog, "MetraNet Help").
                    Maximize();
            TakeScreenshot("Help Dialog");

            helpDialog.Close();
            mainPage.LogOut();
            TakeScreenshot("Logout Page");

            Assert.AreEqual(
                expected: true,
                actual: checkMenuPassed,
                message: @"Check ""MetraNet"" menu."
                );
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies links in the MetraCare menu, makes screenshots which allows to verify if corresponding page renders correctly.")]
        public void LoginToMetraCareTest()
        {
            bool checkMenuPassed;

            var mainPage = WebSite.LogInAsAdmin();

            var metraCareMenu =
                mainPage.
                    ExpandForm(mn.Sidebar, "west").
                    ExpandForm(mt.Menu, "MetraCare");

            #region Check Menu "Manage Accounts"

            var manageAccountsMenu = metraCareMenu.ExpandForm(mt.Menu, "Manage Accounts");

            checkMenuPassed =
                CheckMenuItem(
                    mainPage,
                    manageAccountsMenu,
                    itemName: "My Accounts",
                    hasTicketFrame: true
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    manageAccountsMenu,
                    itemName: "Add Account"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    manageAccountsMenu,
                    itemName: "Add CSR",
                    caption: "Add System User"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    manageAccountsMenu,
                    itemName: "Add Partition",
                    caption: "Add Partition"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    manageAccountsMenu,
                    itemName: "Move Accounts",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );

            manageAccountsMenu.Collapse();

            #endregion Check Menu "Manage Accounts"

            #region Check Menu "Manage Quotes"

            var manageQuotesMenu = metraCareMenu.ExpandForm(mt.Menu, "Manage Quotes");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    manageQuotesMenu,
                    itemName: "Create Quote",
                    caption: "Manage Quote"
                    ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    manageQuotesMenu,
                    itemName: "View All Quotes",
                    caption: "Quotes List"
                     ) && checkMenuPassed
                );

            manageQuotesMenu.Collapse();

            #endregion Check Menu "Manage Quotes"

            #region Check Menu "Approvals"

            var approvalsMenu = metraCareMenu.ExpandForm(mt.Menu, "Approvals");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    approvalsMenu,
                    itemName: "View Pending Changes",
                    caption: "Pending Changes"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    approvalsMenu,
                    itemName: "View Failed Changes",
                    caption: "Failed Changes"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    approvalsMenu,
                    itemName: "View All Changes",
                    caption: "All Changes"
                     ) && checkMenuPassed
                );

            approvalsMenu.Collapse();

            #endregion Check Menu "Approvals"

            #region Check Menu "Security"

            var securityMenu = metraCareMenu.ExpandForm(mt.Menu, "Security");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    securityMenu,
                    itemName: "User Roles",
                    caption: "Manage Roles",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    securityMenu,
                    itemName: "Application Audit Log"
                     ) && checkMenuPassed
                );

            securityMenu.Collapse();

            #endregion Check Menu "Security"

            #region Check Menu "Adjustments / Charges"

            var adjustmentsChargesMenu = metraCareMenu.ExpandForm(mt.Menu, "Adjustments / Charges");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    adjustmentsChargesMenu,
                    itemName: "Adjustments"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    adjustmentsChargesMenu,
                    itemName: "Orphan Adjustments",
                    caption: "Manage Orphan Adjustments",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    adjustmentsChargesMenu,
                    itemName: "Misc. Adjustments"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    adjustmentsChargesMenu,
                    itemName: "Nonstandard Charges"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    adjustmentsChargesMenu,
                    itemName: "View Credit Notes Issued"
                     ) && checkMenuPassed
                );

            adjustmentsChargesMenu.Collapse();

            #endregion Check Menu "Adjustments / Charges"

            Assert.AreEqual(
                expected: true,
                actual: checkMenuPassed,
                message: @"Check ""MetraCare"" menu."
                );
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies links in the MetraControl menu, makes screenshots which allows to verify if corresponding page renders correctly.")]
        public void LoginToMetraControlTest()
        {
            bool checkMenuPassed;

            var mainPage = WebSite.LogInAsAdmin();

            var metraControlMenu =
                mainPage.
                    ExpandForm(mn.Sidebar, "west").
                    ExpandForm(mt.Menu, "MetraControl");

            #region Check Menu "Billing"

            var billingMenu = metraControlMenu.ExpandForm(mt.Menu, "Billing");

            checkMenuPassed =
                CheckMenuItem(
                    mainPage,
                    billingMenu,
                    itemName: "Billable Intervals"
                    );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    billingMenu,
                    itemName: "Active Intervals"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    billingMenu,
                    itemName: "Completed Intervals"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    billingMenu,
                    itemName: "All Intervals"
                     ) && checkMenuPassed
                );

            billingMenu.Collapse();

            #endregion Check Menu "Billing"

            #region Check Menu "Scheduled Adapters"

            var scheduledAdaptersMenu = metraControlMenu.ExpandForm(mt.Menu, "Scheduled Adapters");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    scheduledAdaptersMenu,
                    itemName: "Event List",
                    caption: "Scheduled Adapters Event List"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    scheduledAdaptersMenu,
                    itemName: "Runs in Past 24 Hours",
                    caption: "Scheduled Adapter Run List"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    scheduledAdaptersMenu,
                    itemName: "Runs in Past Week",
                    caption: "Scheduled Adapter Run List"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    scheduledAdaptersMenu,
                    itemName: "Runs (All)",
                    caption: "Scheduled Adapter Run List"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    scheduledAdaptersMenu,
                    itemName: "Run Scheduled Adapter Now"
                     ) && checkMenuPassed
                );

            scheduledAdaptersMenu.Collapse();

            #endregion Check Menu "Scheduled Adapters"

            #region Check Menu "Usage Processing"

            var usageProcessingMenu = metraControlMenu.ExpandForm(mt.Menu, "Usage Processing");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    usageProcessingMenu,
                    itemName: "All Events",
                    caption: "Usage Statistics Filter"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    usageProcessingMenu,
                    itemName: "Batches In The Past 24 Hours",
                    caption: "Batch Management",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    usageProcessingMenu,
                    itemName: "Batches In The Past Week",
                    caption: "Batch Management",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    usageProcessingMenu,
                    itemName: "Active/Failed Batches",
                    caption: "Batch Management",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    usageProcessingMenu,
                    itemName: "Completed Batches",
                    caption: "Batch Management",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    usageProcessingMenu,
                    itemName: "Dismissed Batches",
                    caption: "Batch Management",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    usageProcessingMenu,
                    itemName: "All Batches",
                    caption: "Batch Management",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    usageProcessingMenu,
                    itemName: "Usage Calculation Decision Details"
                     ) && checkMenuPassed
                );

            usageProcessingMenu.Collapse();

            #endregion Check Menu "Usage Processing"

            #region Check Menu "Backout Management"

            var backoutManagementMenu = metraControlMenu.ExpandForm(mt.Menu, "Backout Management");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    backoutManagementMenu,
                    itemName: "Create Backout/Rerun",
                    caption: "Backout Transactions",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    backoutManagementMenu,
                    itemName: "In Progress Backout/Reruns",
                    caption: "Rerun Management",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    backoutManagementMenu,
                    itemName: "Completed Backout/Reruns",
                    caption: "Rerun Management",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );

            backoutManagementMenu.Collapse();

            #endregion Check Menu "Backout Management"

            #region Check Menu "Data Export"

            var dataExportMenu = metraControlMenu.ExpandForm(mt.Menu, "Data Export");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    dataExportMenu,
                    itemName: "Manage Reports",
                    caption: "Show All Report Definitions"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    dataExportMenu,
                    itemName: "Queue Adhoc Reports",
                    caption: "Adhoc Reports"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    dataExportMenu,
                    itemName: "Report Audit History",
                    caption: "Data Export Framework Dashboard"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    dataExportMenu,
                    itemName: "Data Export Queue",
                    caption: "Data Export Framework Work Queue"
                     ) && checkMenuPassed
                );

            dataExportMenu.Collapse();

            #endregion Check Menu "Data Export"

            #region Check Menu "File Processing"

            var fileProcessingMenu = metraControlMenu.ExpandForm(mt.Menu, "File Processing");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    fileProcessingMenu,
                    itemName: "Configure Globals",
                    caption: "Globals"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    fileProcessingMenu,
                    itemName: "Configure Targets",
                    caption: "File Management Targets"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    fileProcessingMenu,
                    itemName: "Jobs in the Past 2 Days",
                    caption: "File Management Jobs in the Past Two Days"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    fileProcessingMenu,
                    itemName: "Jobs in the Past Week",
                    caption: "File Management Jobs in the Past Week"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    fileProcessingMenu,
                    itemName: "Active Jobs",
                    caption: "File Management Active Jobs"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    fileProcessingMenu,
                    itemName: "Failed Jobs",
                    caption: "File Management Failed Jobs"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    fileProcessingMenu,
                    itemName: "Completed Jobs",
                    caption: "File Management Completed Jobs"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    fileProcessingMenu,
                    itemName: "All Jobs",
                    caption: "File Management All Jobs"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    fileProcessingMenu,
                    itemName: "Rejected Files",
                    caption: "Rejected Files"
                     ) && checkMenuPassed
                );

            fileProcessingMenu.Collapse();

            #endregion Check Menu "File Processing"

            #region Check Menu "Failed Transactions"

            var failedTransactionsMenu = metraControlMenu.ExpandForm(mt.Menu, "Failed Transactions");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    failedTransactionsMenu,
                    itemName: "Summary By Account"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    failedTransactionsMenu,
                    itemName: "Summary By Account and Error Type"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    failedTransactionsMenu,
                    itemName: "Summary By Interval Type"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    failedTransactionsMenu,
                    itemName: "Summary By Stage and Plugin"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    failedTransactionsMenu,
                    itemName: "Summary By Error Type"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    failedTransactionsMenu,
                    itemName: "Open"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    failedTransactionsMenu,
                    itemName: "Under Investigation"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    failedTransactionsMenu,
                    itemName: "Corrected and Waiting"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    failedTransactionsMenu,
                    itemName: "Resubmitted"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    failedTransactionsMenu,
                    itemName: "Dismissed"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    failedTransactionsMenu,
                    itemName: "Suspended",
                    caption: "Suspended Transactions",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );

            failedTransactionsMenu.Collapse();

            #endregion Check Menu "Failed Transactions"

            #region Check Menu "Administration"

            var administrationMenu = metraControlMenu.ExpandForm(mt.Menu, "Administration");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    administrationMenu,
                    itemName: "Usage Server",
                    caption: "Usage Server Maintenance"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    administrationMenu,
                    itemName: "Version Information",
                    caption: "System Version Information",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    administrationMenu,
                    itemName: "Namespaces",
                    caption: "Name Space",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    administrationMenu,
                    itemName: "Machine Roles",
                    caption: "MachineRole"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    administrationMenu,
                    itemName: "Synchronize",
                    caption: "Synchronize Platform",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );

            administrationMenu.Collapse();

            #endregion Check Menu "Administration"

            Assert.AreEqual(
                expected: true,
                actual: checkMenuPassed,
                message: @"Check ""MetraControl"" menu."
                );
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies links in the MetraOffer menu, makes screenshots which allows to verify if corresponding page renders correctly.")]
        public void LoginToMetraOfferTest()
        {
            bool checkMenuPassed;

            var mainPage = WebSite.LogInAsAdmin();

            var metraOfferMenu =
                mainPage.
                    ExpandForm(mn.Sidebar, "west").
                    ExpandForm(mt.Menu, "MetraOffer");

            #region Check Menu "Product Catalog"

            var productCatalogMenu = metraOfferMenu.ExpandForm(mt.Menu, "Product Catalog");

            //The Product Dashboard was temporary disabled in the Bling project.
            //When it is enabled, one should uncomment code below.

            //checkMenuPassed =
            //    CheckMenuItem(
            //        productCatalogMenu,
            //        itemName: "Product Dashboard"
            //        );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    productCatalogMenu,
                    itemName: "Product Offerings"
                    ) //&& checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    productCatalogMenu,
                    itemName: "Master Product Offerings"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    productCatalogMenu,
                    itemName: "Shared Properties"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    productCatalogMenu,
                    itemName: "Shared Rates"
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    productCatalogMenu,
                    itemName: "Priceable Items",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            productCatalogMenu.Collapse();

            #endregion Check Menu "Product Catalog"

            #region Check Menu "Bill Messages"

            var billMessagesMenu = metraOfferMenu.ExpandForm(mt.Menu, "Bill Messages");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    billMessagesMenu,
                    itemName: "Manage Bill Messages",
                    caption: "Bill Messages"
                     ) && checkMenuPassed
                );
            billMessagesMenu.Collapse();

            #endregion Check Menu "Bill Messages"

            #region Check Menu "Advanced Options"

            var advancedOptionsMenu = metraOfferMenu.ExpandForm(mt.Menu, "Advanced Options");

            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    advancedOptionsMenu,
                    itemName: "Calendars",
                    caption: "Manage Calendars",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    advancedOptionsMenu,
                    itemName: "Bulk Subscription Change",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    advancedOptionsMenu,
                    itemName: "Audit Log",
                    caption: "Product Catalog Audit Log",
                    hasTicketFrame: true
                     ) && checkMenuPassed
                );
            checkMenuPassed =
                (CheckMenuItem(
                    mainPage,
                    advancedOptionsMenu,
                    itemName: "Decision Types",
                    caption: "Manage Aggregate Metrics Processor (AMP) Decision Types"
                     ) && checkMenuPassed
                );
            advancedOptionsMenu.Collapse();

            #endregion Check Menu "Advanced Options"

            Assert.AreEqual(
                expected: true,
                actual: checkMenuPassed,
                message: @"Check ""MetraOffer"" menu."
                );
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies tabs in AccountSidebar menu, makes screenshots which allows to verify if corresponding page renders correctly.")]
        public void ValidateAccountSidebarTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpAccSidebar");
            var depAcc1 = AccountManager.AddNewAccount("DepartmentAccount.xml", userNamePrefix: "dep1AccSidebar", ancestor:corpAcc);
            var depAcc2 = AccountManager.AddNewAccount("DepartmentAccount.xml", userNamePrefix: "dep2AccSidebar", ancestor:corpAcc);
            var subAcc1 = AccountManager.AddNewAccount("SubscriberAccount.xml", userNamePrefix: "sub1AccSidebar", ancestor: depAcc1);
            AccountManager.AddNewAccount("SubscriberAccount.xml", userNamePrefix: "sub2AccSidebar", ancestor: depAcc2);
            AccountManager.AddNewAccount("SubscriberAccount.xml", userNamePrefix: "sub3AccSidebar", ancestor: depAcc2);

            var corpAccFriendlyUserName = AccountManager.FormatFriendlyUserName(corpAcc);
            var dep1AccFriendlyUserName = AccountManager.FormatFriendlyUserName(depAcc1);
            var depAcc2UserName = depAcc2.UserName;
            var subscrAcc1UserName = subAcc1.UserName;
            var subscrAcc1FriendlyUserName = AccountManager.FormatFriendlyUserName(subAcc1);

            var mainPage = WebSite.LogInAsAdmin();

            mainPage.
                LoadAccountSummaryFrame(subscrAcc1UserName).
                Page().Click(mn.ToolButton_HierarchyFind);

            var accountSidebar = mainPage.GetForm(mn.Sidebar, "east");

            // ============-- BEGIN CHECK: "AccountSidebar.Hierarchy Tab" --===========================
            accountSidebar
                .GetAccountSidebarTabFrame(tab: "Hierarchy")
                .GetForm(mt.TreeNode, "Hierarchy")
                .GetForm(mt.TreeNode, corpAccFriendlyUserName)
                .GetForm(mt.TreeNode, dep1AccFriendlyUserName)
                .CheckDisplayed(mt.TreeLeaf, subscrAcc1FriendlyUserName)
                .Collapse()
                .SwitchToParentForm()
                .Collapse()
                .SwitchToParentForm()
                .Collapse()
                ;
            TakeScreenshot("AccountSidebar.Hierarchy Tab");
            // ============-- END CHECK: "AccountSidebar.Hierarchy Tab" --=============================

            // ============-- BEGIN CHECK: "AccountSidebar.Finder Tab" --==============================
            accountSidebar.SwitchToForm();
            accountSidebar
                .Click(mn.Tab, "Finder")
                .GetAccountSidebarTabFrame(tab: "Finder")
                .ExpandForm(mt.DataPane, "Search Filters")
                .EnterTextBoxValue(caption: "User name", value: depAcc2UserName)
                .ClickWithReload(_.Button, "Search")
                .SwitchToParentForm()
                .ExpandForm(mt.DataPane, "Accounts")
                ;
            TakeScreenshot("AccountSidebar.Finder Tab");
            // ============-- END CHECK: "AccountSidebar.Finder Tab" --================================

            // ============-- BEGIN CHECK: "AccountSidebar.Details Tab" --=============================
            accountSidebar.SwitchToForm();
            accountSidebar.Click(mn.Tab, "Details");
            TakeScreenshot("AccountSidebar.Details Tab");
            // ============-- END CHECK: "AccountSidebar.Details Tab" --===============================

            accountSidebar.SwitchToForm();
            accountSidebar.Collapse();
            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description("Verifies tabs in AccountToolbar menu, makes screenshots which allows to verify if corresponding page renders correctly.")]
        public void ValidateAccountToolbarTest()
        {
            bool checkMenuPassed;

            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpAccToolbar");
            CapabilityManager.GrantApplicationLogonCapability(corpAcc._AccountID.Value, "MPS");
            var corpAccUserName = corpAcc.UserName;
            var corpAccDisplayedName = AccountManager.FormatDisplayName(corpAcc);

            var mainPage = WebSite.LogInAsAdmin();
            mainPage.EnterFindBoxValue(value: corpAccUserName, control: mn.QuickSearch_FindBox);

            // ============-- BEGIN CHECK: "Account" --==============================
            checkMenuPassed = CheckToolbarMenuItem(mainPage, menu: "Account", itemName: "Account Details", caption: "Account Summary");
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Account", itemName: "Account State", hasTicketFrame: true) && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Account", itemName: "Update Account") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Account", itemName: "Contacts") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Account", itemName: "View Online Bill") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Account", itemName: "Edit Template", caption: "Account Templates") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Account", itemName: "Move Account", hasTicketFrame: true) && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Account", itemName: "Assign Bill Messages") && checkMenuPassed);
            // ============-- END CHECK: "Account Details" --================================

            // ============-- BEGIN CHECK: "Subscriptions" --================================
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Subscriptions", itemName: "Subscriptions") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Subscriptions", itemName: "Group Subscriptions") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Subscriptions", itemName: "Quotes", caption: "Quotes List") && checkMenuPassed);
            // ============-- END CHECK: "Subscriptions" --==================================
            
            // ============-- BEGIN CHECK: "Relationships" --================================
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Relationships", itemName: "Account Administrator", hasTicketFrame: true) && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Relationships", itemName: "Administrated Accounts", hasTicketFrame: true) && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Relationships", itemName: "Account Owners", hasTicketFrame: true) && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Relationships", itemName: "Pay for Accounts", hasTicketFrame: true) && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Relationships", itemName: "Payers", hasTicketFrame: true) && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Relationships", itemName: "View Account Log", caption:"Audit Log") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Relationships", itemName: "Add Log Entry", hasTicketFrame: true) && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Relationships", itemName: "Bill Managers") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Relationships", itemName: "Managed Online Bills") && checkMenuPassed);
            // ============-- END CHECK: "Relationships" --==================================
                        
            // ============-- BEGIN CHECK: "Adjustments" --==================================
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Adjustments / Charges", itemName: "Adjust Transactions", hasTicketFrame: true, caption: "Transaction Finder") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Adjustments / Charges", itemName: "Bulk Adjustments", hasTicketFrame: true, caption: "Transaction Finder") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Adjustments / Charges", itemName: "Misc. Adjustments", caption: "Issue Miscellaneous Adjustment") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Adjustments / Charges", itemName: "Create Credit Note", caption: "Create Credit Note Document for Adjustment Issued") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Adjustments / Charges", itemName: "Nonstandard Charges", caption: "Issue Nonstandard Charge") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Adjustments / Charges", itemName: "View Credit Notes Issued") && checkMenuPassed);
            // ============-- END CHECK: "Adjustments" --====================================
            
            // ============-- BEGIN CHECK: "Security" --=====================================
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Security", itemName: "Aliases", hasTicketFrame: true, caption: "Security Permissions:  "+corpAccDisplayedName) && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Security", itemName: "Default Security", hasTicketFrame: true, caption: "Security Permissions:  "+corpAccDisplayedName) && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Security", itemName: "Manage Security", caption: "Security Permissions: Default") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Security", itemName: "Generate Password") && checkMenuPassed);
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Security", itemName: "Lock / Unlock Account") && checkMenuPassed);
            // ============-- END CHECK: "Security" --=======================================

            // ============-- BEGIN CHECK: "Payments" --=====================================
            checkMenuPassed = (CheckToolbarMenuItem(mainPage, menu: "Payments", itemName: "Payment Methods") && checkMenuPassed);
            // ============-- END CHECK: "Payments" --=======================================

            Assert.AreEqual(expected: true, actual: checkMenuPassed, message: @"Check ""Account Toolbar"" menu.");
            WebSite.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private bool
           CheckToolbarMenuItem(
                WebPage mainPage,
                string menu,
                string itemName,
                string caption = null,
                bool hasTicketFrame = false
            ) {
            bool passed;
            var menuItemName = (menu + "." + itemName);
            if (caption == null) {
                caption = itemName;
            }
            try {
                if (hasTicketFrame) {
                    mainPage.NavigateAccountToolbarToFrame_1(menu, itemName, caption);
                } else {
                    mainPage.NavigateAccountToolbarToFrame(menu, itemName, caption);
                }
                passed = true;
            } catch (Exception exception) {
                passed = false;
                LogUnhandledException(exception, "Failed check menu item '{0}'.", menuItemName);
            } finally {
                var fileName = PathExt.NormalizeFileName(menuItemName);
                TakeScreenshot(fileName);
            }
            return passed;
        }

        private bool
            CheckMenuItem(
                WebPage page,
                WebForm menu,
                string itemName,
                string caption = null,
                bool hasTicketFrame = false,
                params object[] additionalFrames
            ) {
            bool passed;
            var menuItemName = (menu.Caption+"."+itemName);
            if (caption == null) {
                caption = itemName;
            }
            try {
                menu.Click(mt.MenuItem, itemName);
                if (hasTicketFrame) {
                    page.GetFrame_1(caption, additionalFrames);
                } else {
                    page.GetFrame(caption, additionalFrames);
                }
                passed = true;
            } catch (Exception exception) {
                passed = false;
                LogUnhandledException(exception, "Failed check menu item '{0}'.", menuItemName);
            } finally {
                var fileName = PathExt.NormalizeFileName(menuItemName);
                TakeScreenshot(fileName);
                menu.SwitchToForm();
            }
            return passed;
        }

        #endregion TestHelpers

        #region TestSession Cleanup

        [AssemblyCleanup]
        public static void CleanupTestSession()
        {
            LogManager.LogInfo("BEGIN cleanup test session '{0}'.", TestSessionName);
            WebBrowser.Quit();
            DatabaseManager.DisconnectFromDatabase();
            LogManager.LogInfo("END cleanup test session '{0}'.", TestSessionName);
        }

        #endregion TestSession Cleanup
    }
}
