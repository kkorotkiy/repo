﻿using MetraTech.DomainModel.BaseTypes;
using MetraTech.DomainModel.Enums.PaymentSvrClient.Metratech_com_paymentserver;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetraTech.TestSystem.Interaction;
using MetraTech.TestComponents;
using MetraTech.TestComponents.MetraView;
using MetraTech.WebComponents.WebForms;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mv = MetraTech.WebComponents.WebControls.MetraView;
using CreditCardType = MetraTech.DomainModel.Enums.Core.Metratech_com.CreditCardType;
using MetraTech.DomainModel.MetraPay;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class MetraViewPaymentMethods : MetraViewTestSuite
    {
        #region Properties and Fields

        private static readonly CreditCardPaymentMethod
            VisaCard = NewCreditCard("4222222222222", CreditCardType.Visa, 1);

        private static readonly CreditCardPaymentMethod
            MasterCard = NewCreditCard("5105105105105100", CreditCardType.MasterCard, 2);

        private static readonly ACHPaymentMethod
            SouthAmericaAch = NewAch("180970068", "South America", 3);

        private static readonly ACHPaymentMethod
            WestIndiaAch = NewAch("160045507", "West of India", 4);

        #endregion

        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraView that credit card (CC) can be added to a user account.")]
        public void AddCreditCardTest()
        {
            var corpAcc = CreateCorporateAccount("corpMvAddCC");
            var creditCard =
                (new CreditCardPaymentMethod {
                    AccountNumber = "5105105105105100",
                    CVNumber = "035",
                    CreditCardType = CreditCardType.MasterCard,
                    Priority = 1,
                    ExpirationDate = "09/2022",
                    FirstName = "Henrikh",
                    LastName = "Larson",
                    Street = "New Line Sity, st. 12",
                    City = "Dangaport",
                    ZipCode = "13522",
                });

            var paymentMethodsPage =
                WebSite.LogIn(corpAcc)
                    .NavigateMetraView(
                        tab: "Bill & Payments",
                        nestedTab: "Payment Methods"
                    );
            var addCreditCardPage =
                paymentMethodsPage
                    .Click(_.Button, "Add Credit Card")
                    .Site().WaitPageLoaded(mv.AddCreditCardPage)
                    ;
            paymentMethodsPage =
                PopulateCreditCardProperties(
                    addCreditCardPage,
                    creditCard
                    );

            //====- VALIDATION STAFF -========

            ValidateCreditCardGridRow(paymentMethodsPage, creditCard);
            paymentMethodsPage.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraView that credit card (CC) can be edited for a user account.")]
        public void EditCreditCardTest()
        {
            var corpAcc = CreateCorporateAccount("CorpEditCcMV");
            PaymentManager.AddPaymentMethod(corpAcc, VisaCard, MasterCard, SouthAmericaAch, WestIndiaAch);
            var creditCardTemplate =
                (new CreditCardPaymentMethod {
                    AccountNumber = "5105105105105100",
                    CVNumber = "111",
                    CreditCardType = CreditCardType.MasterCard,
                    Priority = 1,
                    ExpirationDate = "09/2022"
                });

            var paymentMethodsPage =
                WebSite.LogIn(corpAcc)
                    .NavigateMetraView(
                        tab: "Bill & Payments",
                        nestedTab: "Payment Methods"
                    );
            var updateCreditCardPage =
                NavigateToEditPaymentMethodPage(
                    paymentMethodsPage,
                    creditCardTemplate,
                    buttonCaption: "Edit Card",
                    editPageControl: mv.UpdateCreditCardPage
                    );
            paymentMethodsPage =
                UpdateCreditCardProperties(
                    updateCreditCardPage,
                    creditCardTemplate
                    );

            //====- VALIDATION STAFF -========

            ValidateCreditCardGridRow(paymentMethodsPage, creditCardTemplate);
            paymentMethodsPage.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraView that credit card (CC) can be deleted from a user account.")]
        public void RemoveCreditCardTest()
        {
            var corpAcc = CreateCorporateAccount("CorpDelCcMV");
            PaymentManager.AssignPaymentMethodToAccount(corpAcc, VisaCard, MasterCard, SouthAmericaAch, WestIndiaAch);
            var creditCard =
                (new CreditCardPaymentMethod {
                    AccountNumber = "5105105105105100",
                    CVNumber = "111",
                    CreditCardType = CreditCardType.MasterCard,
                });
            creditCard.SafeAccountNumber = PaymentManager.FormatSecureNumber(creditCard.AccountNumber);

            var paymentMethodsPage =
                WebSite.LogIn(corpAcc)
                    .NavigateMetraView(
                        tab: "Bill & Payments",
                        nestedTab: "Payment Methods"
                    );
            paymentMethodsPage = RemoveCreditCard(paymentMethodsPage, creditCard);

            //====- VALIDATION STAFF -========

            paymentMethodsPage.
                CheckGridRow(
                    Cell("Account Number", creditCard.SafeAccountNumber),
                    exists: false
                );
            paymentMethodsPage.LogOut();
        }

        
        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraView that bank account (ACH) can be added to a user account.")]
        public void AddBankAccountTest()
        {
            var corpAcc = CreateCorporateAccount("corpMvAddAch");
            var ach =
                (new ACHPaymentMethod {
                    AccountNumber = "11091803290",
                    RoutingNumber = "11091803290",
                    AccountType = BankAccountType.Checking,
                    Priority = 1,
                    FirstName = "Henrikh",
                    LastName = "Larson",
                    Street = "New Line Sity, st. 12",
                    City = "Dangaport",
                    State = "MA",
                    ZipCode = "13522"
                });

            var paymentMethodsPage =
                WebSite.LogIn(corpAcc)
                    .NavigateMetraView(
                        tab: "Bill & Payments",
                        nestedTab: "Payment Methods"
                    );
            var addAchPage =
                paymentMethodsPage
                    .Click(_.Button, "Add ACH")
                    .Site().WaitPageLoaded(mv.AddAchPage)
                    ;
            paymentMethodsPage = PopulateBankAccountProperties(addAchPage, ach);

            //====- VALIDATION STAFF -========

            ValidateBankAccountGridRow(paymentMethodsPage, ach);
            paymentMethodsPage.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraView that bank account (ACH) can be edited for a user account.")]
        public void EditBankAccountTest()
        {
            var corpAcc = CreateCorporateAccount("CorpEditACH");
            PaymentManager.AssignPaymentMethodToAccount(corpAcc, VisaCard, SouthAmericaAch, WestIndiaAch);
            var ach =
                (new ACHPaymentMethod {
                    AccountNumber = "180970068",
                    RoutingNumber = "180970068",
                    AccountType = BankAccountType.Checking,
                    Priority = 1,
                });

            var paymentMethodsPage =
                WebSite.LogIn(corpAcc)
                    .NavigateMetraView(
                        tab: "Bill & Payments",
                        nestedTab: "Payment Methods"
                    );
            var updateAchPage =
                NavigateToEditPaymentMethodPage(
                    paymentMethodsPage,
                    ach,
                    buttonCaption: "Edit ACH",
                    editPageControl: mv.UpdateAchPage
                    );
            paymentMethodsPage = UpdateBankAccountProperties(updateAchPage, ach);

            //====- VALIDATION STAFF -========

            ValidateBankAccountGridRow(paymentMethodsPage, ach);
            paymentMethodsPage.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraView that bank account (ACH) can be deleted from a user account.")]
        public void RemoveBankAccountTest()
        {
            var corpAcc = CreateCorporateAccount("CorpDelAchMv");
            PaymentManager.AssignPaymentMethodToAccount(corpAcc, VisaCard, MasterCard, SouthAmericaAch, WestIndiaAch);
            var ach =
                (new ACHPaymentMethod {
                    AccountNumber = "180970068",
                    RoutingNumber = "180970068",
                    AccountType = BankAccountType.Checking,
                    Priority = 2,
                });
            ach.SafeAccountNumber = PaymentManager.FormatSecureNumber(ach.AccountNumber);

            var paymentMethodsPage =
                WebSite.LogIn(corpAcc)
                    .NavigateMetraView(
                        tab: "Bill & Payments",
                        nestedTab: "Payment Methods"
                    );
            paymentMethodsPage = RemoveBankAccount(paymentMethodsPage, ach);

            //====- VALIDATION STAFF -========

            paymentMethodsPage.
                CheckGridRow(
                    Cell("Account Number", ach.SafeAccountNumber),
                    exists: false
                );
            paymentMethodsPage.LogOut();
        }


        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraView that payment could be made and displayed properly on ""Bill & Payments""/""Payment History"" tab.")]
        public void MakePaymentsTest()
        {
            var corpAcc = CreateCorporateAccount("CorpMvMakePayment");
            PaymentManager.AddPaymentMethod(corpAcc, VisaCard, SouthAmericaAch);

            var achNumber = "Checking account ****-0068";
            var ccNumber = "Visa ****-2222";
            var ccAccountNumber = "*******-2222";
            var amount = Number(15);
            var displayAmount = ("$  "+amount);

            var homePage = WebSite.LogIn(corpAcc);

            MakePayment(homePage, achNumber, amount);
            MakePayment(homePage, ccNumber, amount);

            // =====-- BEGIN CHECK: Payment with VISA CC should appear on Payment History page --================

            var paymentHistoryPage =
                homePage.
                    NavigateMetraView(
                        tab: "Bill & Payments",
                        nestedTab: "Payment History"
                    );
            paymentHistoryPage.
                ExpandForm(mt.DataPane, "Payment History").
                FindGridRow(Cell("Account Number", ccAccountNumber)).
                ValidateGridRow(Cell("Amount", displayAmount));

            // =====-- EDN CHECK: Payment with VISA CC should appear on Payment History page --==================

            paymentHistoryPage.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private static WebPage
            NavigateToEditPaymentMethodPage(
                WebPage paymentMethodsPage,
                MetraPaymentMethod paymentMethod,
                string buttonCaption,
                string editPageControl
            ) {
            var editPaymentMethodPage =
                paymentMethodsPage
                    .FindGridRow(Cell("Account Number", paymentMethod.SafeAccountNumber))
                    .Click(_.LinkImage_ByTooltip, buttonCaption)
                    .Site().WaitPageLoaded(editPageControl)
                    ;
            return editPaymentMethodPage;
        }


        private static WebPage
            UpdateCreditCardProperties(
                WebPage updateCreditCardPage,
                CreditCardPaymentMethod creditCard
            ) {
            string expirationMonth, expirationYear;
            PaymentManager.ParseExpirationDate(
                creditCard.ExpirationDate,
                out expirationMonth,
                out expirationYear
                );
            updateCreditCardPage
                .EnterComboBoxValue(caption: "Priority", value: creditCard.Priority)
                .EnterComboBoxValue(control: mt.ComboBox, caption: "Expiration Date", value: expirationMonth)
                .EnterComboBoxValue(control: mt.ComboBox, caption: "/", value: expirationYear)
                ;
            var paymentMethodsPage =
                updateCreditCardPage
                    .Click(_.Button, "OK")
                    .Site().WaitPageLoaded(mv.PaymentMethodsPage)
                    ;
            return paymentMethodsPage;
        }

        private static WebPage
            UpdateBankAccountProperties(
                WebPage updateAchPage,
                ACHPaymentMethod ach
            ) {
            updateAchPage.
                EnterComboBoxValue(caption: "Priority", value: ach.Priority);

            var paymentMethodsPage =
                updateAchPage.
                    Click(_.Button, "OK").
                    Site().WaitPageLoaded(mv.PaymentMethodsPage);

            return paymentMethodsPage;
        }


        private static WebPage
            PopulateCreditCardProperties(
                WebPage addCreditCardPage,
                CreditCardPaymentMethod creditCard
            ) {
            string expirationMonth, expirationYear;
            PaymentManager.ParseExpirationDate(
                creditCard.ExpirationDate,
                out expirationMonth,
                out expirationYear
                );
            addCreditCardPage.
                EnterComboBoxValue(caption: "Priority", value: creditCard.Priority).
                EnterComboBoxValue(caption: "Credit Card Type", value: creditCard.CreditCardType).
                EnterTextBoxValue(caption: "Card Number", value: creditCard.AccountNumber).
                EnterTextBoxValue(caption: "CVV Number", value: creditCard.CVNumber).
                EnterComboBoxValue(control: mt.ComboBox, caption: "Expiration Date", value: expirationMonth).
                EnterComboBoxValue(control: mt.ComboBox, caption: "/", value: expirationYear).
                EnterTextBoxValue(caption: "First Name", value: creditCard.FirstName).
                EnterTextBoxValue(caption: "Last Name", value: creditCard.LastName).
                EnterTextBoxValue(caption: "Address Line 1", value: creditCard.Street).
                EnterTextBoxValue(caption: "City", value: creditCard.City).
                EnterTextBoxValue(caption: "Zip/Postal Code", value: creditCard.ZipCode).
                EnterComboBoxValue(caption: "Country", enterValue: "us", dropdownValue: "US Virgin Islands", mode: DataInputMode.Mixed);

            var paymentMethodsPage =
                addCreditCardPage.
                    Click(_.Button, "OK").
                    Site().WaitPageLoaded(mv.PaymentMethodsPage);

            return paymentMethodsPage;
        }

        private static WebPage
            PopulateBankAccountProperties(
                WebPage addAchPage,
                ACHPaymentMethod ach
            ) {
            addAchPage.
                EnterCheckBoxValue(caption: ach.AccountType, value: true).
                EnterComboBoxValue(caption: "Priority", value: ach.Priority).
                EnterTextBoxValue(caption: "First Name", value: ach.FirstName).
                EnterTextBoxValue(caption: "Last Name", value: ach.LastName).
                EnterTextBoxValue(caption: "Address Line 1", value: ach.Street).
                EnterTextBoxValue(caption: "City", value: ach.City).
                EnterTextBoxValue(caption: "State/Province", value: ach.State).
                EnterTextBoxValue(caption: "Zip/Postal Code", value: ach.ZipCode).
                EnterComboBoxValue(caption: "Country", enterValue: "us", dropdownValue: "US Virgin Islands", mode: DataInputMode.Mixed).
                EnterTextBoxValue(caption: "Account Number", value: ach.RoutingNumber).
                EnterTextBoxValue(caption: "Routing Number", value: ach.RoutingNumber);

            var paymentMethodsPage =
                addAchPage.
                    Click(_.Button, "OK").
                    Site().WaitPageLoaded(mv.PaymentMethodsPage);

            return paymentMethodsPage;
        }


        private static WebPage
            RemoveCreditCard(
                WebPage paymentMethodsPage,
                CreditCardPaymentMethod creditCard
            ) {
            var removeCreditCardPage =
                paymentMethodsPage.
                    FindGridRow(Cell("Account Number", creditCard.SafeAccountNumber)).
                    Click(_.LinkImage_ByTooltip, "Remove Card").
                    Site().WaitPageLoaded(mv.RemoveCreditCardPage);

            paymentMethodsPage =
                removeCreditCardPage.
                    CheckDisplayed(_.Label, "Are you sure you want to remove the credit card below?").
                    CheckDisplayed(_.Label, creditCard.CreditCardType).
                    CheckDisplayed(_.Label, creditCard.SafeAccountNumber).
                    Click(_.Button, "Yes").
                    Site().WaitPageLoaded(mv.PaymentMethodsPage);

            return paymentMethodsPage;
        }

        private static WebPage
            RemoveBankAccount(
                WebPage paymentMethodsPage,
                ACHPaymentMethod ach
            ) {
            var removeAchPage =
                paymentMethodsPage.
                    FindGridRow(Cell("Account Number", ach.SafeAccountNumber)).
                    Click(_.LinkImage_ByTooltip, "Remove ACH").
                    Site().WaitPageLoaded(mv.RemoveAchPage);

            paymentMethodsPage =
                removeAchPage.
                    CheckDisplayed(_.Label, "Are you sure you want to remove the ACH account below?").
                    CheckDisplayed(_.Label, ach.SafeAccountNumber).
                    Click(_.Button, "Yes").
                    Site().WaitPageLoaded(mv.PaymentMethodsPage);

            return paymentMethodsPage;
        }


        private static void
            ValidateCreditCardGridRow(
                WebPage paymentMethodsPage,
                CreditCardPaymentMethod creditCard
            ) {
            var creditCardGridRow =
                paymentMethodsPage.
                    GetForm(mt.GridRow_ByIndex, creditCard.Priority);

            creditCardGridRow.
                ValidateGridRow(Cell("Account Number", creditCard.SafeAccountNumber)).
                ValidateGridRow(Cell("Payment Method", creditCard.CreditCardType)).
                ValidateGridRow(Cell("Exp. Date", creditCard.ExpirationDate));

            //return creditCardGridRow;
        }

        private static void
            ValidateBankAccountGridRow(
                WebPage paymentMethodsPage,
                ACHPaymentMethod ach
            ) {
            var achGridRow =
                paymentMethodsPage.
                    GetForm(mt.GridRow_ByIndex, ach.Priority);

            achGridRow.
                ValidateGridRow(Cell("Account Number", ach.SafeAccountNumber)).
                ValidateGridRow(Cell("Payment Method", "ACH"));

            //return achGridRow;
        }


        private static void
            MakePayment(
                WebPage homePage,
                string paymentMethodNumber,
                string amount
            ) {
            var makePaymentPage =
                homePage.
                    NavigateMetraView(tab: "Bill & Payments").
                    GetForm(mv.DataPane, "Payment Information").
                    Click(mv.Button, "Make a Payment").
                    Site().WaitPageLoaded(mv.MakePaymentPage);

            var reviewPaymentPage =
                makePaymentPage.
                    EnterTextBoxValue(control: mv.TextBoxForCheckBox, caption: "Pay this Amount, $", value: amount).
                    EnterComboBoxValue(control: mv.TextBoxForCheckBox, caption: "Existing Payment Method",
                                       value: paymentMethodNumber).
                    Click(mv.Button, "Next").
                    Site().WaitPageLoaded(mv.ReviewPaymentPage);

            var payFinalPage =
                reviewPaymentPage.
                    Click(mv.Button, "Next").
                    Site().WaitPageLoaded(mv.PayFinalPage);

            payFinalPage.
                CheckDisplayed(_.Label, caption: "Your payment has been processed").
                Site().LoadPage(mv.HomePage);
        }


        private static Account CreateCorporateAccount(string userNamePrevix)
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrevix);
            CapabilityManager.GrantApplicationLogonCapability(corpAcc._AccountID.Value, "MPS");
            env.ProlongatePassword(corpAcc);
            return corpAcc;
        }


        private static CreditCardPaymentMethod
            NewCreditCard(
                string accountNumber,
                CreditCardType creditCardType,
                int priority
            ) {
            return
                (new CreditCardPaymentMethod {
                    City = "City",
                    Country = PaymentMethodCountry.USA,
                    FirstName = "FirstName",
                    LastName = "LastName",
                    MiddleName = "M",
                    MaxChargePerCycle = 10000,
                    Priority = priority,
                    State = "MA",
                    Street = "Street",
                    Street2 = "Street2",
                    ZipCode = "12345",
                    CreditCardType = creditCardType,
                    AccountNumber = accountNumber,
                    CVNumber = "111",
                    ExpirationDate = "12/2017",
                    ExpirationDateFormat = MTExpDateFormat.MT_MM_slash_YYYY,
                    StartDate = "01/20/2013",
                });
        }

        private static ACHPaymentMethod
            NewAch(
                string number,
                string bankName,
                int priority
            ) {
            return
                (new ACHPaymentMethod {
                    City = "City",
                    Country = PaymentMethodCountry.USA,
                    FirstName = "FirstName",
                    LastName = "LastName",
                    MiddleName = "M",
                    MaxChargePerCycle = 10000,
                    Priority = priority,
                    State = "MA",
                    Street = "Street",
                    Street2 = "Street2",
                    ZipCode = "95345",
                    AccountNumber = number,
                    RoutingNumber = number,
                    AccountType = BankAccountType.Checking,
                    BankAddress = "BankAddress",
                    BankCity = "BankCity",
                    BankState = "BankState",
                    BankZipCode = "12345",
                    BankCountry = PaymentMethodCountry.USA,
                    BankName = bankName,
                });
        }

        #endregion TestHelpers
    }
}
