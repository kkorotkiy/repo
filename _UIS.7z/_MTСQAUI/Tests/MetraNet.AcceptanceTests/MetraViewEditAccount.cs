﻿using MetraTech.DomainModel.BaseTypes;
using MetraTech.TestSystem.Interaction;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetraTech.TestComponents.MetraView;
using MetraTech.WebComponents.WebForms;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mv = MetraTech.WebComponents.WebControls.MetraView;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class MetraViewEditAccount : MetraViewTestSuite
    {
        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies that account invoice method can be changed in MetraView both ways as manually so by ""Going Green?"" widget.")]
        public void ChangeAccountInvoiceMethodTest()
        {
            var homePage = WebSite.LogInAsAdmin();

            // =====-- BEGIN CHECK: Invoice method set to "None" if "paperless billing" enabled --=========
            var invoiceMethodPage =
                homePage.
                    NavigateMetraView(
                        tab: "Account Info",
                        nestedTab: "Invoice Method"
                    ).Site().WaitPageLoaded(mv.InvoiceMethodPage);

            invoiceMethodPage.
                CheckDisplayed(mv.DataPane, "Going Green?", displayed: false).
                ValidateComboBoxValue(caption: "Paper Invoice", expectedValue: "None");
            // =====-- END CHECK: Invoice method set to "None" if "paperless billing" enabled --===========
            
            // =====-- BEGIN CHECK: Change invoice method, "Going Green?" widget appears --================
            var accountInfoSuccessPage =
                invoiceMethodPage.
                    EnterComboBoxValue(caption: "Paper Invoice", value: "Standard").
                    Click(_.Button, "OK").
                    Site().WaitPageLoaded(mv.AccountInfoSuccessPage);

            accountInfoSuccessPage.
                CheckDisplayed(_.Any, "Your account information was successfully updated.").
                CheckDisplayed(mv.DataPane, "Going Green?");
            // =====-- END CHECK: Change invoice method, "Going Green?" widget appears --==================

            // =====-- BEGIN CHECK: After "paperless billing" enabled, "Going Green?" widget disappers --==
            homePage =
                accountInfoSuccessPage.
                    GetForm(mv.DataPane, "Going Green?").
                    Click(_.Link, "paperless billing").
                    Site().WaitPageLoaded(mv.GoPaperlessPage).
                    Click(_.Button, "Yes").
                    Site().WaitPageLoaded(mv.HomePage);

            var accountInfoPage =
                homePage.
                    GetForm(mv.DataPane, "Account Information").
                    Click(mv.Button, "Edit Account").
                    Site().WaitPageLoaded(mv.AccountInfoPage);

            invoiceMethodPage =
                accountInfoPage.
                    NavigateMetraView(nestedTab: "Invoice Method").
                    Site().WaitPageLoaded(mv.InvoiceMethodPage);

            invoiceMethodPage.
                CheckDisplayed(mv.DataPane, "Going Green?", displayed: false).
                ValidateComboBoxValue(caption: "Paper Invoice", expectedValue: "None");
            // =====-- END CHECK: After "paperless billing" enabled, "Going Green?" widget disappers --====

            WebSite.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verify in MetraView that account information could be updated and changes are saved and displayed.")]
        public void ChangeAccountDetailsTest()
        {
            const string expectedAccountInfo =
                ("FirstNameUpd"
                 + " " + "LastNameUpd"
                 + "\r\n" + "MetraTech"
                 + "\r\n" + "1st Avenue"
                 + "\r\n" + "CityUpd"
                 + ", " + "11222"
                );
            var corpAcc = CreateCorporateAccount("CorpMvUpd");
            CapabilityManager.GrantCapability("Update Corporate Accounts", corpAcc._AccountID.Value);

            var homePage = WebSite.LogIn(corpAcc);
          
            var accountInfoPage =
                homePage
                    .GetForm(mv.DataPane, "Account Information")
                    .Click(mv.Button, "Edit Account")
                    .Site().WaitPageLoaded(mv.AccountInfoPage)
                    ;
            var accountInfoSuccessPage =
                accountInfoPage
                    .EnterTextBoxValue("FirstNameUpd", caption: "First Name")
                    .ClearTextBoxValue(caption: "Middle Initial")
                    .EnterTextBoxValue("LastNameUpd", caption: "Last Name")
                    .EnterTextBoxValue("taTeam@metratech.com", caption: "Email")
                    .EnterTextBoxValue("MetraTech", caption: "Company")
                    .EnterTextBoxValue("1st Avenue", caption: "Address1")
                    .ClearTextBoxValue(caption: "Address2")
                    .ClearTextBoxValue(caption: "Address3")
                    .EnterTextBoxValue("CityUpd", caption: "City")
                    .EnterTextBoxValue("11222", caption: "Zip")
                    .ClearTextBoxValue(caption: "State")
                    .EnterComboBoxValue("USA", caption: "Country")
                    .Click(_.Button, "OK")
                    .Site().WaitPageLoaded(mv.AccountInfoSuccessPage)
                    ;
            accountInfoSuccessPage.CheckDisplayed(_.Any, "Your account information was successfully updated.");

            var logInPage = accountInfoSuccessPage.LogOut();

            homePage = logInPage.LogIn(corpAcc);
            homePage.ValidateElementValue(control: mv.DataPaneInfo, expectedValue: expectedAccountInfo);
            homePage.LogOut();
        }

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verify in MetraView that account password could be updated and changes are saved and displayed.")]
        public void ChangeAccountPasswordTest()
        {
            var corpAcc = CreateCorporateAccount("CorpMvUpdPwd");
            CapabilityManager.GrantCapability("Manage Subscriber Auth", corpAcc._AccountID.Value);
         
            var corpAccNewPassword = env.Password.Format(corpAcc.Password_);
          
            var homePage = WebSite.LogIn(corpAcc);

            var accountInfoPage =
                homePage.
                    GetForm(mv.DataPane, "Account Information").
                    Click(mv.Button, "Edit Account").
                    Site().WaitPageLoaded(mv.AccountInfoPage);

            var changePasswordPage =
                accountInfoPage.
                    NavigateMetraView(nestedTab: "Change Password").
                    Site().WaitPageLoaded(mv.ChangePasswordPage);

            var changePasswordSuccessPage =
                changePasswordPage.
                    EnterTextBoxValue(caption: "Old Password", value: corpAcc.Password_).
                    EnterTextBoxValue(caption: "New Password", value: corpAccNewPassword).
                    EnterTextBoxValue(caption: "Confirm Password", value: corpAccNewPassword).
                    Click(_.Button, "OK").
                    Site().WaitPageLoaded(mv.ChangePasswordSuccessPage);

            //====- BEGIN VALIDATION: Check the message "Your password was changed successfully." is displayed on the page -===================
            var logInPage =
                changePasswordSuccessPage.
                    CheckDisplayed(_.Any, "Your password was changed successfully.").
                    Page().LogOut();
            //====- END VALIDATION: Check the message "Your password was changed successfully." is displayed on the page -=====================

            //====- BEGIN VALIDATION: Log in to MetraView using the new credentials and check if UserName displayed on the Home page. -========
            homePage =
                logInPage.LogIn(
                    userName: corpAcc.UserName,
                    password: corpAccNewPassword
                    );
            homePage.
            CheckDisplayed(mv.TextFieldValue, @Array("Account Name", corpAcc.UserName)).
            CheckDisplayed(mv.TextFieldValue, @Array("Account Number", corpAcc._AccountID.Value));
            //====- END VALIDATION: Log in to MetraView using the new credentials and check if UserName displayed on the Home page. -==========
            homePage.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private static Account CreateCorporateAccount(string userNamePrevix)
        {
          var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrevix);
          CapabilityManager.GrantApplicationLogonCapability(corpAcc._AccountID.Value, "MPS");
          CapabilityManager.GrantCapability("Update Subscriber Accounts", corpAcc._AccountID.Value);
          env.ProlongatePassword(corpAcc);
          return corpAcc;
        }

        #endregion TestHelpers
    }
}
