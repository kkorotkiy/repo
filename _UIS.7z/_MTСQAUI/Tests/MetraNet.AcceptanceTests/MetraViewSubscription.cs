﻿using MetraTech.TestSystem.Interaction;
using MetraTech.WebComponents.WebForms;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebComponents.WebForms;
using MetraTech.TestComponents.MetraView;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mv = MetraTech.WebComponents.WebControls.MetraView;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class MetraViewSubscription : MetraViewTestSuite
    {
        #region Constants

        const string RcPoDisplayName = "Recurring Charges Product Offering - Localized";
        const string RcPoDescription = "Recurring Charges Product Offering - Localized";

        const string GroupPoDisplayName = "GROUP_USAGE_Simple_PO display name";
        const string GroupPoDescription = "GROUP_USAGE_Simple_PO description";

        #endregion Constants

        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies in MetraView ability of subscribing a Corporate account to a product offering, i.e. add subscription to the account.")]
        public void AddSubscriptionTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", "corpMVAddSubscr");
            CapabilityManager.GrantApplicationLogonCapability(corpAcc._AccountID.Value, "MPS");
            CapabilityManager.GrantCapability("Create Subscription", corpAcc._AccountID.Value);
            CapabilityManager.GrantCapability("View Subscriptions", corpAcc._AccountID.Value);
            env.ProlongatePassword(corpAcc);

            var homePage = WebSite.LogIn(corpAcc);

            //=================-- BEGIN: Add RC PO --==============================
            var subscriptionsPage = homePage.NavigateMetraView(tab: "My Subscriptions");
            homePage = AddSubscription(subscriptionsPage, RcPoDisplayName, RcPoDescription);
            ValidateSubscriptions(homePage, RcPoDisplayName);
            //=================-- END: Add RC PO --================================

            //=================-- BEGIN: Add Group PO --===========================
            subscriptionsPage =
                homePage.
                    Click(mv.Button, caption: "Add Subscription").
                    Site().WaitPageLoaded(mv.SubscriptionsPage);

            homePage = AddSubscription(subscriptionsPage, GroupPoDisplayName, GroupPoDescription);
            ValidateSubscriptions(homePage, GroupPoDisplayName);
            //=================-- END: Add Group PO --=============================

            homePage.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private static WebPage
            AddSubscription(
                WebPage subscriptionsPage,
                string poDisplayName,
                string poDescription
            ) {
            var poFullName = (poDisplayName+"---"+poDescription);
            var homePage =
                subscriptionsPage
                    .EnterCheckBoxValue(caption: poFullName, value: true)
                    .Click(_.Button, "OK")
                    .Site().WaitPageLoaded(mv.HomePage)
                    ;
            return homePage;
        }

        private static void
            ValidateSubscriptions(
                WebPage homePage,
                string poDisplayName
            ) {
            homePage.
                GetForm(mv.DataPane, "My Subscriptions").
                CheckDisplayed(_.Label, poDisplayName).
                GetForm(mv.NestedDataPane, caption: "Available Product Offerings").
                CheckDisplayed(_.Label, poDisplayName, displayed: false);
        }

        #endregion TestHelpers
    }
}
