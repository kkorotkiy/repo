﻿using MetraTech.DomainModel.AccountTypes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MetraTech.TestSystem.Interaction;
using MetraTech.TestComponents.MetraNet;
using MetraTech.WebComponents.WebForms;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;


namespace MetraNet.AcceptanceTests
{
    [TestClass]
    public class UpdateAccount : MetraNetTestSuite
    {
        #region Tests

        [TestMethod]
        [TestCategory(UITestCategory)]
        [Description(@"Verifies that CoreSubscriber properties can be updated and account can be moved under other parent within the hierarchy by updating ""Parent Account"" property.")]
        public void UpdateCoreSubscriberAccountTest()
        {
            var corpAcc = AccountManager.AddNewAccount("CorporateAccount.xml", userNamePrefix: "corpUpdSubAcc");
            var depAcc = AccountManager.AddNewAccount("DepartmentAccount.xml", userNamePrefix: "depUpdSubAcc", ancestor: corpAcc);
            var subscrAcc = AccountManager.AddNew<CoreSubscriber>("SubscriberAccount.xml", userNamePrefix: "subAccUpd", ancestor: depAcc);

            var corpAccFriendlyUserName = AccountManager.FormatFriendlyUserName(corpAcc);
            var corpAccDisplayName = AccountManager.FormatDisplayName(corpAcc, friendly: true);
            var subscrAccContactView = subscrAcc.LDAP[0];
            var subscrAccDisplayName = AccountManager.FormatDisplayName(subscrAcc);

            var mainPage = WebSite.LogInAsAdmin();
            var updateAccountFrame =
                mainPage
                    .LoadAccountSummaryFrame(
                        enterValue: subscrAcc.UserName,
                        dropdownValue: subscrAccDisplayName
                    ).NavigateAccountToolbarToFrame(
                        "Account",
                        "Update Account"
                    );
            var accountDetailsFrame =
                UpdateAccountProperties(
                    updateAccountFrame,
                    corpAccDisplayName
                    );
            //====- VALIDATION STAFF -========
            ValidateAccountDetails(
                accountDetailsFrame,
                subscrAcc.UserName,
                corpAccDisplayName
                );
            mainPage.SwitchToForm();
            var accountSummaryFrame =
                mainPage
                    .Click(_.Button, subscrAccDisplayName)
                    .Page().GetFrame("Account 360")
                    ;
            ValidateAccountSummaryFrame(
                accountSummaryFrame,
                subscrAccDisplayName,
                subscrAccContactView
                );
            ValidateSubscriberAccountHierarchyTab(
                mainPage,
                accountDetailsFrame,
                corpAccFriendlyUserName,
                subscrAccDisplayName,
                subscrAccContactView
                );
            WebSite.LogOut();
        }

        #endregion Tests

        #region TestHelpers

        private static WebForm
            UpdateAccountProperties(
                WebForm updateAccFrame,
                string corpAccDisplayName
            ) {
            updateAccFrame.
                EnterTextBoxValue(caption: "Last Name", value: "CoreSubscriberUpd").
                EnterTextBoxValue(caption: "City", value: "Boston").
                EnterCheckBoxValue(caption: "Billable", value: false).
                EnterCheckBoxValue(caption: "MetraTax Has Override Band", value: true).
                EnterComboBoxValue(caption: "Billing Cycles", value: "Daily").
                EnterComboBoxValue(caption: "Country", value: "USA").
                EnterTextBoxValue(caption: "Parent Account", value: corpAccDisplayName).
                EnterTextBoxValue(caption: "Payer", value: corpAccDisplayName).
                Click(_.Button, "OK");

            var accountUpdatedFrame =
                updateAccFrame.
                    Page().GetFrame("Account Updated").
                    CheckDisplayed(_.Label, "The account was updated successfully.");

            var accountDetailsFrame =
                accountUpdatedFrame.
                    Click(_.Button, "OK").
                    Page().GetFrame("Account 360").
                    NavigateAccountToolbarToFrame(
                        menu: "Account",
                        menuItem: "Account Details",
                        caption: "Account Summary"
                    );
            return accountDetailsFrame;
        }

        private static void
            ValidateAccountDetails(
                WebForm accountDetailsFrame,
                string subscrUserName,
                string corpAccDisplayName
            ) {
            accountDetailsFrame.
                ExpandForm(mt.DataPane, "Billing Information").
                ValidateTextBoxValue(caption: "Last Name", expectedValue: "CoreSubscriberUpd").
                ValidateTextBoxValue(caption: "City", expectedValue: "Boston").
                ValidateTextFieldValue(caption: "Country", expectedValue: "USA").
                Collapse();

            accountDetailsFrame.
                ExpandForm(mt.DataPane, "Login Information").
                ValidateTextBoxValue(caption: "User name", expectedValue: subscrUserName).
                ValidateTextFieldValue(caption: "Parent Id", expectedValue: corpAccDisplayName).
                Collapse();

            accountDetailsFrame.
                ExpandForm(mt.DataPane, "Account Information").
                ValidateTextBoxValue(caption: "Billable", expectedValue: "False").
                ValidateTextFieldValue(caption: "Payer Id", expectedValue: corpAccDisplayName).
                ValidateTextFieldValue(caption: "Billing Cycles", expectedValue: "Daily").
                Collapse();

            accountDetailsFrame.
                ExpandForm(mt.DataPane, "Tax").
                ValidateTextBoxValue(caption: "MetraTax Has Override Band", expectedValue: "True").
                Collapse();
        }

        private static void
            ValidateAccountSummaryFrame(
                WebForm accountSummaryFrame,
                string accountDisplayName,
                ContactView accountContactView
            ) {
            var accountFriendlyUserName = (accountContactView.FirstName+" CoreSubscriberUpd");
            accountSummaryFrame.
                CheckDisplayed(_.Label, accountFriendlyUserName).
                CheckDisplayed(_.Label, accountContactView.Company).
                CheckDisplayed(_.Label, accountDisplayName);
        }

        private static void
            ValidateSubscriberAccountHierarchyTab(
                WebPage mainPage,
                WebForm accountDetailsFrame,
                string corpFriendlyUserName,
                string subscrDisplayName,
                ContactView subscrContactView
            ) {
            var accountSidebar =
                accountDetailsFrame.
                    Page().Click(mn.ToolButton_HierarchyFind).
                    GetForm(mn.Sidebar, "east");

            var accountFriendlyUserName = (subscrContactView.FirstName+" CoreSubscriberUpd");
            accountSidebar.
                CheckDisplayed(_.Label, subscrDisplayName).
                CheckDisplayed(_.Label, accountFriendlyUserName).
                CheckDisplayed(_.Label, subscrContactView.Company).
                CheckDisplayed(_.Label, string.Format("{0}, {1} {2}", "Boston", subscrContactView.State, subscrContactView.Zip)).
                CheckDisplayed(_.Label, "USA");

            accountSidebar.ClickWithReload(mn.ToolButton_HierarchyRefresh);
            mainPage.Click(mn.ToolButton_HierarchyFind);

            accountSidebar.
                ExpandForm(mt.TreeNode, "Hierarchy").
                ExpandForm(mt.TreeNode, corpFriendlyUserName).
                CheckDisplayed(mt.TreeLeaf, accountFriendlyUserName).
                Collapse();

            accountSidebar.Collapse();
        }

        #endregion TestHelpers
    }
}