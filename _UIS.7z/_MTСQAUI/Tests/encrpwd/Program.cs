﻿using System;
using System.Security.Cryptography;
using System.Text;
using MetraTech.Security.Crypto;


namespace encrpwd
{
    static class Program
    {
        #region Properties and Fields

        private static readonly CryptoManager
            CryptoManager = (new CryptoManager());

        #endregion Properties and Fields

        static void Main(string[] args)
        {
            string userName, nameSpace, password;

            InitArgs(out userName, out nameSpace, out password, args);
            var encryptedPassword = EncryptPassword(userName, nameSpace, password);

            var origForegroundColor = Console.ForegroundColor;
            Console.ForegroundColor = Console.BackgroundColor;
            Console.WriteLine(encryptedPassword);
            Console.ForegroundColor = origForegroundColor;
        }

        private static void
            InitArgs(
                out string userName, 
                out string nameSpace, 
                out string password,
                string [] args
            ) {
            if (args.Length > 2) {
                userName = args[0];
                nameSpace = args[1];
                password = args[2];
            } else {
                userName = Console.ReadLine();
                nameSpace = Console.ReadLine();
                password = Console.ReadLine();
            }
        }

        #region Encrypt Password

        private static string
            EncryptPassword(
                string userName,
                string nameSpace,
                string password
            ) {
            var saltedPassword = SaltPassword(userName, nameSpace, password);
            var encryptedPassword = CryptoManager.Hash(HashKeyClass.PasswordHash, saltedPassword);
            return encryptedPassword;
        }

        private static string
            SaltPassword(
                string userName,
                string nameSpace,
                string password
            ) {
            userName = userName.ToLower();
            nameSpace = nameSpace.ToLower();
            var md5 = GetMD5(password);
            var saltedPassword = (md5 + userName + nameSpace);
            return saltedPassword;
        }

        private static string
            GetMD5(
                string plainText
            ) {
            using (MD5 md5 = MD5.Create()) {
                byte[] hash = md5.ComputeHash(Encoding.Default.GetBytes(plainText));
                var hashBuilder = (new StringBuilder());
                for (int index = 0; index < hash.Length; ++index) {
                    hashBuilder.Append(hash[index].ToString("x2"));
                }
                return hashBuilder.ToString();
            }
        }

        #endregion Encrypt Password
    }
}
