﻿using System.Linq;
using OpenQA.Selenium;
using UtilityComponents;
using WebComponents.WebElements;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;


namespace MetraTech.WebComponents.WebForms
{
    public enum DataInputMode : byte {
        Enter = 0,
        Submit = 10,
        Dropdown = 20,
        Mixed = 30,
    }



    public static class WebFormExt
    {
        #region VRCE Value

        #region Validate Value

        public static WebForm
            ValidateTextFieldValue<
                TValue>(
                this WebForm webForm,
                TValue expectedValue,
                object caption,
                bool @equals = true,
                ulong timeout = ulong.MinValue,
                string message = null
            ) {
            return
                webForm.
                    ValidateElementValue(
                        expectedValue,
                        mt.TextField,
                        caption,
                        @equals,
                        timeout,
                        message
                    );
        }

        public static WebForm
            ValidateTextBoxValue<
                TValue>(
                this WebForm webForm,
                TValue expectedValue,
                object caption,
                bool @equals = true,
                ulong timeout = ulong.MinValue,
                string message = null
            ) {
            return
                webForm.
                    ValidateTextBoxValue(
                        expectedValue,
                        mt.TextBox,
                        caption,
                        @equals,
                        timeout,
                        message
                    );
        }

        public static WebForm
            ValidateCheckBoxValue(
                this WebForm webForm,
                bool? expectedValue,
                object caption,
                bool @equals = true,
                ulong timeout = ulong.MinValue,
                string message = null
            ) {
            return
                webForm.
                    ValidateCheckBoxValue(
                        expectedValue,
                        mt.CheckBox,
                        caption,
                        @equals,
                        timeout,
                        message
                    );
        }

        #region ValidateComboBoxValue

        public static WebForm
            ValidateComboBoxValue<
                TValue>(
                this WebForm webForm,
                TValue expectedValue,
                string control = mt.ComboBox,
                object caption = null,
                bool @equals = true,
                ulong timeout = ulong.MinValue,
                string message = null
            ) {
            bool isValid;
            return
                ValidateComboBoxValue(
                    webForm,
                    out isValid,
                    expectedValue,
                    @equals,
                    control,
                    caption,
                    timeout,
                    throwOnFailure: true,
                    message: message
                    );
        }

        public static WebForm
            ValidateComboBoxValue<
                TValue>(
                this WebForm webForm,
                out bool isValid,
                TValue expectedValue,
                bool @equals,
                string control = mt.ComboBox,
                object caption = null,
                ulong timeout = ulong.MinValue,
                bool throwOnFailure = true,
                string message = null
            ) {
            var actualValue =
                ReadComboBoxValue<
                    TValue>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
            isValid =
                global::
                    WebComponents.WebForms.WebFormExt.
                    ValidateValue(
                        expectedValue,
                        actualValue,
                        @equals,
                        throwOnFailure,
                        (message ?? global::WebComponents.WebForms.WebFormExt.ValidateValueMessageFormat),
                        parameters: (new[] {webForm.FullName, control, caption})
                    );
            return
                webForm;
        }

        #endregion ValidateComboBoxValue

        #region ValidateFindBoxValue

        public static WebForm
            ValidateFindBoxValue<
                TValue>(
                this WebForm webForm,
                TValue expectedValue,
                string control = mt.FindBox,
                object caption = null,
                bool @equals = true,
                ulong timeout = ulong.MinValue,
                string message = null
            ) {
            bool isValid;
            return
                ValidateFindBoxValue(
                    webForm,
                    out isValid,
                    expectedValue,
                    @equals,
                    control,
                    caption,
                    timeout,
                    throwOnFailure: true,
                    message: message
                    );
        }

        public static WebForm
            ValidateFindBoxValue<
                TValue>(
                this WebForm webForm,
                out bool isValid,
                TValue expectedValue,
                bool @equals,
                string control = mt.FindBox,
                object caption = null,
                ulong timeout = ulong.MinValue,
                bool throwOnFailure = true,
                string message = null
            ) {
            var actualValue =
                ReadFindBoxValue<
                    TValue>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
            isValid =
                global::
                    WebComponents.WebForms.WebFormExt.
                    ValidateValue(
                        expectedValue,
                        actualValue,
                        @equals,
                        throwOnFailure,
                        (message ?? global::WebComponents.WebForms.WebFormExt.ValidateValueMessageFormat),
                        parameters: (new[] {webForm.FullName, control, caption})
                    );
            return
                webForm;
        }

        #endregion ValidateFindBoxValue

        #endregion Validate Value

        #region Read Value

        public static TValue
            ReadTextFieldValue<
                TValue>(
                this WebForm webForm,
                object caption,
                ulong timeout = ulong.MinValue
            ) {
            return
                webForm.
                    ReadElementValue<
                        TValue>(
                        mt.TextField,
                        caption,
                        timeout
                    );
        }

        public static TValue
            ReadTextBoxValue<
                TValue>(
                this WebForm webForm,
                object caption,
                ulong timeout = ulong.MinValue
            ) {
            return
                webForm.
                    ReadTextBoxValue<
                        TValue>(
                        mt.TextBox,
                        caption,
                        timeout
                    );
        }

        public static bool?
            ReadCheckBoxValue(
                this WebForm webForm,
                object caption,
                ulong timeout = ulong.MinValue
            ) {
            return
                webForm.
                    ReadCheckBoxValue(
                        mt.CheckBox,
                        caption,
                        timeout
                    );
        }

        public static TValue
            ReadComboBoxValue<
                TValue>(
                this WebForm webForm,
                string control = mt.ComboBox,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                webForm.
                    ReadElementValue<
                        TValue,
                        TextBoxWebElement>(
                        control,
                        caption,
                        timeout
                    );
        }

        public static TValue
            ReadFindBoxValue<
                TValue>(
                this WebForm webForm,
                string control = mt.FindBox,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                webForm.
                    ReadElementValue<
                        TValue,
                        TextBoxWebElement>(
                        control,
                        caption,
                        timeout
                    );
        }

        #endregion Read Value

        #region Clear Value

        public static WebForm
            ClearTextBoxValue(
                this WebForm webForm,
                object caption,
                ulong timeout = ulong.MinValue
            ) {
            return
                webForm.
                    ClearTextBoxValue(
                        mt.TextBox,
                        caption,
                        timeout
                    );
        }

        public static WebForm
            ClearCheckBoxValue(
                this WebForm webForm,
                object caption,
                ulong timeout = ulong.MinValue
            ) {
            return
                webForm.
                    ClearCheckBoxValue(
                        mt.CheckBox,
                        caption,
                        timeout
                    );
        }

        public static WebForm
            ClearComboBoxValue(
                this WebForm webForm,
                string control = mt.ComboBox,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                webForm.
                    ClearElementValue<
                        TextBoxWebElement>(
                            control,
                            caption,
                            timeout
                    );
        }

        public static WebForm
            ClearFindBoxValue(
                this WebForm webForm,
                string control = mt.FindBox,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                webForm.
                    ClearElementValue<
                        TextBoxWebElement>(
                            control,
                            caption,
                            timeout
                    );
        }

        #endregion Clear Value

        #region Enter Value

        public static WebForm
            EnterTextBoxValue<
                TValue>(
                this WebForm webForm,
                TValue value,
                object caption,
                bool clear = true,
                bool submit = false,
                ulong timeout = ulong.MinValue
            ) { return webForm.EnterTextBoxValue(value, mt.TextBox, caption, clear, submit, timeout); }

        public static WebForm
            EnterCheckBoxValue(
                this WebForm webForm,
                bool? value,
                object caption,
                ulong timeout = ulong.MinValue
            ) { return webForm.EnterCheckBoxValue(value, mt.CheckBox, caption, timeout); }

        #region EnterComboBoxValue

        public static WebForm
            EnterComboBoxValue<
                TValue>(
                this WebForm webForm,
                TValue value,
                string control = mt.ComboBox,
                object caption = null,
                DataInputMode mode = DataInputMode.Dropdown,
                bool clear = true,
                ulong timeout = ulong.MinValue
            ) { return EnterComboBoxValue<object>(webForm, value, null, control, caption, mode, clear, timeout); }

        public static WebForm
            EnterComboBoxValue<
                TValue>(
                this WebForm webForm,
                TValue enterValue,
                TValue dropdownValue,
                string control = mt.ComboBox,
                object caption = null,
                DataInputMode mode = DataInputMode.Dropdown,
                bool clear = true,
                ulong timeout = ulong.MinValue
            ) {
            var enterValueIsNull = ReferenceEquals(enterValue, null);
            var dropdownValueIsNull = ReferenceEquals(dropdownValue, null);
            var useDropdownMode = (mode == DataInputMode.Dropdown);

            if (enterValueIsNull && dropdownValueIsNull && useDropdownMode
                || enterValueIsNull && !useDropdownMode
               ) {
                return webForm;
            }
            var textBoxInfo = webForm.GetElement<TextBoxWebElement>(control, caption);
            var textBox = textBoxInfo.Find<TextBoxWebElement>(timeout);

            var openDropdownButtonXPath = webForm.Site().GetXPath(mt.ToolButton_Open_ComboBoxDropdown);
            var openDropdownButton = WebElementInfo.New(textBoxInfo, openDropdownButtonXPath);

            string dropdownElementControl;
            TValue dropdownElementCaption;
            var single = !dropdownValueIsNull;
            if (single) {
                dropdownElementControl = mt.ComboBoxDropdownElementSingle;
                dropdownElementCaption = dropdownValue;
            } else {
                dropdownElementControl = mt.ComboBoxDropdownElement;
                dropdownElementCaption = enterValue;
            }
            var dropdownElementXPath = webForm.Site().FormatXPath(dropdownElementControl, dropdownElementCaption);
            var dropdownElement = WebElementInfo.New(dropdownElementXPath);

            var dropdownXPath = webForm.Site().GetXPath(mt.ComboBoxDropdown);
            var dropdown = WebElementInfo.New(dropdownElement, dropdownXPath);

            switch (mode) {
                default: goto case DataInputMode.Enter;
                case DataInputMode.Enter: {
                    textBox.EnterValue(enterValue, clear);
                    if (dropdown.WaitDisplayedAny(true, 640UL, throwTimedOut: false)) {
                        textBox.EnterValue(Keys.Delete, clear: false);
                        textBox.EnterValue(Keys.Escape, clear: false);
                        dropdown.WaitDisplayedAny(false, timeout, throwTimedOut: false);
                    }
                    break;
                }
                case DataInputMode.Submit: {
                    textBox.EnterValue(enterValue, clear);
                    var dropdownDisplayed = dropdown.WaitDisplayedAny(true, 640UL, throwTimedOut: false);
                    textBox.EnterValue(Keys.Enter, clear: false);
                    if (dropdownDisplayed) {
                        dropdown.WaitDisplayedAny(false, timeout, throwTimedOut: false);
                    }
                    break;
                }
                case DataInputMode.Dropdown: {
                    openDropdownButton.Click(timeout);
                    dropdown.WaitDisplayedAny(true, timeout);
                    if (single) {
                        dropdownElement.FindAll(timeout).Single(webel => webel.Displayed.IsTrue()).Click();
                    } else {
                        dropdownElement.FindAll(timeout).First(webel => webel.Displayed.IsTrue()).Click();
                    }
                    dropdown.WaitDisplayedAny(false, timeout);
                    break;
                }
                case DataInputMode.Mixed: {
                    textBox.EnterValue(enterValue, clear);
                    dropdown.WaitDisplayedAny(true, timeout);
                    if (single) {
                        dropdownElement.FindAll(timeout).Single(webel => webel.Displayed.IsTrue()).Click();
                    } else {
                        dropdownElement.FindAll(timeout).First(webel => webel.Displayed.IsTrue()).Click();
                    }
                    dropdown.WaitDisplayedAny(false, timeout);
                    break;
                }
            }
            return webForm;
        }

        #endregion EnterComboBoxValue

        #region EnterFindBoxValue

        public static WebForm
            EnterFindBoxValue<
                TValue>(
                this WebForm webForm,
                TValue value,
                string control = mt.FindBox,
                object caption = null,
                DataInputMode mode = DataInputMode.Mixed,
                bool clear = true,
                ulong timeout = ulong.MinValue
            ) { return EnterFindBoxValue<object>(webForm, value, null, control, caption, mode, clear, timeout); }

        public static WebForm
            EnterFindBoxValue<
                TValue>(
                this WebForm webForm,
                TValue enterValue,
                TValue dropdownValue,
                string control = mt.FindBox,
                object caption = null,
                DataInputMode mode = DataInputMode.Mixed,
                bool clear = true,
                ulong timeout = ulong.MinValue
            ) {
            if (ReferenceEquals(enterValue, null)) {
                return webForm;
            }
            var textBoxInfo = webForm.GetElement<TextBoxWebElement>(control, caption);
            var textBox = textBoxInfo.Find<TextBoxWebElement>(timeout);

            string dropdownElementControl;
            TValue dropdownElementCaption;
            var single = !ReferenceEquals(dropdownValue, null);
            if (single) {
                dropdownElementControl = mt.FindBoxDropdownElementSingle;
                dropdownElementCaption = dropdownValue;
            } else {
                dropdownElementControl = mt.FindBoxDropdownElement;
                dropdownElementCaption = enterValue;
            }
            var dropdownElementXPath = webForm.Site().FormatXPath(dropdownElementControl, dropdownElementCaption);
            var dropdownElement = WebElementInfo.New(dropdownElementXPath);

            var dropdownXPath = webForm.Site().GetXPath(mt.FindBoxDropdown);
            var dropdown = WebElementInfo.New(dropdownElement, dropdownXPath);

            switch (mode) {
                default: goto case DataInputMode.Enter;
                case DataInputMode.Enter: {
                    textBox.EnterValue(enterValue, clear);
                    if (dropdown.WaitDisplayedAny(true, 1280UL, throwTimedOut: false)) {
                        textBox.EnterValue(Keys.Escape, clear: false);
                        dropdown.WaitDisplayedAny(false, timeout, throwTimedOut: false);
                    }
                    break;
                }
                case DataInputMode.Submit: {
                    textBox.EnterValue(enterValue, clear);
                    var dropdownDisplayed = dropdown.WaitDisplayedAny(true, 1280UL, throwTimedOut: false);
                    textBox.EnterValue(Keys.Enter, clear: false);
                    if (dropdownDisplayed) {
                        dropdown.WaitDisplayedAny(false, timeout, throwTimedOut: false);
                    }
                    break;
                }
                case DataInputMode.Dropdown: goto case DataInputMode.Mixed;
                case DataInputMode.Mixed: {
                    textBox.EnterValue(enterValue, clear);
                    dropdown.WaitDisplayedAny(true, timeout);
                    if (single) {
                        dropdownElement.FindAll(timeout).Single(webel => webel.Displayed.IsTrue()).Click();
                    } else {
                        dropdownElement.FindAll(timeout).First(webel => webel.Displayed.IsTrue()).Click();
                    }
                    dropdown.WaitDisplayedAny(false, timeout);
                    break;
                }
            }
            return webForm;
        }

        #endregion EnterFindBoxValue

        #endregion Enter Value

        #endregion VRCE Value
    }
}
