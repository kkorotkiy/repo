﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using UtilityComponents;
using WebComponents;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraTech.WebComponents
{
    [Flags]
    public enum LocalizationSite : byte {
        None = byte.MinValue,
        MetraNet = 1,
        MetraView = 2,
        All = byte.MaxValue,
    }



    public class MetraTechWebSite : WebSite
    {
        #region Properties and Fields

        protected readonly CultureInfo DefaultCulture = CultureInfo.GetCultureInfo("en-US");

        #region MetraNet Localization Resource

        public string
            MetraNetLocalizationResourceFilePath {
            get {
                if (_metraNetLocalizationResourceFilePath == null) {
                    _metraNetLocalizationResourceFilePath =
                        Environment.ExpandEnvironmentVariables(
                            @"%MTRMPBIN%\MetraNetLocalizationResource.xml"
                            );
                }
                return _metraNetLocalizationResourceFilePath;
            }
        }
        private string _metraNetLocalizationResourceFilePath;

        public string
            MetraNetLocalizationResourcesDirectoryPath {
            get {
                if (_metraNetLocalizationResourcesDirectoryPath == null) {
                    _metraNetLocalizationResourcesDirectoryPath =
                        Environment.ExpandEnvironmentVariables(
                            @"%MTRMP%\UI\MetraNet"
                            );
                }
                return _metraNetLocalizationResourcesDirectoryPath;
            }
        }
        private string _metraNetLocalizationResourcesDirectoryPath;

        #endregion MetraNet Localization Resource

        #region MetraView Localization Resource

        public string
            MetraViewLocalizationResourceFilePath {
            get {
                if (_metraViewLocalizationResourceFilePath == null) {
                    _metraViewLocalizationResourceFilePath =
                        Environment.ExpandEnvironmentVariables(
                            @"%MTRMPBIN%\MetraViewLocalizationResource.xml"
                            );
                }
                return _metraViewLocalizationResourceFilePath;
            }
        }
        private string _metraViewLocalizationResourceFilePath;

        public string
            MetraViewLocalizationResourcesDirectoryPath {
            get {
                if (_metraViewLocalizationResourcesDirectoryPath == null) {
                    _metraViewLocalizationResourcesDirectoryPath =
                        Environment.ExpandEnvironmentVariables(
                                @"%MTRMP%\Extensions\MetraView\Sites"
                                );
                }
                return _metraViewLocalizationResourcesDirectoryPath;
            }
        }
        private string _metraViewLocalizationResourcesDirectoryPath;

        #endregion MetraView Localization Resource

        protected readonly Dictionary<LocalizationSite,string> _localizationResourceFilePath;
        protected readonly Dictionary<LocalizationSite, string> _localizationResourcesDirectoryPath;
        protected readonly Dictionary<LocalizationSite, XDocument> _localizationResource;

        #endregion Properties and Fields

        #region C-tors

        protected MetraTechWebSite() {
            _localizationResourceFilePath = (new Dictionary<LocalizationSite, string> {
                {LocalizationSite.MetraNet, MetraNetLocalizationResourceFilePath},
                {LocalizationSite.MetraView, MetraViewLocalizationResourceFilePath},
            });
            _localizationResourcesDirectoryPath = (new Dictionary<LocalizationSite, string> {
                {LocalizationSite.MetraNet, MetraNetLocalizationResourcesDirectoryPath},
                {LocalizationSite.MetraView, MetraViewLocalizationResourcesDirectoryPath},
            });
            _localizationResource = (new Dictionary<LocalizationSite, XDocument> {
                {LocalizationSite.MetraNet, null},
                {LocalizationSite.MetraView, null},
            });
        }

        #endregion C-tors

        #region Load Localization

        public virtual LocalizationSite Localization {
            get { return _localization; }
            set {
                LoadLocalization(value);
                _localization = value;
            }
        }
        private LocalizationSite _localization = LocalizationSite.None;
        protected LocalizationSite _loadedLocalization = LocalizationSite.None;

        
        protected virtual void LoadLocalization(LocalizationSite site)
        {
            if ((_loadedLocalization & site) == site) {
                return;
            }
            if (((site & LocalizationSite.MetraNet) == LocalizationSite.MetraNet)
                && ((_loadedLocalization & LocalizationSite.MetraNet) != LocalizationSite.MetraNet)
               ) {
                LoadLocalizationResource(LocalizationSite.MetraNet);
                _loadedLocalization |= LocalizationSite.MetraNet;
            }
            if (((site & LocalizationSite.MetraView) == LocalizationSite.MetraView)
                && ((_loadedLocalization & LocalizationSite.MetraView) != LocalizationSite.MetraView)
               ) {
                LoadLocalizationResource(LocalizationSite.MetraView);
                _loadedLocalization |= LocalizationSite.MetraView;
            }
        }

        protected virtual void LoadLocalizationResource(LocalizationSite site)
        {
            var localizationResourceFilePath = _localizationResourceFilePath[site];
            var localizationResourceFileExists = File.Exists(localizationResourceFilePath);
            XDocument localizationResource;
            if (localizationResourceFileExists) {
                localizationResource = XDocument.Load(localizationResourceFilePath);
            } else {
                CreateLocalizationResource(out localizationResource, site);
            }
            _localizationResource[site] = localizationResource;
        }

        #region Create Localization Resource

        protected virtual void
            CreateLocalizationResource(
                out XDocument localizationResource,
                LocalizationSite site
            ) {
            var localizationResourcesDirectoryPath =_localizationResourcesDirectoryPath[site];
            var root =
                (new XElement(
                    "LocalizationResource",
                    (new XAttribute("site", site.ToString())),
                    (new XAttribute("source-path", localizationResourcesDirectoryPath)))
                );
            var resourceGroups = CreateLocalizationResourceGroups(localizationResourcesDirectoryPath);
            root.Add(resourceGroups);
            localizationResource = (new XDocument(root));
        }

        protected virtual IEnumerable<XElement>
            CreateLocalizationResourceGroups(
                string resourcesDirectoryPath
            ) {
            var resourceGroups = (new List<XElement>());
            var resourcesDirs = GetAllLocalizationResourcesDirectories(resourcesDirectoryPath);
            var resourceGroupSites =
                resourcesDirs
                    .Select(dir => (new {
                        Directory.GetParent(dir).Name,
                        Type = (new DirectoryInfo(dir)).Name,
                        SourcePath = dir})
                    ).ToList();
            foreach (var resourceGroupSite in resourceGroupSites) {
                var resourceGroup =
                    (new XElement("ResourceGroup",
                        (new XAttribute("site", resourceGroupSite.Name)),
                        (new XAttribute("type", resourceGroupSite.Type)))
                    );
                var resourceSites = CreateLocalizationResourceSites(resourceGroupSite.SourcePath);
                resourceGroup.Add(resourceSites);
                resourceGroups.Add(resourceGroup);
            }
            return resourceGroups;
        }

        protected virtual IEnumerable<XElement>
            CreateLocalizationResourceSites(
                string resourceGroupDirectoryPath
            ) {
            var resourceSites = (new List<XElement>());
            var resourceSiteFilePaths = Directory.GetFiles(resourceGroupDirectoryPath, "*.resx");
            var resourceSiteNames =
                resourceSiteFilePaths
                    .Select(filePath => (Path.GetFileNameWithoutExtension(filePath) ?? "<unknown>"))
                    .Select(fileName => fileName.Split('.')[0])
                    .Distinct();
            foreach (var resourceSiteName in resourceSiteNames) {
                var resourceSite = (new XElement("ResourceSite", (new XAttribute("name", resourceSiteName))));
                var resources = CreateLocalizationResources(resourceGroupDirectoryPath,resourceSiteName);
                resourceSite.Add(resources);
                resourceSites.Add(resourceSite);
            }
            return resourceSites;
        }

        protected virtual IEnumerable<XElement>
            CreateLocalizationResources(
                string resourceGroupDirectoryPath,
                string resourceSiteName
            ) {
            var resources = (new List<XElement>());
            var resourceFileNamePattern = (resourceSiteName + "." + "*resx");
            var resourceFilePaths = Directory.GetFiles(resourceGroupDirectoryPath, resourceFileNamePattern);
            foreach (var resourceFilePath in resourceFilePaths) {
                var resourceFileName = Path.GetFileNameWithoutExtension(resourceFilePath);
                var resourceCulture = Path.GetExtension(resourceFileName);
                if (string.IsNullOrWhiteSpace(resourceCulture)
                    || (resourceCulture == ".aspx")
                    || (resourceCulture == ".ascx")
                   ) {
                    resourceCulture = "en-US";
                } else {
                    resourceCulture = resourceCulture.Substring(1);
                }
                var resource = (new XElement("Resource",(new XAttribute("culture", resourceCulture))));
                PopulateLocalizationResourceWithData(resource, resourceFilePath);
                resources.Add(resource);
            }
            return resources;
        }

        protected virtual void
            PopulateLocalizationResourceWithData(
                XElement resource,
                string resourceFilePath
            ) {
            XDocument resourceDoc = XDocument.Load(resourceFilePath);
            Debug.Assert(resourceDoc.Root != null, "resourceDoc.Root != null");
            var resourceData = resourceDoc.Root.Elements("data").ToList();
            resource.Add(resourceData);
        }

        protected virtual IEnumerable<string>
            GetAllLocalizationResourcesDirectories(
                string rootDirectoryPath
            ) {
            var resourcesDirs = (new List<string>());
            var subDirPaths = Directory.GetDirectories(rootDirectoryPath);
            foreach (var dirPath in subDirPaths) {
                var dir = (new DirectoryInfo(dirPath));
                var dirName = dir.Name;
                if ((dirName == "App_GlobalResources") || (dirName == "App_LocalResources")) {
                    resourcesDirs.Add(dirPath);
                } else {
                    var resourcesSubDirs = GetAllLocalizationResourcesDirectories(dirPath);
                    resourcesDirs.AddRange(resourcesSubDirs);
                }
            }
            return resourcesDirs;
        }

        #endregion Create Localization Resource

        #endregion Load Localization

        #region Unload

        protected override void ProcessUnload(bool force = false)
        {
            base.ProcessUnload(force);
            SaveLocalizationResources(force);
        }

        private void SaveLocalizationResources(bool force = false)
        {
            foreach (var resource in _localizationResource) {
                var localizationSite = resource.Key;
                if ((_loadedLocalization & localizationSite) != localizationSite) {
                    continue;
                }
                var localizationResourceFilePath = _localizationResourceFilePath[localizationSite];
                var localizationResourceFileExists = File.Exists(localizationResourceFilePath);
                if (!force && localizationResourceFileExists) {
                    continue;
                }
                var localizationResource = resource.Value;
                localizationResource.Save(localizationResourceFilePath);
            }
        }

        #endregion Unload

        #region Caption

        public override object[]
            LocalizeCaption(
                params object[] captions
            ) {
            if (Localization == LocalizationSite.None) {
                return base.LocalizeCaption(captions);
            }
            var captionsLength = captions.Length;
            var localizedCaptions = (new object[captionsLength]);
            for (var i = 0; i < captionsLength; i++) {
                object localizedCaption;
                var caption = captions[i];
                var captionStr = (caption as string);
                if (captionStr != null) {
                    localizedCaption = FindLocalizedCaption(captionStr, Localization);
                } else {
                    localizedCaption = caption;
                }
                localizedCaptions[i] = localizedCaption;
            }
            return localizedCaptions;
        }

        protected virtual string
            FindLocalizedCaption(
                string caption,
                LocalizationSite site
            ) {
            var localizedCaption = caption;
            XDocument localizationResource;
            if ((site & LocalizationSite.MetraNet) == LocalizationSite.MetraNet) {
                localizationResource = _localizationResource[LocalizationSite.MetraNet];
                localizedCaption = FindLocalizedCaption(caption, localizationResource);
                if (localizedCaption == null) {
                    localizedCaption = caption;
                } else {
                    return localizedCaption;
                }
            }
            if ((site & LocalizationSite.MetraView) == LocalizationSite.MetraView) {
                localizationResource = _localizationResource[LocalizationSite.MetraView];
                localizedCaption = FindLocalizedCaption(caption, localizationResource);
                if (localizedCaption == null) {
                    localizedCaption = caption;
                } else {
                    return localizedCaption;
                }
            }
            return localizedCaption;
        }

        protected virtual string
            FindLocalizedCaption(
                string caption,
                XDocument localizationResource
            ) {
            var resourceRoot = localizationResource.Root;
            Debug.Assert((resourceRoot != null), "(localizationResource.Root != null)");
            var localizedCaption = caption;
            var defaultCultureName = DefaultCulture.Name;
            var defaultCultureResourceData = resourceRoot
                .Elements("ResourceGroup")
                .SelectMany(rg => rg.Elements("ResourceSite"))
                .SelectMany(rs => rs.Elements("Resource"))
                .Where(r => (r.GetAttributeValue("culture") == defaultCultureName))
                .SelectMany(r => r.Elements("data"))
                .FirstOrDefault(r => (r.Elements("value").Single().Value == caption))
                ;
            if (defaultCultureResourceData != default(XElement)) {
                var cultureName = env.Culture.Name;
                var defaultCultureResourceDataName = defaultCultureResourceData.GetAttributeValue("name");
                var defaultCultureResource = defaultCultureResourceData.Parent;
                Debug.Assert((defaultCultureResource != null), "(defaultCultureResourceData.Parent != null)");
                var defaultCultureResourceSite = defaultCultureResource.Parent;
                Debug.Assert((defaultCultureResourceSite != null), "(defaultCultureResource.Parent != null)");
                var localizedResourceData = defaultCultureResourceSite
                    .Elements("Resource")
                    .Where(r => (r.GetAttributeValue("culture") == cultureName))
                    .SelectMany(r => r.Elements("data"))
                    .SingleOrDefault(d => (d.GetAttributeValue("name") == defaultCultureResourceDataName))
                    ;
                if (localizedResourceData != default(XElement)) {
                    localizedCaption = localizedResourceData.Elements("value").Single().Value;
                }
            }
            return localizedCaption;
        }

        #endregion Caption

        #region Forms

        protected override bool
            WaitWebFormLoaded(
                WebForm webForm,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            return
                webForm.WaitDisplayed(
                    mt.LoadingMask,
                    displayed: false,
                    timeout: timeout,
                    throwTimedOut: throwTimedOut
                    );
        }

        #endregion Forms
    }
}
