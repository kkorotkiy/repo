﻿
namespace MetraTech.WebComponents.WebControls
{
    public static class MetraTech
    {
        #region Dialogs

        public const string Dialog = ("mt.Dialog");
        public const string ToolButton_Close_Dialog = ("mt.ToolButton_Close_Dialog");
        public const string ToolButton_Maximize_Dialog = ("mt.ToolButton_Maximize_Dialog");
        public const string ToolButton_Restore_Dialog = ("mt.ToolButton_Restore_Dialog");
        public const string ToolButton_Expand_Dialog = ("mt.ToolButton_Expand_Dialog");
        public const string ToolButton_Collapse_Dialog = ("mt.ToolButton_Collapse_Dialog");
        public const string DialogBody = ("mt.DialogBody");

        #endregion Dialogs

        #region Panels

        #region DataPane

        public const string DataPane = ("mt.DataPane");
        public const string ToolButton_Expand_DataPane = ("mt.ToolButton_Expand_DataPane");
        public const string ToolButton_Collapse_DataPane = ("mt.ToolButton_Collapse_DataPane");
        public const string DataPaneBody = ("mt.DataPaneBody");

        #endregion DataPane

        #region Menu

        public const string Menu = ("mt.Menu");
        public const string ToolButton_Expand_Menu = ("mt.ToolButton_Expand_Menu");
        public const string ToolButton_Collapse_Menu = ("mt.ToolButton_Collapse_Menu");
        public const string MenuBody = ("mt.MenuBody");
        public const string MenuItem = ("mt.MenuItem");

        #endregion Menu

        #endregion Panels

        #region Grids

        #region Grid

        public const string Grid = ("mt.Grid");
        public const string CheckBox_SelectAll_GridRow = ("mt.CheckBox_SelectAll_GridRow");

        #endregion Grid

        #region Grid_1

        public const string Grid_1 = ("mt.Grid_1");

        #endregion Grid_1

        #region GridPage

        public const string Label_GridPageCount = ("mt.Label_GridPageCount");

        #endregion GridPage

        #region GridPage_1

        public const string DropBox_GridPageIndex_1 = ("mt.DropBox_GridPageIndex_1");
        public const string TextBox_GridPageFilter_1 = ("mt.TextBox_GridPageFilter_1");

        #endregion GridPage_1

        #region GridColumn

        public const string GridColumn_ByName = ("mt.GridColumn_ByName");
        public const string GridColumn_ByIndex = ("mt.GridColumn_ByIndex");

        #endregion GridColumn

        #region GridColumn_1

        public const string GridColumn_ByName_1 = ("mt.GridColumn_ByName_1");
        public const string GridColumn_ByIndex_1 = ("mt.GridColumn_ByIndex_1");

        #endregion GridColumn_1

        #region GridRow

        public const string GridRow_ByColumnIndex_And_CellValue = ("mt.GridRow_ByColumnIndex_And_CellValue");
        public const string GridRow_ByIndex = ("mt.GridRow_ByIndex");
        public const string ToolButton_Expand_GridRow = ("mt.ToolButton_Expand_GridRow");
        public const string ToolButton_Collapse_GridRow = ("mt.ToolButton_Collapse_GridRow");
        public const string GridRowBody = ("mt.GridRowBody");
        public const string CheckBox_Select_GridRow = ("mt.CheckBox_Select_GridRow");
        public const string RadioButton_Select_GridRow = ("mt.RadioButton_Select_GridRow");

        #endregion GridRow

        #region GridRow_1

        public const string GridRow_ByColumnIndex_And_CellValue_1 = ("mt.GridRow_ByColumnIndex_And_CellValue_1");
        public const string GridRow_ByIndex_1 = ("mt.GridRow_ByIndex_1");
        public const string ToolButton_Expand_GridRow_1 = ("mt.ToolButton_Expand_GridRow_1");
        public const string ToolButton_Collapse_GridRow_1 = ("mt.ToolButton_Collapse_GridRow_1");
        public const string GridRowBody_1 = ("mt.GridRowBody_1");
        public const string CheckBox_Select_GridRow_1 = ("mt.CheckBox_Select_GridRow_1");
        public const string RadioButton_Select_GridRow_1 = ("mt.RadioButton_Select_GridRow_1");
        
        #endregion GridRow_1

        #region GridCell

        public const string GridRowCell_ByColumnIndex = ("mt.GridRowCell_ByColumnIndex");
        public const string GridRowCell_ByColumnIndex_1 = ("mt.GridRowCell_ByColumnIndex_1");

        #endregion GridCell_1

        #endregion Grids

        #region Trees

        #region Tree

        public const string TreeNode = ("mt.TreeNode");
        public const string ToolButton_Expand_TreeNode = ("mt.ToolButton_Expand_TreeNode");
        public const string ToolButton_Collapse_TreeNode = ("mt.ToolButton_Collapse_TreeNode");
        public const string TreeNodeBody = ("mt.TreeNodeBody");
        public const string TreeLeaf = ("mt.TreeLeaf");

        #endregion Tree

        #region Tree_1
        
        public const string TreeNode_1 = ("mt.TreeNode_1");
        public const string ToolButton_Expand_TreeNode_1 = ("mt.ToolButton_Expand_TreeNode_1");
        public const string ToolButton_Collapse_TreeNode_1 = ("mt.ToolButton_Collapse_TreeNode_1");
        public const string TreeNodeBody_1 = ("mt.TreeNodeBody_1");
        public const string TreeLeaf_1 = ("mt.TreeLeaf_1");

        #endregion Tree_1

        #endregion Trees

        #region Fields

        public const string TextField = ("mt.TextField");

        #endregion Fields

        #region TextBoxes

        public const string TextBox = ("mt.TextBox");
        public const string TextBox_1 = ("mt.TextBox_1");

        #region TextBoxBetween

        public const string TextBox_Between_From = ("mt.TextBox_Between_From");
        public const string TextBox_Between_To = ("mt.TextBox_Between_To");

        #endregion TextBoxBetween

        #endregion TextBoxes

        #region CheckBoxes

        public const string CheckBox = ("mt.CheckBox");
        public const string CheckBox_1 = ("mt.CheckBox_1");

        #endregion CheckBoxes

        #region DropBoxes

        public const string DropBox_1 = ("mt.DropBox_1");

        #endregion DropBoxes

        #region ComboBoxes

        #region ConditionComboBox

        public const string ComboBox_Condition = ("mt.ComboBox_Condition");
        public const string ComboBox_ByCondition = ("mt.ComboBox_ByCondition");

        #endregion ConditionComboBox

        public const string ComboBox = ("mt.ComboBox");
        public const string ToolButton_Open_ComboBoxDropdown = ("mt.ToolButton_Open_ComboBoxDropdown");
        public const string ComboBoxDropdown = ("mt.ComboBoxDropdown");
        public const string ComboBoxDropdownElement = ("mt.ComboBoxDropdownElement");
        public const string ComboBoxDropdownElementSingle = ("mt.ComboBoxDropdownElementSingle");

        #endregion ComboBoxes

        #region FindBoxes

        public const string FindBox = ("mt.FindBox");
        public const string FindBoxDropdown = ("mt.FindBoxDropdown");
        public const string FindBoxDropdownElement = ("mt.FindBoxDropdownElement");
        public const string FindBoxDropdownElementSingle = ("mt.FindBoxDropdownElementSingle");

        #endregion FindBoxes

        #region Misc.

        public const string LoadingMask = ("mt.LoadingMask");

        #endregion Misc.
    }

    public static class MetraNet
    {
        #region Pages

        public const string LoginPage = ("mn.LoginPage");
        public const string MainPage = ("mn.MainPage");

        #endregion Pages        

        #region Panels

        #region Login pane

        public const string LoginPane = ("mn.LoginPane");
        public const string LoginChangePasswordPane = ("mn.LoginChangePasswordPane");

        #endregion Login pane

        #region Sidebar

        public const string Sidebar = ("mn.Sidebar");
        public const string ToolButton_Expand_Sidebar = ("mn.ToolButton_Expand_Sidebar");
        public const string ToolButton_Collapse_Sidebar = ("mn.ToolButton_Collapse_Sidebar");
        public const string SidebarBody = ("mn.SidebarBody");

        #endregion Sidebar

        #region Toolbar

        public const string ToolbarMenu = ("mn.ToolbarMenu");
        public const string ToolButton_Expand_ToolbarMenu = ("mn.ToolButton_Expand_ToolbarMenu");
        public const string ToolButton_Collapse_ToolbarMenu = ("mn.ToolButton_Collapse_ToolbarMenu");
        public const string ToolbarMenuBody = ("mn.ToolbarMenuBody");
        public const string ToolbarMenuItem = ("mn.ToolbarMenuItem");

        #endregion Toolbar

        #endregion Panels

        #region TabControls

        public const string Tab = ("mn.Tab");
        public const string Tab_1 = ("mn.Tab_1");

        #endregion TabControls

        #region TextBoxes

        public const string PlaceholderTextBox = ("mn.PlaceholderTextBox");

        #endregion TextBoxes

        #region FindBoxes

        public const string QuickSearch_FindBox = ("mn.QuickSearch_FindBox");

        #endregion FindBoxes

        #region Buttons

        public const string ToolButton_HierarchyFind = ("mn.ToolButton_HierarchyFind");
        public const string ToolButton_HierarchyRefresh = ("mn.ToolButton_HierarchyRefresh");

        #endregion Buttons
    }

    public static class MetraView
    {
        #region Pages

        public const string LoginPage = ("mv.LoginPage");
        public const string HomePage = ("mv.HomePage");
        public const string BillPaymentsPage = ("mv.BillPaymentsPage");
        public const string BillingHistoryPage = ("mv.BillingHistoryPage");
        public const string GoPaperlessPage = ("mv.GoPaperlessPage");
        public const string ReviewPaymentPage = ("mv.ReviewPaymentPage");
        public const string PayFinalPage = ("mv.PayFinalPage");
        public const string PaymentMethodsPage = ("mv.PaymentMethodsPage");
        public const string AddCreditCardPage = ("mv.AddCreditCardPage");
        public const string UpdateCreditCardPage = ("mv.UpdateCreditCardPage");
        public const string RemoveCreditCardPage = ("mv.RemoveCreditCardPage");
        public const string AddAchPage = ("mv.AddAchPage");
        public const string UpdateAchPage = ("mv.UpdateAchPage");
        public const string RemoveAchPage = ("mv.RemoveAchPage");
        public const string PaymentHistoryPage = ("mv.PaymentHistoryPage");
        public const string MakePaymentPage = ("mv.MakePaymentPage");
        public const string ReportsPage = ("mv.ReportsPage");
        public const string DownloadInvoicePage = ("mv.DownloadInvoicePage");
        public const string AccountInfoPage = ("mv.AccountInfoPage");
        public const string AccountInfoSuccessPage = ("mv.AccountInfoSuccessPage");
        public const string ChangePasswordPage = ("mv.ChangePasswordPage");
        public const string ChangePasswordSuccessPage = ("mv.ChangePasswordSuccessPage");
        public const string RegionalSettingsPage = ("mv.RegionalSettingsPage");
        public const string InvoiceMethodPage = ("mv.InvoiceMethodPage");
        public const string AccountSecurityPage = ("mv.AccountSecurityPage");
        public const string SubscriptionsPage = ("mv.SubscriptionsPage");
        public const string AdminPage = ("mv.AdminPage");
        public const string ConfigureSitePage = ("mv.ConfigureSitePage");
        public const string ActivityPage = ("mv.ActivityPage");

        #endregion Pages

        #region Panels

        public const string DataPane = ("mv.DataPane");
        public const string NestedDataPane = ("mv.NestedDataPane");
        public const string DataPaneInfo = ("mv.DataPaneInfo");

        #endregion Panels

        #region TabControls

        public const string Tab = ("mv.Tab");

        #endregion TabControls

        #region Trees

        public const string TreeNode = ("mv.TreeNode");
        public const string ToolButton_Expand_TreeNode = ("mv.ToolButton_Expand_TreeNode");
        public const string ToolButton_Collapse_TreeNode = ("mv.ToolButton_Collapse_TreeNode");
        public const string TreeNodeBody = ("mv.TreeNodeBody");
        public const string TreeNodeValue = ("mv.TreeNodeValue");
        public const string TreeLeaf = ("mv.TreeLeaf");
        public const string TreeLeafValue = ("mv.TreeLeafValue");

        #endregion Trees

        #region Fields

        public const string TextFieldValue = ("mv.TextFieldValue");

        #endregion Fields

        #region TextBoxes

        public const string TextBoxForCheckBox = ("mv.TextBoxForCheckBox");

        #endregion TextBoxes

        #region Buttons

        public const string Button = ("mv.Button");

        #endregion Buttons
    }
}
