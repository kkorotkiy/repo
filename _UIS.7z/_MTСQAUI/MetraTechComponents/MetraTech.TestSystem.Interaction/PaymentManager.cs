﻿using System;
using System.ServiceModel;
using MetraTech.ActivityServices.Common;
using MetraTech.Core.Services.ClientProxies;
using MetraTech.DomainModel.BaseTypes;
using MetraTech.DomainModel.MetraPay;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraTech.TestSystem.Interaction
{
    public static class PaymentManager
    {
        #region Properties and Fields

        private static RecurringPaymentsServiceClient
            PaymentServiceClient {
            get {
                if ((_serviceClient == null) || (_serviceClient.State != CommunicationState.Opened)) {
                    _serviceClient = CreateServiceClient();
                }
                return _serviceClient;
            }
        }
        private static RecurringPaymentsServiceClient _serviceClient;


        private static RecurringPaymentsServiceClient CreateServiceClient()
        {
            var client = new RecurringPaymentsServiceClient("NetTcpBinding_IRecurringPaymentsService");
            client.ClientCredentials.UserName.UserName = env.SuperUser.UserName;
            client.ClientCredentials.UserName.Password = env.SuperUser.Password;
            return client;
        }

        #endregion Properties and Fields

        public static void
            AddPaymentMethod(
                Account account,
                params MetraPaymentMethod[] paymentMethods
            ) { foreach (var method in paymentMethods) { AddPaymentMethod(account, method); } }

        public static Guid
            AddPaymentMethod(
                Account account,
                MetraPaymentMethod paymentMethod
            ) {
            Guid token;
            var accIdentifier = new AccountIdentifier(account._AccountID.Value);
            PaymentServiceClient.AddPaymentMethod(accIdentifier, paymentMethod, out token);
            return token;
        }


        public static void
            AssignPaymentMethodToAccount(
                Account account,
                params MetraPaymentMethod[] paymentMethods
            ) { foreach (var method in paymentMethods) { AssignPaymentMethodToAccount(account, method); } }

        public static Guid
            AssignPaymentMethodToAccount(
                Account account,
                MetraPaymentMethod paymentMethod
            ) {
            Guid token;
            var accIdentifier = new AccountIdentifier(account._AccountID.Value);
            PaymentServiceClient.AddPaymentMethod(accIdentifier, paymentMethod, out token);
            PaymentServiceClient.AssignPaymentMethodToAccount(token, accIdentifier);
            return token;
        }

        #region FormatSecureNumber

        public static string
            FormatSecureNumber(
                int number,
                string prefix = "******",
                int suffixLength = 4
            ) { return FormatSecureNumber(Convert.ToString(number), prefix, suffixLength); }

        public static string
            FormatSecureNumber(
                string number,
                string prefix = "******",
                int suffixLength = 4
            ) {
            var numberSuffixStartIndex = (number.Length - suffixLength);
            var numberSuffix = number.Substring(numberSuffixStartIndex);
            var secureNumber = (prefix + numberSuffix);
            return secureNumber;
        }

        #endregion FormatSecureNumber

        #region ParseExpirationDate

        public static void
            ParseExpirationDate(
                string date,
                out string month,
                out string year,
                char separator = '/'
            ) {
            var expirationDate = date.Split(separator);
            month = expirationDate[0];
            year = expirationDate[1];
        }

        public static string
            ParseExpirationMonth(
                string expirationDate,
                char separator = '/'
            ) {
            string expirationMonth, expirationYear;
            ParseExpirationDate(
                expirationDate,
                out expirationMonth,
                out expirationYear,
                separator
                );
            return expirationMonth;
        }

        public static string
            ParseExpirationYear(
                string expirationDate,
                char separator = '/'
            ) {
            string expirationMonth, expirationYear;
            ParseExpirationDate(
                expirationDate,
                out expirationMonth,
                out expirationYear,
                separator
                );
            return expirationYear;
        }

        #endregion ParseExpirationDate 
    }
}
