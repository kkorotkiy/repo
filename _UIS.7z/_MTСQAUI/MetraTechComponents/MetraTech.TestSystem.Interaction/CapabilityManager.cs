﻿using System;
using MetraTech.Interop.MTAuth;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraTech.TestSystem.Interaction
{
    public static class CapabilityManager
    {
        #region Properties and Fields

        private static readonly MTSecurity _mtSecurity = (new MTSecurityClass());

        #endregion Properties and Fields

        #region Grant Capability

        public static void
            GrantCapability(
                IMTCompositeCapability capability,
                int accountId,
                DateTime? dateTime = null
            ) {
            if (!dateTime.HasValue) {
                dateTime = DateTime.UtcNow;
            }
            var accObj = _mtSecurity.GetAccountByID(env.SessionContext, accountId, dateTime);
            accObj.GetActivePolicy(env.SessionContext).AddCapability(capability);
            accObj.GetActivePolicy(env.SessionContext).Save();
        }

        public static void
            GrantCapability(
                string capabilityName,
                int accountId,
                DateTime? dateTime = null
            ) {
            var capability = GetCapability(capabilityName);
            GrantCapability(capability, accountId, dateTime);
        }

        public static IMTCompositeCapability
            GetCapability(
                string capabilityName
            ) { return _mtSecurity.GetCapabilityTypeByName(capabilityName).CreateInstance(); }

        #endregion Grant Capability

        /// <summary>
        /// Grants the Application Logon capability to provided account
        /// </summary>
        /// <param name="accountId">Account the capability is granted to</param>
        /// <param name="applicationCodes">MetraNet application codes. 
        /// Valid codes: MAM, MCM, MOM, MPS. 
        /// MAM means MetraCare. MCM means MetraOffer. MOM means MetraControl. MPS means MetraView.</param>
        public static void
            GrantApplicationLogonCapability(
                int accountId,
                params string[] applicationCodes
            ) {
            foreach (var app in applicationCodes) {
                var capability = GetCapability("Application Logon");
                capability.GetAtomicEnumCapability().SetParameter(app);
                GrantCapability(capability, accountId);
            }
        }

        /// <summary>
        /// Grants the Apply Adjustments capability to provided account
        /// </summary>
        /// <param name="accountId">Account the capability is granted to</param>
        /// <param name="operatorType">Operator to be used to compute the limit</param>
        /// <param name="limit">Amount limitation that account is able to adjust</param>
        /// <param name="isoCurrencyCode">ISO 4217 currency code: GBP, EUR, USD, etc.</param>
        public static void
            GrantApplyAdjustmentsCapability(
                int accountId,
                MTOperatorType operatorType,
                decimal limit,
                string isoCurrencyCode
            ) {
            var capability = GetCapability("Apply Adjustments");
            capability.GetAtomicEnumCapability().SetParameter(isoCurrencyCode);
            capability.GetAtomicDecimalCapability().SetParameter(limit, operatorType);
            GrantCapability(capability, accountId);
        }

        /// <summary>
        /// Grants the Manage Account Hierarchies capability to provided account
        /// </summary>
        /// <param name="accountId">Account the capability is granted to</param>
        /// <param name="hierarchyPath">Defines a scope of accounts to be managed</param>
        /// <param name="managedAccountId">Account Id that is considered to be the root account in hierarchy</param>
        /// <param name="accessType">The type of access to hierarchy. Valid values: READ, WRITE</param>
        public static void
            GrantManageAccountHierarchiesCapability(
                int accountId,
                MTHierarchyPathWildCard hierarchyPath,
                int managedAccountId,
                string accessType
            ) {
            var capability = GetCapability("Manage Account Hierarchies");
            SetHierarchyPathParameter(capability, managedAccountId, hierarchyPath, accessType);
            GrantCapability(capability, accountId);
        }

        /// <summary>
        /// Grants the Manage Sales Force Hierarchies capability to provided account
        /// </summary>
        /// <param name="accountId">Account the capability is granted to</param>
        /// <param name="hierarchyPath">Defines the scope of accounts to be managed</param>
        /// <param name="managedAccountId">Account Id that is considered to be the root account in hierarchy</param>
        /// <param name="accessType">The type of access to hierarchy. Valid values are READ, WRITE</param>
        public static void
            GrantManageSalesForceHierarchiesCapability(
                int accountId,
                MTHierarchyPathWildCard hierarchyPath,
                int managedAccountId,
                string accessType
            ) {
            var capability = GetCapability("Manage Sales Force Hierarchies");
            SetHierarchyPathParameter(capability, managedAccountId, hierarchyPath, accessType);
            GrantCapability(capability, accountId);
        }

        #region Private Methods
       
        private static void
            SetHierarchyPathParameter(
                IMTCompositeCapability capability,
                int managedAccountId,
                MTHierarchyPathWildCard hierarchyPath,
                string accessType
            ) {
            if (managedAccountId == 1) {
                // account "root (1)"
                capability.GetAtomicPathCapability().SetParameter("/", hierarchyPath);
            } else {
                var managedAccount = _mtSecurity.GetAccountByID(env.SessionContext, managedAccountId, DateTime.Now);
                capability.GetAtomicPathCapability().SetParameter(managedAccount.HierarchyPath, hierarchyPath);
            }
            capability.GetAtomicEnumCapability().SetParameter(accessType.ToUpper());
        }

        #endregion Private Methods
    }
}
