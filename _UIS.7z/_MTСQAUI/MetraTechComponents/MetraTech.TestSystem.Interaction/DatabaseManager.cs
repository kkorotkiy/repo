﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.OracleClient;
using System.Data.SqlClient;
using System.Reflection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UtilityComponents;
using DbSource = MetraTech.DataAccess.DBType;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraTech.TestSystem.Interaction
{
    internal static class Database
    {
        private class ConnectionInfo
        {
            public readonly DbSource DbSource;
            public readonly DbConnection DbConnection;

            public ConnectionInfo(
                DbSource dbSource,
                DbConnection dbConnection
                ) {
                DbSource = dbSource;
                DbConnection = dbConnection;
            }
        }
#pragma warning disable 612,618

        #region Executed Command

        private const string ExecutedCommandTextFormat=("[{0}][{1}]");
        private const string CommandParameterFormat=("parameter[name:'{0}', value:'{1}']");

        public static string
            ExecutedCommandText { get; private set; }

        internal static DbCommand
            ExecutedCommand {
            get { return _executedCommand; }
            private set {
                _executedCommand = value;
                var parameterFormats =
                    _executedCommand.
                        Parameters.
                        Cast<DbParameter>().
                        Select(p => string.Format(Environment.NewLine+CommandParameterFormat, p.ParameterName, p.Value));
                var parameters = (string.Join(",", parameterFormats)+Environment.NewLine);
                ExecutedCommandText =
                    string.Format(
                        ExecutedCommandTextFormat,
                        _executedCommand.CommandText,
                        parameters
                        );
            }
        }
        private static DbCommand _executedCommand;

        #endregion Executed Command

        #region Connect

        private const string ConnectionForAliasAlreadyOpenedException = ("Cannot create connection to '{0}'. Alias '{1}' is already associated with opened connection to '{2}'.");
        public const string DefaultConnectionAlias = ("DEFAULT");

        private static readonly Dictionary<string, ConnectionInfo>
            _dbConnections = (new Dictionary<string, ConnectionInfo>(capacity: 1));

        public static void
            Connect(
                DbSource dbSource,
                string connectionString,
                string connectionAlias = DefaultConnectionAlias
            ) {
            var connectionExists = _dbConnections.ContainsKey(connectionAlias);
            if (connectionExists) {
                var connectionSource = _dbConnections[connectionAlias].DbSource;
                if (connectionSource == dbSource) {
                    return;
                }
                throw (new Exception(string.Format(
                    ConnectionForAliasAlreadyOpenedException,
                        dbSource,
                        connectionAlias,
                        connectionSource))
                      );
            }
            var dbConnection = GetDbConnection(dbSource, connectionString);
            dbConnection.Open();
            var connectionInfo = (new ConnectionInfo(dbSource, dbConnection));
            _dbConnections.Add(connectionAlias, connectionInfo);
        }

        private static DbConnection
            GetDbConnection(
                DbSource dbSource,
                string connectionString
            ) {
            DbConnection dbConnection;
            switch (dbSource) {
                case DbSource.SQLServer: {
                    dbConnection = (new SqlConnection(connectionString));
                    break;
                }
                case DbSource.Oracle: {
                    dbConnection = (new OracleConnection(connectionString));
                    break;
                }
                default: {
                    throw (new InvalidEnumArgumentException("dbSource",((int)dbSource),typeof(DbSource)));
                }
            }
            return dbConnection;
        }

        #region ConnectToSqlServer

        public static void
            ConnectToSqlServer(
                string instanceName,
                string databaseName,
                string userName,
                string password
            ) { ConnectToSqlServer(DefaultConnectionAlias, instanceName, databaseName, userName, password); }
        
        public static void
            ConnectToSqlServer(
                string connectionAlias,
                string instanceName,
                string databaseName,
                string userName,
                string password
            ) {
            var connectionStringBuilder =
                (new SqlConnectionStringBuilder {
                        DataSource = instanceName,
                        InitialCatalog = databaseName,
                        UserID = userName,
                        Password = password,
                        TrustServerCertificate = true,
                        Pooling = true,
                     });
            var connectionString = connectionStringBuilder.ConnectionString;
            Connect(DbSource.SQLServer, connectionString, connectionAlias);
        }

        #endregion ConnectToSqlServer

        #region ConnectToOracle

        public static void
            ConnectToOracle(
                string hostName,
                string userName,
                string password
            ) { ConnectToOracle(DefaultConnectionAlias, hostName, userName, password); }
        
        public static void
            ConnectToOracle(
                string connectionAlias,
                string hostName,
                string userName,
                string password
            ) {
            var connectionStringBuilder =
                (new OracleConnectionStringBuilder {
                        DataSource = hostName,
                        UserID = userName,
                        Password = password,
                        Pooling = true,
                    });
            var connectionString = connectionStringBuilder.ConnectionString;
            Connect(DbSource.Oracle, connectionString, connectionAlias);
        }

        #endregion ConnectToOracle

        #endregion Connect

        #region GetDbParameter

        public static DbParameter
            GetDbParameter(
                string name,
                object value,
                DbType type,
                int size = 0,
                string connectionAlias = DefaultConnectionAlias
            ) { return GetDbParameter(_dbConnections[connectionAlias].DbSource, name, value, type, size); }

        public static DbParameter
            GetDbParameter(
                string name,
                object value,
                string connectionAlias = DefaultConnectionAlias
            ) { return GetDbParameter(_dbConnections[connectionAlias].DbSource, name, value); }


        public static DbParameter
            GetDbParameter(
                DbSource dbSource,
                string name,
                object value,
                DbType type,
                int size = 0
            ) {
            var dbParameter = GetDbParameter(dbSource, name, value);
            dbParameter.Size = size;
            dbParameter.DbType = type;
            return dbParameter;
        }

        public static DbParameter
            GetDbParameter(
                DbSource dbSource,
                string name,
                object value
            ) {
            DbParameter dbParameter;
            switch (dbSource) {
                case DbSource.SQLServer: {
                    dbParameter = (new SqlParameter(name, value));
                    break;
                }
                case DbSource.Oracle: {
                    dbParameter = (new OracleParameter(name, value));
                    break;
                }
                default: {
                    throw (new
                        InvalidEnumArgumentException(
                            "dbSource",
                            ((int) dbSource),
                            typeof(DbSource)
                        ));
                }
            }
            return dbParameter;
        }

        public static DbParameter[]
            CloneDbParameter(
                DbSource dbSource,
                params DbParameter[] dbParameters
            ) {
            int dbParametersLength = dbParameters.Length;
            var clonedDbParameters = (new DbParameter[dbParametersLength]);
            for (int i = 0; i < dbParametersLength; i++) {
                var dbParameter = dbParameters[i];
                clonedDbParameters[i] =
                    GetDbParameter(
                        dbSource,
                        dbParameter.ParameterName,
                        dbParameter.Value,
                        dbParameter.DbType,
                        dbParameter.Size
                        );
            }
            return clonedDbParameters;
        }

        #endregion GetDbParameter
        
        #region Execute Command

        #region ExecuteNonQuery

        public static int
            ExecuteNonQuery(
                string dbCommandText,
                params DbParameter[] dbParameters
            ) { return ExecuteNonQuery(DefaultConnectionAlias, dbCommandText, dbParameters); }

        public static int
            ExecuteNonQuery(
                string connectionAlias,
                string dbCommandText,
                params DbParameter[] dbParameters
            ) {
            var connectionInfo = _dbConnections[connectionAlias];
            var dbCommand =
                GetDbCommand(
                    connectionInfo.DbSource,
                    connectionInfo.DbConnection,
                    dbCommandText,
                    CommandType.Text,
                    dbParameters
                    );
            int affectedRowCount;
            using (dbCommand) {
                ExecutedCommand = dbCommand;
                affectedRowCount = dbCommand.ExecuteNonQuery();
            }
            return affectedRowCount;
        }

        #endregion ExecuteNonQuery

        #region ExecuteScalar

        public static TOut
            ExecuteScalar<
                TOut>(
                string dbCommandText,
                params DbParameter[] dbParameters
            ) { return ExecuteScalar<TOut>(DefaultConnectionAlias, dbCommandText, dbParameters); }

        public static TOut
            ExecuteScalar<
                TOut>(
                string connectionAlias,
                string dbCommandText,
                params DbParameter[] dbParameters
            ) { return ((TOut) ExecuteScalar(connectionAlias, dbCommandText, dbParameters)); }


        public static object
            ExecuteScalar(
                string dbCommandText,
                params DbParameter[] dbParameters
            ) { return ExecuteScalar(DefaultConnectionAlias, dbCommandText, dbParameters); }

        public static object
            ExecuteScalar(
                string connectionAlias,
                string dbCommandText,
                params DbParameter[] dbParameters
            ) {
            var connectionInfo = _dbConnections[connectionAlias];
            var dbCommand =
                GetDbCommand(
                    connectionInfo.DbSource,
                    connectionInfo.DbConnection,
                    dbCommandText,
                    CommandType.Text,
                    dbParameters
                    );
            object scalar;
            using (dbCommand) {
                ExecutedCommand = dbCommand;
                scalar = dbCommand.ExecuteScalar();
            }
            return scalar;
        }

        #endregion ExecuteScalar

        #region ExecuteDataTable

        public static DataTable
            ExecuteDataTable(
                string dbCommandText,
                params DbParameter[] dbParameters
            ) { return ExecuteDataTable(DefaultConnectionAlias, dbCommandText, dbParameters); }

        public static DataTable
            ExecuteDataTable(
                string connectionAlias,
                string dbCommandText,
                params DbParameter[] dbParameters
            ) {
            var connectionInfo = _dbConnections[connectionAlias];
            var dbCommand =
                GetDbCommand(
                    connectionInfo.DbSource,
                    connectionInfo.DbConnection,
                    dbCommandText,
                    CommandType.Text,
                    dbParameters
                    );
            var dataTable = (new DataTable());
            using (dbCommand) {
                ExecutedCommand = dbCommand;
                var dbDataReader = dbCommand.ExecuteReader();
                using (dbDataReader) {
                    dataTable.Load(dbDataReader);
                }
            }
            return dataTable;
        }

        #endregion ExecuteDataTable

        #region ExecuteDataSet

        public static DataSet
            ExecuteDataSet(
                string dbCommandText,
                params DbParameter[] dbParameters
            ) { return ExecuteDataSet(DefaultConnectionAlias, dbCommandText, dbParameters); }
        
        public static DataSet
            ExecuteDataSet(
                string connectionAlias,
                string dbCommandText,
                params DbParameter[] dbParameters
            ) {
            var connectionInfo = _dbConnections[connectionAlias];
            var dbCommand =
                GetDbCommand(
                    connectionInfo.DbSource,
                    connectionInfo.DbConnection,
                    dbCommandText,
                    CommandType.Text,
                    dbParameters
                    );
            var dataSet = (new DataSet());
            using (dbCommand) {
                var dbDataAdapter = GetDbDataAdapter(connectionInfo.DbSource, dbCommand);
                using (dbDataAdapter) {
                    ExecutedCommand = dbCommand;
                    dbDataAdapter.Fill(dataSet);
                }
            }
            return dataSet;
        }

        #endregion ExecuteDataSet

        #region ExecuteStoredProcedure

        public static DataSet
            ExecuteStoredProcedure(
                string procedureName,
                params DbParameter[] dbParameters
            ) { return ExecuteStoredProcedure(DefaultConnectionAlias, procedureName, dbParameters); }

        public static DataSet
            ExecuteStoredProcedure(
                string connectionAlias,
                string procedureName,
                params DbParameter[] dbParameters
            ) {
            var connectionInfo = _dbConnections[connectionAlias];
            var dbCommand =
                GetDbCommand(
                    connectionInfo.DbSource,
                    connectionInfo.DbConnection,
                    procedureName,
                    CommandType.StoredProcedure,
                    dbParameters
                    );
            var dataSet = (new DataSet());
            using (dbCommand) {
                var dbDataAdapter = GetDbDataAdapter(connectionInfo.DbSource, dbCommand);
                using (dbDataAdapter) {
                    ExecutedCommand = dbCommand;
                    dbDataAdapter.Fill(dataSet);
                }
            }
            return dataSet;
        }

        #endregion ExecuteStoredProcedure

        #region GetDbDataAdapter

        private static DbDataAdapter
            GetDbDataAdapter(
                DbSource dbSource,
                DbCommand dbCommand
            ) {
            DbDataAdapter dbDataAdapter;
            switch (dbSource) {
                case DbSource.SQLServer: {
                    var sqlCommand = ((SqlCommand) dbCommand);
                    dbDataAdapter = (new SqlDataAdapter(sqlCommand));
                    break;
                }
                case DbSource.Oracle: {
                    var oracleCommand = ((OracleCommand) dbCommand);
                    dbDataAdapter = (new OracleDataAdapter(oracleCommand));
                    break;
                }
                default: {
                    throw (new InvalidEnumArgumentException("dbSource",((int)dbSource),typeof(DbSource)));
                }
            }
            return dbDataAdapter;
        }

        private static DbCommand
            GetDbCommand(
                DbSource dbSource,
                DbConnection dbConnection,
                string dbCommandText,
                CommandType dbCommandType,
                params DbParameter[] dbParameters
            ) {
            DbCommand dbCommand;
            switch (dbSource) {
                case DbSource.SQLServer: {
                    var sqlConnection = ((SqlConnection) dbConnection);
                    dbCommand = (new SqlCommand(dbCommandText, sqlConnection));
                    break;
                }
                case DbSource.Oracle: {
                    var oracleConnection = ((OracleConnection) dbConnection);
                    dbCommand = (new OracleCommand(dbCommandText, oracleConnection));
                    break;
                }
                default: {
                    throw (new InvalidEnumArgumentException("dbSource",((int)dbSource),typeof(DbSource)));
                }
            }
            dbCommand.CommandType = dbCommandType;
            dbCommand.Parameters.AddRange(dbParameters);
            return dbCommand;
        }

        #endregion GetDbDataAdapter

        #endregion Execute Command

        #region Disconnect

        public static void
            DisconnectAll(
            ) {
            foreach (var connectionAlias in _dbConnections.Keys) {
                CloseConnection(connectionAlias);
            }
            _dbConnections.Clear();
        }
        
        public static void
            Disconnect(
                string connectionAlias = DefaultConnectionAlias
            ) {
            var connectionExists = CloseConnection(connectionAlias);
            if (connectionExists) {
                _dbConnections.Remove(connectionAlias);
            }
        }


        private static bool
            CloseConnection(
                string connectionAlias
            ) {
            var connectionExists = _dbConnections.ContainsKey(connectionAlias);
            if (!connectionExists) {
                return false;
            }
            _dbConnections[connectionAlias].DbConnection.Close();
            return true;
        }

        #endregion Disconnect

#pragma warning restore 612,618
    }


    public static class DatabaseManager
    {
        #region DbQueries

        public static readonly
            Dictionary<DbSource, Dictionary<string, string>>
            DbQueries = (new Dictionary<DbSource, Dictionary<string, string>> {
                {DbSource.SQLServer, (new Dictionary<string, string>())},
                {DbSource.Oracle,    (new Dictionary<string, string>())},
            });

        private static void PopulateDbQueries()
        {
            var dbQueryNames = typeof(DbQueries).GetFields(BindingFlags.Public|BindingFlags.Static).Select(q => q.Name).ToArray();
            var sqlServerQueries = typeof(SqlServerQueries).GetFields(BindingFlags.Public|BindingFlags.Static);
            var oracleQueries = typeof(OracleQueries).GetFields(BindingFlags.Public|BindingFlags.Static);
            foreach (var dbQueryName in dbQueryNames) {
                var dbQuery = sqlServerQueries.Single(q => (q.Name == dbQueryName));
                var dbQueryText = ((string)dbQuery.GetValue(null));
                DbQueries[DbSource.SQLServer].Add(dbQueryName, dbQueryText);
                dbQuery = oracleQueries.Single(q => (q.Name == dbQueryName));
                dbQueryText = ((string)dbQuery.GetValue(null));
                DbQueries[DbSource.Oracle].Add(dbQueryName, dbQueryText);
            }
        }

        private static string GetDbQuery(string dbQuery)
        {
            var dbQueries = DbQueries[env.NetMeter.DatabaseType];
            if (dbQueries.ContainsKey(dbQuery)) {
                dbQuery = dbQueries[dbQuery];
            }
            return dbQuery;
        }

        static DatabaseManager() { PopulateDbQueries(); }

        #endregion DbQueries

        #region Connect to Database

        private static bool _isConnected;

        private static void ConnectToDatabase()
        {
            if (_isConnected) {
                return;
            }
            switch (env.NetMeter.DatabaseType) {
                case DbSource.SQLServer: {
                    Database.ConnectToSqlServer(
                        instanceName: env.NetMeter.Server,
                        databaseName: env.NetMeter.Catalog,
                        userName: env.NetMeter.UserName,
                        password: env.NetMeter.Password
                        );
                    break;
                }
                case DbSource.Oracle: {
                    Database.ConnectToOracle(
                        hostName: env.NetMeter.Server,
                        userName: env.NetMeter.UserName,
                        password: env.NetMeter.Password
                        );
                    break;
                }
            }
            _isConnected = true;
        }

        public static void DisconnectFromDatabase() { Database.DisconnectAll(); }

        #endregion Connect to Database

        #region Execute Database Query

        private const string NoRowsAffectedByQuery = ("No rows affected by the query.");
        private const string NonSingleRowSelectedByQuery = ("There are more or less than a single row selected by the query.");


        public static DbParameter
            GetDbParameter(
                string name,
                object value
            ) { return Database.GetDbParameter(env.NetMeter.DatabaseType, name, value); }


        public static int
            ExecuteDbNonQuery(
                string dbQuery,
                params DbParameter[] dbParameters
            ) { return ExecuteDbNonQuery(dbQuery, dbParameters, throwNoRowAffected: false); }

        public static int
            ExecuteDbNonQuery(
                string dbQuery,
                DbParameter[] dbParameters,
                bool throwNoRowAffected,
                string message = null,
                params object[] messageParameters
            ) {
            ConnectToDatabase();
            dbQuery = GetDbQuery(dbQuery);
            var affectedRowCount = Database.ExecuteNonQuery(dbQuery, dbParameters);
            if (throwNoRowAffected) {
                if (message == null) {
                    message = NoRowsAffectedByQuery;
                }
                message += (Environment.NewLine+Database.ExecutedCommandText);
                var anyRowAffected = (affectedRowCount > 0);
                Assert.IsTrue(anyRowAffected, message, messageParameters);
            }
            return affectedRowCount;
        }


        public static TValue
            ReadDbValue<
                TValue>(
                string dbQuery,
                params DbParameter[] dbParameters
            ) {
            ConnectToDatabase();
            dbQuery = GetDbQuery(dbQuery);
            var value = Cast.As<TValue>(Database.ExecuteScalar(dbQuery, dbParameters));
            return value;
        }

        public static DataRow
            ReadDbSingleRow(
                string dbQuery,
                params DbParameter[] dbParameters
            ) {
            ConnectToDatabase();
            dbQuery = GetDbQuery(dbQuery);
            var dataTable = Database.ExecuteDataTable(dbQuery, dbParameters);
            var dataTableRows = dataTable.Rows;
            var singleRowSelected = ((dataTableRows != null) && (dataTableRows.Count == 1));
            var assertMessage = (NonSingleRowSelectedByQuery+Environment.NewLine+Database.ExecutedCommandText);
            Assert.IsTrue(singleRowSelected, assertMessage);
            var dataRow = dataTableRows[0];
            return dataRow;
        }

        #endregion Execute Database Query
    }


    public static class DbQueries
    {
        public const string SetupBillingServer = ("SetupBillingServer");
        public const string GetListenerOnlineStatus = ("GetListenerOnlineStatus");
        public const string ProlongateUserPassword = ("ProlongateUserPassword");
        public const string CountUsages_ByAccountId = ("CountUsages_ByAccountId");
        //public const string CountSvcOrderCookies_ByPayerUserName = ("CountSvcOrderCookies_ByPayerUserName");
        //public const string CountPvOrderCookies_ByPayerUserName = ("CountPvOrderCookies_ByPayerUserName");
        //public const string GetFirstInterval_ByUsageCycleAndStatus = ("GetFirstInterval_ByUsageCycleAndStatus");
        //public const string SetUsageIntervalStatus_ById = ("SetUsageIntervalStatus_ById");
        //public const string GetIntervalEopEventList_ByIntervalIdAndBillingGroupName = ("GetIntervalEopEventList_ByIntervalIdAndBillingGroupName");
        //public const string GetEventLastRunStatus_ByInstanceId = ("GetEventLastRunStatus_ByInstanceId");
        public const string GetInvoice_ByIntervalIdAndAccountId = ("GetInvoice_ByIntervalIdAndAccountId");
    }
    public static class SqlServerQueries
    {
        public const string
            SetupBillingServer = (@"
UPDATE [dbo].[t_billing_server_settings]
SET [is_block_new_accounts_enabled] = 0,
    [is_auto_soft_close_bg_enabled] = 0,
    [is_auto_run_eop_enabled] = 0
WHERE (([is_block_new_accounts_enabled] = 1)
    OR ([is_auto_soft_close_bg_enabled] = 1)
    OR ([is_auto_run_eop_enabled] = 1)
)
");
        public const string
            GetListenerOnlineStatus = (@"
SELECT l.[b_online] AS [Status]
FROM [dbo].[t_listener] AS l
WHERE (UPPER(l.[tx_machine]) = UPPER(@machine_name))
");
        public const string
            ProlongateUserPassword = (@"
DECLARE @now AS DATETIME;
SET @now = GETUTCDATE();

UPDATE [dbo].[t_user_credentials]
SET [dt_expire] = DATEADD(MONTH, 4, @now),
    [dt_last_login] = @now,
    [dt_last_logout] = DATEADD(SECOND, 4, @now),
    [num_failures_since_login] = 0
WHERE (([nm_login] = @user_name)
    AND ([nm_space] = @user_nameSpace)
)
INSERT INTO [dbo].[t_user_credentials_history] (
    [nm_login],
    [nm_space],
    [tx_password],
    [tt_end]
) SELECT
    uc.[nm_login],
    uc.[nm_space],
    uc.[tx_password],
    uc.[dt_last_login]
FROM [dbo].[t_user_credentials] AS uc
WHERE ((uc.[nm_login] = @user_name)
    AND ([nm_space] = @user_nameSpace)
)
");
        public const string
            GetInvoice_ByIntervalIdAndAccountId = (@"
SELECT *
FROM [dbo].[t_invoice] AS inv
WHERE ((inv.[id_interval] = @interval_id)
    AND (inv.[id_acc] = @account_id)
)
");
        public const string
            CountUsages_ByAccountId = (@"
SELECT COUNT(*) AS [UsageCount]
FROM [dbo].[t_acc_usage] AS au
WHERE (au.[id_acc] = @account_id)
");
        /*public const string
            CountSvcOrderCookies_ByPayerUserName = (@"
SELECT COUNT(*) AS [UsageCount]
FROM [dbo].[t_svc_OrderCookies] AS svcoc
WHERE (svcoc.[c_Payer] = @payer_userName)
");*/
        /*public const string
            CountPvOrderCookies_ByPayerUserName = (@"
SELECT COUNT(*) AS [UsageCount]
FROM [dbo].[t_pv_OrderCookies] AS pvoc
WHERE (pvoc.[c_Payer] = @payer_userName)
");*/
        /*public const string
            GetFirstInterval_ByUsageCycleAndStatus = (@"
SELECT TOP (1)
    ui.[id_interval] AS [ID],
    ui.[dt_start] AS [StartDate],
    ui.[dt_end] AS [EndDate],
    ui.[tx_interval_status] AS [Status],
    uct.[tx_desc] AS [UsageCycle]
FROM [dbo].[t_usage_interval] AS ui
INNER JOIN [dbo].[t_usage_cycle] AS uc
    ON (ui.[id_usage_cycle] = uc.[id_usage_cycle])
INNER JOIN [dbo].[t_usage_cycle_type] AS uct
    ON (uc.[id_cycle_type] = uct.[id_cycle_type])
WHERE ((CHARINDEX(uct.[tx_desc], @interval_usageCycle) > 0)
    AND (CHARINDEX(ui.[tx_interval_status], @interval_status) > 0))
ORDER BY ui.[dt_start] ASC
");*/
        /*public const string
            SetUsageIntervalStatus_ById = (@"
UPDATE [dbo].[t_usage_interval]
SET [tx_interval_status] = @interval_status
WHERE ([id_interval] = @interval_id)

UPDATE [dbo].[t_acc_usage_interval]
SET [tx_status] = @interval_status
WHERE ([id_usage_interval] = @interval_id)
");*/
        /*public const string
            GetIntervalEopEventList_ByIntervalIdAndBillingGroupName = (@"
SELECT
    COUNT(revdep.[id_event]) AS [Order],
    revinst.[id_instance] AS [InstanceID],
    rev.[id_event] AS [ID],
    rev.[tx_name] AS [Name],
    rev.[tx_display_name] AS [DisplayName],
    rev.[tx_type] AS [Type]
FROM dbo.[t_recevent] AS rev
INNER JOIN dbo.[t_recevent_dep] AS revdep
    ON (rev.[id_event] = revdep.[id_event])
INNER JOIN dbo.[t_recevent_inst] AS revinst
    ON (rev.[id_event] = revinst.[id_event])
LEFT OUTER JOIN dbo.[t_billgroup] AS bg
    ON (bg.[id_billgroup] = revinst.[id_arg_billgroup])
WHERE (rev.[tx_type] in ('EndOfPeriod', 'Checkpoint')
    AND (revinst.[id_arg_interval] = @interval_id)
    AND (bg.[tx_name] = @billingGroup_name))
GROUP BY
    revinst.[id_instance],
    rev.[id_event],
    rev.[tx_name],
    rev.[tx_display_name],
    rev.[tx_type]
ORDER BY
    [Order],
    [DisplayName]
");*/
        /*public const string
            GetEventLastRunStatus_ByInstanceId = (@"
SELECT TOP (1) revrun.[tx_status] AS [Status]
FROM [dbo].[t_recevent_run] AS revrun
WHERE (revrun.[id_instance] = @instance_id)
ORDER BY revrun.[dt_start] DESC
");*/
    }
    public static class OracleQueries
    {
        public const string
            SetupBillingServer = (@"
BEGIN
UPDATE t_billing_server_settings
SET is_block_new_accounts_enabled = 0,
    is_auto_soft_close_bg_enabled = 0,
    is_auto_run_eop_enabled = 0
WHERE ((is_block_new_accounts_enabled = 1)
    OR (is_auto_soft_close_bg_enabled = 1)
    OR (is_auto_run_eop_enabled = 1)
);
END;
");
        public const string
            GetListenerOnlineStatus = (@"
SELECT l.b_online AS Status
FROM t_listener l
WHERE (UPPER(l.tx_machine) = UPPER(:machine_name))
");
        public const string
            ProlongateUserPassword = (@"
DECLARE now DATE;
BEGIN
now := SYS_EXTRACT_UTC(SYSTIMESTAMP);

UPDATE t_user_credentials
SET dt_expire = ADD_MONTHS(now, 4),
    dt_last_login = now,
    dt_last_logout = now+4/(24*60*60),
    num_failures_since_login = 0
WHERE ((nm_login = :user_name)
    AND (nm_space = :user_nameSpace)
);
INSERT INTO t_user_credentials_history (
    nm_login,
    nm_space,
    tx_password,
    tt_end
) SELECT
    nm_login,
    nm_space,
    tx_password,
    dt_last_login
FROM t_user_credentials
WHERE ((nm_login = :user_name)
    AND (nm_space = :user_nameSpace)
);
END;
");
        public const string
            GetInvoice_ByIntervalIdAndAccountId = (@"
SELECT *
FROM t_invoice inv
WHERE ((inv.id_interval = :interval_id)
    AND (inv.id_acc = :account_id))
");
        public const string
            CountUsages_ByAccountId = (@"
SELECT COUNT(*) AS UsageCount
FROM t_acc_usage au
WHERE (au.id_acc = :account_id)
");
        /*public const string
            CountSvcOrderCookies_ByPayerUserName = (@"
SELECT COUNT(*) AS UsageCount
FROM t_svc_OrderCookies svcoc
WHERE (svcoc.c_Payer = :payer_userName)
");*/
        /*public const string
            CountPvOrderCookies_ByPayerUserName = (@"
SELECT COUNT(*) AS UsageCount
FROM t_pv_OrderCookies pvoc
WHERE (pvoc.c_Payer = :payer_userName)
");*/
        /*public const string
            GetFirstInterval_ByUsageCycleAndStatus = (@"
SELECT 
   tmp.ID AS ID,
   tmp.StartDate AS StartDate,
   tmp.EndDAte AS EndDate,
   tmp.Status AS Status,
   tmp.UsageCycle AS UsageCycle
FROM (
SELECT 
    ui.id_interval AS ID,
    ui.dt_start AS StartDate,
    ui.dt_end AS EndDate,
    ui.tx_interval_status AS Status,
    uct.tx_desc AS UsageCycle
FROM t_usage_interval ui
INNER JOIN t_usage_cycle uc 
    ON (ui.id_usage_cycle = uc.id_usage_cycle)
INNER JOIN t_usage_cycle_type uct 
    ON (uc.id_cycle_type = uct.id_cycle_type)
WHERE ((INSTR(:interval_usageCycle, uct.tx_desc, 1) > 0)
    AND (INSTR(:interval_status, ui.tx_interval_status, 1) > 0))
ORDER BY ui.dt_start ASC
) tmp
WHERE (ROWNUM = 1)
");*/
        /*public const string
            SetUsageIntervalStatus_ById = (@"
BEGIN
UPDATE t_usage_interval
SET tx_interval_status = :interval_status
WHERE (id_interval = :interval_id);

UPDATE t_acc_usage_interval
SET tx_status = :interval_status
WHERE (id_usage_interval = :interval_id);
END;
");*/
        /*public const string
            GetIntervalEopEventList_ByIntervalIdAndBillingGroupName = (@"
SELECT
    COUNT(revdep.id_event) AS ""Order"",
    revinst.id_instance AS InstanceID,
    rev.id_event AS ID,
    rev.tx_name AS Name,
    rev.tx_display_name AS DisplayName,
    rev.tx_type AS Type
FROM t_recevent rev
INNER JOIN t_recevent_dep revdep
    ON (rev.id_event = revdep.id_event)
INNER JOIN t_recevent_inst revinst
    ON (rev.id_event = revinst.id_event)
LEFT OUTER JOIN t_billgroup bg
    ON (bg.id_billgroup = revinst.id_arg_billgroup)
WHERE (rev.tx_type IN ('EndOfPeriod', 'Checkpoint')
    AND (revinst.id_arg_interval = :interval_id)
    AND (bg.tx_name = :billingGroup_name))
GROUP BY
    revinst.id_instance,
    rev.id_event,
    rev.tx_name,
    rev.tx_display_name,
    rev.tx_type
ORDER BY
    ""Order"",
    DisplayName
");*/
        /*public const string
            GetEventLastRunStatus_ByInstanceId = (@"
SELECT TEMP.Status
FROM (
    SELECT revrun.tx_status AS Status
    FROM t_recevent_run revrun
    WHERE (revrun.id_instance = :instance_id)
    ORDER BY revrun.dt_start DESC
) TEMP
WHERE (ROWNUM = 1)
");*/
    }
}
