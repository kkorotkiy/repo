﻿using System.Collections.Generic;
using MetraTech.Interop.COMMeter;


namespace MetraTech.TestSystem.Interaction
{
    public class MeteringSession
    {
        public readonly string ServiceName;
        public readonly Dictionary<string, object> Parameters;

        public bool HasChildSessions { get { return ((_childSessions != null) && (_childSessions.Count > 0)); } }
        private List<MeteringSession> _childSessions;

        public MeteringSession(string serviceName, Dictionary<string, object> parameters)
        {
            ServiceName = serviceName;
            Parameters = parameters;
        }

        public IEnumerable<MeteringSession> GetChildSessions() { return _childSessions; }

        public void AddChildSession(params MeteringSession[] sessions)
        {
            if (_childSessions == null) {
                _childSessions = (new List<MeteringSession>());
            }
            _childSessions.AddRange(sessions);
        }

        public void AddChildSession(string serviceName, Dictionary<string, object> sessionParameters)
        {
            var session = (new MeteringSession(serviceName, sessionParameters));
            AddChildSession(session);
        }
    }


    public static class MeteringManager
    {
        private static IMeter InitializeMeter()
        {
            var meter = (new Meter());
            meter.AddServer(0, "localhost", PortNumber.DEFAULT_HTTP_PORT, 0, "", "");
            return meter;
        }

        public static void Meter(string serviceName, Dictionary<string, object> parameters)
        {
            var session = (new MeteringSession(serviceName, parameters));
            Meter(session);
        }

        public static void Meter(params MeteringSession[] sessions)
        {
            var meter = InitializeMeter();
            meter.Startup();
            foreach (var session in sessions) { MeterSession(meter, session); }
            meter.Shutdown();
        }

        private static void
            MeterSession(
                IMeter meter,
                MeteringSession meterSession
            ) {
            var sessionSet = meter.CreateSessionSet();
            var session = sessionSet.CreateSession(meterSession.ServiceName);
            InitializeSession(session, meterSession.Parameters);
            if (meterSession.HasChildSessions) {
                AddChildSessions(session, meterSession.GetChildSessions());
            }
            session.RequestResponse = true;
            sessionSet.Close();
        }

        private static void
            InitializeSession(
                ISession session,
                Dictionary<string, object> parameters
            ) { foreach (var param in parameters) { session.InitProperty(param.Key, param.Value); } }

        private static void
            AddChildSessions(
                ISession parentSession,
                IEnumerable<MeteringSession> childSessions
            ) {
            foreach (var session in childSessions) {
                var childSession = parentSession.CreateChildSession(session.ServiceName);
                InitializeSession(childSession, session.Parameters);
                childSession.RequestResponse = true;
                if (session.HasChildSessions) {
                    AddChildSessions(childSession, session.GetChildSessions());
                }
            }
        }        
    }
}
