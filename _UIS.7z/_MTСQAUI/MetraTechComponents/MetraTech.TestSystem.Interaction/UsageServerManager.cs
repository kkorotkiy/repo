﻿using System;
using System.Collections.Generic;
using MetraTech.Interop.Rowset;
using MetraTech.UsageServer;
using System.Linq;
using UtilityComponents;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraTech.TestSystem.Interaction
{
    public static class UsageServerManager
    {
        #region Properties and Fields

        public static Client
            Client { get { return (_client ?? (_client = (new Client {SessionContext = env.SessionContext}))); } }
        private static Client _client;

        #endregion Properties and Fields

        public static UsageInterval GetFirstOpenUsageInterval(CycleType cycleType)
        {
            var filter = (new UsageIntervalFilter());
            var intervals = filter.GetIntervals().Cast<UsageInterval>();
            var interval =
                intervals
                    .Where(i => (i.CycleType == cycleType))
                    .OrderBy(i => i.StartDate)
                    .First(i => (i.Status == UsageIntervalStatus.Open) || (i.Status == UsageIntervalStatus.Billable));
            return interval;
        }

        #region Recurring Events

        public class RecurringEventInstance
        {
            public readonly int Id;
            public readonly string Name;
            public readonly string DisplayName;
            public readonly string Description;
            public readonly RecurringEventType Type;
            public RecurringEventInstanceStatus Status { get; private set; }
            public string DisplayStatus;

            public RecurringEventInstance(
                    int id,
                    string name,
                    string displayName,
                    string description,
                    RecurringEventType type,
                    RecurringEventInstanceStatus status
                ) {
                Id = id;
                Name = name;
                DisplayName = displayName;
                Description = description;
                Type = type;
                Status = status;
            }

            public void WaitStatus(RecurringEventInstanceStatus status, int timeout = 0)
            {
                var filter = (new RecurringEventInstanceFilter());
                filter.AddInstanceCriteria(Id);
                filter.AddEventTypeCriteria(Type);
                filter.AddStatusCriteria(status);
                var now = DateTime.Now;
                var rowset = filter.GetEndOfPeriodRowset(includeEOP: true, includeCheckpoint: false, includeRoot: false);
                while (Convert.ToBoolean(rowset.EOF)) {
                    if ((DateTime.Now-now).TotalMilliseconds > timeout) {
                        var message = string.Format(
                            "Event[id={0}, name='{1}'] did not get '{2}' status in timeout of '{3}' milliseconds.",
                            Id, Name, status, timeout);
                        throw (new Exception(message));
                    }
                    rowset = filter.GetEndOfPeriodRowset(includeEOP: true, includeCheckpoint: false, includeRoot: false);
                }
                Status = status;
            }
        }


        public static IEnumerable<RecurringEventInstance>
            GetRecurringEventInstances(
                int intervalId,
                string billingGroupName = "Default"
            ) {
            var recEventInstances = (new List<RecurringEventInstance>());
            var billingGroupFilter = (new BillingGroupFilter {IntervalId = intervalId, BillingGroupName = billingGroupName});
            var billingGroups = (new BillingGroupManager()).GetBillingGroups(billingGroupFilter);
            var billingGroup = ((BillingGroup) billingGroups[0]);
            var recEventInstanceFilter =
                (new RecurringEventInstanceFilter {
                    UsageIntervalID = intervalId,
                    BillingGroupID = billingGroup.BillingGroupID
                });
            var rowset =
                ((MTSQLRowsetClass)
                 recEventInstanceFilter.
                     GetEndOfPeriodRowset(
                         includeEOP: true,
                         includeCheckpoint: true,
                         includeRoot: false
                     ));
            rowset.MoveFirst();
            while (!Convert.ToBoolean(rowset.EOF)) {
                var id = ((int) rowset.Value["InstanceID"]);
                var name = ((string) rowset.Value["EventName"]);
                var displayName = ((string) rowset.Value["EventDisplayName"]);
                var description = (rowset.Value["EventDescription"] as string);
                var type = Cast.AsEnum<RecurringEventType>(rowset.Value["EventType"]);
                var status = Cast.AsEnum<RecurringEventInstanceStatus>(rowset.Value["Status"]);
                var recEventInstance = (new RecurringEventInstance(id, name, displayName, description, type, status));
                recEventInstances.Add(recEventInstance);
                rowset.MoveNext();
            }
            return recEventInstances;
        }

        public static void RunAdapter(int instanceId, bool ignoreDeps = true)
        {
            Client.SubmitEventForExecution(instanceId, ignoreDeps, comment: string.Empty);
            Client.NotifyServiceOfSubmittedEvents();
        }

        #endregion Recurring Events

        #region HardCloseUsageIntervals

        public static int
            HardCloseUsageIntervals(
                DateTime startDate,
                DateTime endDate,
                bool ignoreBillingGroups,
                params CycleType[] ignoreCycleTypes
            ) {
            int count = 0;
            var timeSpan = 
                (new UsageIntervalTimeSpan {
                    StartDateInclusive = true,
                    EndDateInclusive = true,
                    StartDate = startDate,
                    EndDate = endDate,
                });
            var filter = 
                (new UsageIntervalFilter {
                    UsageIntervalTimeSpan = timeSpan,
                });

            var intervals = filter.GetIntervals().Cast<UsageInterval>();
            foreach (var interval in intervals) {
                if (ignoreCycleTypes.Contains(interval.CycleType)) {
                    continue;
                }
                Client.HardCloseUsageInterval(interval.IntervalID, ignoreBillingGroups);
                ++count;
            }
            return count;
        }

        public static int
            HardCloseAllPastUsageIntervals(
                DateTime endDate,
                bool ignoreBillingGroups,
                params CycleType[] ignoreCycleTypes
            ) {
            var startDate = (new DateTime(1753, 1, 1));
            var intervalsCount =
                HardCloseUsageIntervals(
                    startDate,
                    endDate,
                    ignoreBillingGroups,
                    ignoreCycleTypes
                    );
            return intervalsCount;
            }

        #endregion HardCloseUsageIntervals
    }
}
