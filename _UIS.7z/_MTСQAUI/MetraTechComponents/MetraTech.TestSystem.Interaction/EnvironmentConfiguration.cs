﻿using System;
using System.Globalization;
using MetraTech.ActivityServices.Common;
using MetraTech.DataAccess;
using MetraTech.DomainModel.AccountTypes;
using MetraTech.DomainModel.BaseTypes;
using MetraTech.Interop.MTAuth;
using dbq = MetraTech.TestSystem.Interaction.DbQueries;
using db = MetraTech.TestSystem.Interaction.DatabaseManager;
using appConfig = System.Configuration.ConfigurationManager;


namespace MetraTech.TestSystem.Interaction
{
    public static class EnvironmentConfiguration
    {
        #region DateTime

        public const string MetraTechDateTimeFormat = ("yyyy'-'MM'-'dd'T'HH':'mm':'ss'Z'");
        public const string MetraTechDateFormat = ("yyyy'-'MM'-'dd");        
        public const string MMddHHmmssff = ("MMddHHmmssff");

        public static string
            @TimeStamp(
                string format = MMddHHmmssff
            ) { return DateTime.Now.ToString(format); }

        public static string
            @TimeStampUtc(
                string format = MMddHHmmssff
            ) { return DateTime.UtcNow.ToString(format); }

        public static string
            @MetraTimeStamp(
                string format = MMddHHmmssff
            ) { return MetraTime.Now.ToString(format); }

        #endregion DateTime

        #region Session Context

        public static readonly string MtRmpBin;

        public static readonly string ListenerWebSiteUrl;
        public static readonly string MetraNetWebSiteUrl;
        public static readonly string MetraViewWebSiteUrl;

        public const string UserNamespace = "mt";
        public const string SystemUserNamespace = "system_user";

        public static readonly SystemAccount MetraNetAdmin;
        public static readonly Account MetraViewAdmin;

        public static readonly CultureInfo Culture;

        public static readonly ConnectionInfo SuperUser;
        public static readonly ConnectionInfo NetMeter;

        public static MTSessionContext
            SessionContext { get { return (_sessionContext ?? (_sessionContext = LoginAsSuperUser())); } }
        private static MTSessionContext _sessionContext;


        static EnvironmentConfiguration()
        {
            MtRmpBin = Environment.GetEnvironmentVariable("MTRMPBIN");

            ListenerWebSiteUrl = appConfig.AppSettings["ListenerWebSiteUrl"];
            MetraNetWebSiteUrl = appConfig.AppSettings["MetraNetWebSiteUrl"];
            MetraViewWebSiteUrl = appConfig.AppSettings["MetraViewWebSiteUrl"];

            SuperUser = (new ConnectionInfo("SuperUser"));
            NetMeter = (new ConnectionInfo("NetMeter"));

            AccountManager.LoadAccount(
                (new AccountIdentifier(
                    userName: appConfig.AppSettings["MetraNetAdminUserName"],
                    nameSpace: SystemUserNamespace))
                , out MetraNetAdmin
                );
            MetraNetAdmin.Password_ = appConfig.AppSettings["MetraNetAdminPassword"];

            AccountManager.LoadAccount(
                (new AccountIdentifier(
                    userName: appConfig.AppSettings["MetraViewAdminUserName"],
                    nameSpace: UserNamespace))
                , out MetraViewAdmin
                );
            MetraViewAdmin.Password_ = appConfig.AppSettings["MetraViewAdminPassword"];

            Culture = CultureInfo.GetCultureInfo(appConfig.AppSettings["Language"]);
        }

        public static MTSessionContext LoginAsSuperUser()
        {
            var loginContext = (new MTLoginContextClass());
            var sessionContext = loginContext.Login(SuperUser.UserName, SystemUserNamespace, SuperUser.Password);
            return sessionContext;
        }

        public static void ProlongatePassword(Account account)
        {
            var userName = db.GetDbParameter("user_name", account.UserName);
            var userNamespace = db.GetDbParameter("user_nameSpace", account.Name_Space);
            db.ExecuteDbNonQuery(dbq.ProlongateUserPassword, userName, userNamespace);
        }

        #endregion Session Context

        public static class Password
        {
            public const string PasswordPrefix = ("AaZz_");
            public static readonly int PasswordPrefixLength = PasswordPrefix.Length;
            public const int PasswordSuffixValue = 1234;

            public static string Format(string password)
            {
                var passwordSuffix = GetPasswordSuffixValue(password);
                password = (PasswordPrefix + passwordSuffix);
                return password;
            }

            private static int GetPasswordSuffixValue(string password)
            {
                if (string.IsNullOrWhiteSpace(password)
                    || !password.StartsWith(PasswordPrefix)
                    || (password.Length == PasswordPrefixLength)
                   ) {
                    return PasswordSuffixValue;
                }
                int suffixValue;
                var suffix = password.Substring(PasswordPrefixLength);
                if (!int.TryParse(suffix, out suffixValue)
                    || (suffixValue < PasswordSuffixValue)
                    || (int.MaxValue <= suffixValue)
                   ) {
                    return PasswordSuffixValue;
                }
                suffixValue += 10;
                return suffixValue;
            }
        }
    }
}
