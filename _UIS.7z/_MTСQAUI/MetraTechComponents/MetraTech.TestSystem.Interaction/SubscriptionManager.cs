﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using MetraTech.ActivityServices.Common;
using MetraTech.Core.Services.ClientProxies;
using MetraTech.DomainModel.BaseTypes;
using MetraTech.DomainModel.ProductCatalog;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraTech.TestSystem.Interaction
{
    public static class SubscriptionManager
    {
        #region Properties and Fields

        private static SubscriptionServiceClient
            SubscriptionServiceClient {
            get {
                if ((_subscriptionServiceClient == null) || (_subscriptionServiceClient.State != CommunicationState.Opened)) {
                    _subscriptionServiceClient = CreateSubscriptionClient();
                }
                return _subscriptionServiceClient;
            }
        }
        private static SubscriptionServiceClient _subscriptionServiceClient;

        private static GroupSubscriptionServiceClient
            GroupSubscriptionServiceClient {
            get {
                if (_groupSubscriptionServiceClient == null || _groupSubscriptionServiceClient.State != CommunicationState.Opened) {
                    _groupSubscriptionServiceClient = CreateGroupSubClient();
                }
                return _groupSubscriptionServiceClient;
            }
        }
        private static GroupSubscriptionServiceClient _groupSubscriptionServiceClient;

        public static ProductOfferingServiceClient
            ProductOfferingServiceClient {
            get {
                if ((_productOfferingServiceClient == null) || (_productOfferingServiceClient.State != CommunicationState.Opened)) {
                    _productOfferingServiceClient = CreateProductOfferingServiceClient();
                }
                return _productOfferingServiceClient;
            }
        }
        private static ProductOfferingServiceClient _productOfferingServiceClient;

        
        private static IEnumerable<ProductOffering>
            ProductOfferings {
            get {
                if (_pos == null) {
                    var pos = (new MTList<ProductOffering>());
                    ProductOfferingServiceClient.GetProductOfferings(ref pos);
                    _pos = pos.Items;
                }
                return _pos;
            }
        }
        private static IEnumerable<ProductOffering> _pos;

        #endregion Properties and Fields

        #region Initialize

        private static SubscriptionServiceClient CreateSubscriptionClient()
        {
            var client = (new SubscriptionServiceClient("NetTcpBinding_ISubscriptionService"));
            client.ClientCredentials.UserName.UserName = env.SuperUser.UserName;
            client.ClientCredentials.UserName.Password = env.SuperUser.Password;
            return client;
        }
        private static GroupSubscriptionServiceClient CreateGroupSubClient()
        {
            var client = (new GroupSubscriptionServiceClient("NetTcpBinding_IGroupSubscriptionService"));
            client.ClientCredentials.UserName.UserName = env.SuperUser.UserName;
            client.ClientCredentials.UserName.Password = env.SuperUser.Password;
            return client;
        }
        public static ProductOfferingServiceClient CreateProductOfferingServiceClient()
        {
            var client = (new ProductOfferingServiceClient("NetTcpBinding_IProductOfferingService"));
            client.ClientCredentials.UserName.UserName = env.SuperUser.UserName;
            client.ClientCredentials.UserName.Password = env.SuperUser.Password;
            return client;
        }

        #endregion Initialize

        public static Subscription
            SubscribeAccount(
                Account account,
                BaseProductOffering po,
                DateTime? startDate = null,
                DateTime? endDate = null
            ) {
            var accIdent = (new AccountIdentifier(account._AccountID.Value));
            if (!startDate.HasValue) {
                startDate = account.AccountStartDate;
            }
            if (!endDate.HasValue) {
                endDate = account.AccountEndDate;
            }
            var subscriptionSpan = (new ProdCatTimeSpan { StartDate = startDate, EndDate = endDate });
            var subscription =
                (new Subscription {
                    SubscriptionSpan = subscriptionSpan,
                    ProductOfferingId = po.ProductOfferingId.Value
                });
            SubscriptionServiceClient.AddSubscription(accIdent, ref subscription);
            return subscription;
        }

        public static Subscription
            SubscribeAccount(
                Account account,
                string poName,
                DateTime? startDate = null,
                DateTime? endDate = null
            ) {
            var po = GetProductOffering(poName);
            var subscription = SubscribeAccount(account, po, startDate, endDate);
            return subscription;
        }


        public static void
            AddGroupSubscriptionMember(
                GroupSubscription groupSubscription,
                DateTime? startDate,
                DateTime? endDate,
                params Account[] memberList
            ) {
            if (groupSubscription.Members == null) {
                groupSubscription.Members = (new MTList<GroupSubscriptionMember>());
            }
            foreach (Account account in memberList) {
                var membershipSpan =
                    (new ProdCatTimeSpan {
                        StartDate = startDate,
                        EndDate = endDate
                    });
                var groupSubscriptionMember =
                    (new GroupSubscriptionMember {
                        AccountId = account._AccountID.Value,
                        MembershipSpan = membershipSpan
                    });
                groupSubscription.Members.Items.Add(groupSubscriptionMember);
            }
        }

        public static void
            AddGroupSubscriptionMember(
                GroupSubscription groupSubscription,
                params Account[] memberList
            ) {
            if (groupSubscription.Members == null) {
                groupSubscription.Members = (new MTList<GroupSubscriptionMember>());
            }
            foreach (Account account in memberList) {
                var membershipSpan =
                    (new ProdCatTimeSpan {
                        StartDate = account.AccountStartDate,
                        EndDate = account.AccountEndDate
                  });
                var groupSubscriptionMember =
                    (new GroupSubscriptionMember {
                        AccountId = account._AccountID.Value,
                        MembershipSpan = membershipSpan
                    });
                groupSubscription.Members.Items.Add(groupSubscriptionMember);
            }
        }

        public static void
            CreateGroupSubscription(
                GroupSubscription groupSubscription
            ) { GroupSubscriptionServiceClient.AddGroupSubscription(ref groupSubscription); }


        public static BaseProductOffering
            GetProductOffering(
                string poName
            ) { return ProductOfferings.Single(po => (po.Name == poName)); }

        public static BasePriceableItemInstance
            GetPriceableItemInstance(
                string poName, 
                string piName
            ) {
            BasePriceableItemInstance pi;
            var poId = (new PCIdentifier(poName));
            var piId = (new PCIdentifier(piName));
            ProductOfferingServiceClient.GetPIInstanceForPO(poId, piId, out pi);
            return pi;
        }
    }
}
