﻿using System;
using System.Diagnostics;
using System.Linq;
using System.IO;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Xml;
using MetraTech.ActivityServices.Common;
using MetraTech.Core.Services.ClientProxies;
using System.Collections.Generic;
using MetraTech.DomainModel.AccountTypes;
using MetraTech.DomainModel.BaseTypes;
using MetraTech.DomainModel.Enums.Core.Metratech_com_billingcycle;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraTech.TestSystem.Interaction
{
    public static class AccountManager
    {
        #region Properties and Fields

        private const string AccountTemplatesDirectory = "AccountTemplates.Test";
        private static readonly Dictionary<string, Account> AccountTemplates = (new Dictionary<string, Account>());

        private static readonly DataContractSerializer AccountSerializer;

        private static AccountServiceClient
            AccountServiceClient {
            get {
                if ((_serviceClient == null) || (_serviceClient.State != CommunicationState.Opened)) {
                    _serviceClient = CreateServiceClient();
                }
                return _serviceClient;
            }
        }
        private static AccountServiceClient _serviceClient;

        #endregion Properties and Fields

        #region Initialize

        static AccountManager() {
            AccountSerializer = (new DataContractSerializer(typeof(Account), Account.KnownTypes()));
        }

        private static AccountServiceClient CreateServiceClient()
        {
            var client = (new AccountServiceClient("NetTcpBinding_IAccountService"));
            Debug.Assert(client.ClientCredentials != null, "client.ClientCredentials != null");
            client.ClientCredentials.UserName.UserName = env.SuperUser.UserName;
            client.ClientCredentials.UserName.Password = env.SuperUser.Password;
            return client;
        }

        #endregion Initialize

        #region Serialize/Deserialize

        public static void Serialize<TAccount>(TAccount account, string filePath) where TAccount : Account
        {
            using (var streamWriter = (new StreamWriter(filePath))) {
                using (var xmlWriter = (XmlWriter.Create(streamWriter))) {
                    AccountSerializer.WriteObject(xmlWriter, account);
                }
            }
        }

        public static TAccount Deserialize<TAccount>(string filePath) where TAccount : Account
        {
            TAccount account;
            using (var streamReader = (new StreamReader(filePath))) {
                using (var xmlReader = (XmlReader.Create(streamReader))) {
                    var obj = AccountSerializer.ReadObject(xmlReader);
                    account = ((TAccount)obj);
                }
            }
            return account;
        }

        #endregion Serialize/Deserialize

        #region NewAccount

        private static TAccount
            NewTemplate<
                TAccount>(
                string filePath
            ) where TAccount : Account {
            if (!Path.IsPathRooted(filePath)) {
                filePath = Path.Combine(env.MtRmpBin, AccountTemplatesDirectory, filePath);
            }
            if (AccountTemplates.ContainsKey(filePath)) {
                return ((TAccount)AccountTemplates[filePath].Clone());
            }
            var account = Deserialize<TAccount>(filePath);
            AccountTemplates.Add(filePath, account);
            return ((TAccount) account.Clone());
        }

        public static Account
            NewAccount(
                string filePath,
                string userNamePrefix = null,
                Account ancestor = null,
                Account payer = null,
                DateTime? startDate = null,
                UsageCycleType usageCycleType = UsageCycleType.Monthly
            ) { return New<Account>(filePath, userNamePrefix, ancestor, payer, startDate, usageCycleType); }

        public static TAccount
            New<TAccount>(
                string filePath,
                string userNamePrefix = null,
                Account ancestor = null,
                Account payer = null,
                DateTime? startDate = null,
                UsageCycleType usageCycleType = UsageCycleType.Monthly
            ) where TAccount : Account {
            var account = NewTemplate<TAccount>(filePath);
            if (string.IsNullOrWhiteSpace(userNamePrefix)) {
                userNamePrefix = (new string(account.AccountType.ToCharArray().Take(4).ToArray())).ToUpper();
            }
            var userNameSuffix = env.TimeStamp();
            var accountUserName = (userNamePrefix+userNameSuffix);
            var ancestorUserName = ((ancestor != null) ? ancestor.UserName : "root");
            var payerUserName = ((payer != null) ? payer.UserName : accountUserName);
            var payerId = ((payer != null) ? payer._AccountID : null);
            if (!startDate.HasValue) {
                startDate = DateTime.Now;
            }
            account.UserName = accountUserName;
            account.AncestorAccountID = null;
            account.AncestorAccount = ancestorUserName;
            account.PayerID = payerId;
            account.PayerAccount = payerUserName;
            account.AccountStartDate = startDate;
            account.Hierarchy_StartDate = startDate;
            var accountInternalView = GetAccountInternalView(account);
            accountInternalView.UsageCycleType = usageCycleType;
            var contactView = GetAccountContactView(account);
            if (contactView != null) {
                contactView.FirstName = ("FN:"+userNamePrefix);
                contactView.LastName = ("LN:"+userNameSuffix);
            }
            return account;
        }

        #endregion NewAccount

        #region AddAccount

        public static Account
            AddNewAccount(
                string filePath,
                string userNamePrefix = null,
                Account ancestor = null,
                Account payer = null,
                DateTime? startDate = null,
                UsageCycleType usageCycleType = UsageCycleType.Monthly
            ) { return AddNew<Account>(filePath, userNamePrefix, ancestor, payer, startDate, usageCycleType); }

        public static TAccount
            AddNew<
                TAccount>(
                string filePath,
                string userNamePrefix = null,
                Account ancestor = null,
                Account payer = null,
                DateTime? startDate = null,
                UsageCycleType usageCycleType = UsageCycleType.Monthly
            ) where TAccount : Account {
            Account account = New<TAccount>(filePath, userNamePrefix, ancestor, payer, startDate, usageCycleType);
            AccountServiceClient.AddAccountWithoutWorkflow(ref account);
            return ((TAccount) account);
        }

        public static void
            AddAccountWithoutWorkflow<
                TAccount>(
                ref TAccount account
            ) where TAccount : Account {
            Account acc = account;
            AccountServiceClient.AddAccountWithoutWorkflow(ref acc);
            account = ((TAccount) acc);
        }

        #endregion AddAccount

        #region LoadAccount

        public static void
            LoadAccount<
                TAccount>(
                AccountIdentifier accountIdentifier,
                out TAccount account,
                DateTime? timeStamp = null
            ) where TAccount : Account {
            if (!timeStamp.HasValue) {
                timeStamp = DateTime.UtcNow;
            }
            Account acc;
            AccountServiceClient.LoadAccount(accountIdentifier, timeStamp.Value, out acc);
            account = ((TAccount) acc);
        }

        public static void
            LoadAccountWithViews<
                TAccount>(
                AccountIdentifier accountIdentifier,
                out TAccount account,
                DateTime? timeStamp = null
            ) where TAccount : Account {
            if (!timeStamp.HasValue) {
                timeStamp = DateTime.UtcNow;
            }
            Account acc;
            AccountServiceClient.LoadAccountWithViews(accountIdentifier, timeStamp.Value, out acc);
            account = ((TAccount) acc);
        }

        #endregion LoadAccount

        #region Account Views

        public const string DisplayNameFormat = ("{0}{1}({2})");

        public static string
            FormatDisplayName(
                Account account,
                bool friendly = false,
                bool nbsp = false
            ) {
            var userName = (friendly ? FormatFriendlyUserName(account, nbsp) : account.UserName);
            var space = (nbsp ? '\u00a0' : ' ');
            var displayName = string.Format(DisplayNameFormat, userName, space, account._AccountID);
            return displayName;
        }

        public static string
            FormatFriendlyUserName(
                Account account,
                bool nbsp = false
            ) {
            var userName = account.UserName;
            var contactView = GetAccountContactView(account);
            if (contactView == null) {
                return userName;
            }
            var firstName = contactView.FirstName;
            var lastName = contactView.LastName;
            var firstNameNotNull = !string.IsNullOrEmpty(firstName);
            var lastNameNotNull = !string.IsNullOrEmpty(lastName);
            if (firstNameNotNull && lastNameNotNull) {
                var space = (nbsp ? '\u00a0' : ' ');
                userName = (firstName+space+lastName);
            } else if (lastNameNotNull) {
                userName = lastName;
            } else if (firstNameNotNull) {
                userName = firstName;
            }
            return userName;
        }

        public static ContactView GetAccountContactView(Account account)
        {
            ContactView contactView = null;
            var views = account.GetViews();
            if (views.ContainsKey("LDAP")) {
                contactView = (views["LDAP"].SingleOrDefault(v => (v is ContactView)) as ContactView);
            }
            return contactView;
        }

        public static InternalView GetAccountInternalView(Account account)
        {
            return ((InternalView) account.GetInternalView());
        }

        #endregion Account Views
    }
}
