﻿using System.Text.RegularExpressions;
using MetraTech.WebComponents.WebForms;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestComponents;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;


namespace MetraTech.TestComponents
{
    public static class GridExt
    {
        #region GetGridPageCount

        private const string GetGridPageCountMessageFormat = ("Extract grid page count from label '{1}' for grid[{0}].");

        public static uint
            GetGridPageCount(
                this WebForm mtGrid,
                ulong timeout = ulong.MinValue
            ) {
            var pageCountLabel = mtGrid.ReadElementValue<string>(mt.Label_GridPageCount, timeout: timeout);
            var pageCountMatch = Regex.Match(pageCountLabel, @"\d+");
            if (!pageCountMatch.Success) {
                Assert.Fail(GetGridPageCountMessageFormat, mtGrid.FullName, pageCountLabel);
            }
            var pageCount = uint.Parse(pageCountMatch.Value);
            return pageCount;
        }

        public static uint
            GetGridPageCount_1(
                this WebForm mtGrid,
                ulong timeout = ulong.MinValue
            ) {
            var pageIndexDropBoxDisplayed = mtGrid.Displayed(mt.DropBox_GridPageIndex_1, timeout: 160UL);
            if (!pageIndexDropBoxDisplayed) {
                return 1;
            }
            var pageIndexDropBoxLastChild = mtGrid.Site().GetXPath(mt.DropBox_GridPageIndex_1, _.last_child);
            var pageCount = mtGrid.ReadElementValue<uint>(pageIndexDropBoxLastChild, timeout: timeout);
            return pageCount;
        }

        #endregion GetGridPageCount

        #region Resolve Grid Column

        #region ResolveGridColumn

        public static void
            ResolveGridColumn(
                this WebForm mtGrid,
                ref GridCellInfo gridCellInfo,
                bool resolveName = false,
                ulong timeout = ulong.MinValue
            ) {
            if (gridCellInfo.ColumnName != null) {
                var columnIndex = mtGrid.GetGridColumnIndex(gridCellInfo.ColumnName, timeout);
                gridCellInfo = (new GridCellInfo(columnIndex, gridCellInfo.ColumnName, gridCellInfo.Value));
            } else if (resolveName && (gridCellInfo.ColumnIndex > 0)) {
                var columnName = mtGrid.GetGridColumnName(gridCellInfo.ColumnIndex, timeout);
                gridCellInfo = (new GridCellInfo(gridCellInfo.ColumnIndex, columnName, gridCellInfo.Value));
            }
        }

        public static int
            GetGridColumnIndex(
                this WebForm mtGrid,
                string columnName,
                ulong timeout = ulong.MinValue
            ) {
            var columnIndex =
                mtGrid.Position(
                    mt.GridColumn_ByName,
                    columnName,
                    skipNotDisplayed: false,
                    timeout: timeout
                    );
            return columnIndex;
        }

        public static string
            GetGridColumnName(
                this WebForm mtGrid,
                int columnIndex,
                ulong timeout = ulong.MinValue
            ) {
            var columnName = mtGrid.ReadElementValue<string>(mt.GridColumn_ByIndex, columnIndex, timeout);
            return columnName;
        }

        #endregion ResolveGridColumn

        #region ResolveGridColumn_1

        public static void
            ResolveGridColumn_1(
                this WebForm mtGrid,
                ref GridCellInfo gridCellInfo,
                bool resolveName = false,
                ulong timeout = ulong.MinValue
            ) {
            if (gridCellInfo.ColumnName != null) {
                var columnIndex = mtGrid.GetGridColumnIndex_1(gridCellInfo.ColumnName, timeout);
                gridCellInfo = (new GridCellInfo(columnIndex, gridCellInfo.ColumnName, gridCellInfo.Value));
            } else if (resolveName && (gridCellInfo.ColumnIndex > 0)) {
                var columnName = mtGrid.GetGridColumnName_1(gridCellInfo.ColumnIndex, timeout);
                gridCellInfo = (new GridCellInfo(gridCellInfo.ColumnIndex, columnName, gridCellInfo.Value));
            }
        }

        public static int
            GetGridColumnIndex_1(
                this WebForm mtGrid,
                string columnName,
                ulong timeout = ulong.MinValue
            ) {
            var columnIndex =
                mtGrid.Position(
                    mt.GridColumn_ByName_1,
                    columnName,
                    skipNotDisplayed: false,
                    timeout: timeout
                    );
            return columnIndex;
        }

        public static string
            GetGridColumnName_1(
                this WebForm mtGrid,
                int columnIndex,
                ulong timeout = ulong.MinValue
            ) {
            var columnName = mtGrid.ReadElementValue<string>(mt.GridColumn_ByIndex_1, columnIndex, timeout);
            return columnName;
        }

        #endregion ResolveGridColumn_1

        #endregion Resolve Grid Column

        #region Find Grid Row

        public const ulong WaitRowTimeout = 2048UL;
        public const string FindGridRowMessageFormat = (@"Find grid row: [{0}\{1}]");
        
        #region FindGridRow

        public static WebForm
            FindGridRow(
                this WebForm mtGrid,
                GridCellInfo gridCellInfo,
                ulong waitRowTimeout = WaitRowTimeout,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) {
            mtGrid.ResolveGridColumn(ref gridCellInfo, timeout: timeout);
            var pageCount = mtGrid.GetGridPageCount(timeout);
            var pageIndex = ((pageCount == 1) ? 1 : mtGrid.ReadTextBoxValue<uint>("Page", timeout));
            var gridRow = FindGridRow(mtGrid, gridCellInfo, pageIndex, pageCount, waitRowTimeout, timeout);
            if ((gridRow == default(WebForm)) && (pageIndex > 1)) {
                gridRow = mtGrid
                    .EnterTextBoxValue(caption: "Page", value: 1, submit: true, timeout: timeout)
                    .WaitLoad(force: false, timeout: timeout)
                    .FindGridRow(gridCellInfo, 1, --pageIndex, waitRowTimeout, timeout);
            }
            if ((gridRow == default(WebForm)) && throwNotFound) {
                Assert.Fail(FindGridRowMessageFormat, mtGrid.FullName, gridCellInfo);
            }
            return gridRow;
        }

        private static WebForm
            FindGridRow(
                this WebForm mtGrid,
                GridCellInfo gridCellInfo,
                uint pageIndex,
                uint pageEndIndex,
                ulong waitRowTimeout = WaitRowTimeout,
                ulong timeout = ulong.MinValue
            ) {
            while (pageIndex <= pageEndIndex) {
                var gridRowIndex =
                    mtGrid.Position(
                        mt.GridRow_ByColumnIndex_And_CellValue,
                        (new[] {gridCellInfo.ColumnIndex, gridCellInfo.Value}),
                        timeout: waitRowTimeout
                        );
                if (gridRowIndex > 0) {
                    var gridRow = mtGrid.GetForm(mt.GridRow_ByIndex, gridRowIndex, waitLoad: false);
                    return gridRow;
                }
                if (++pageIndex <= pageEndIndex) {
                    mtGrid
                        .EnterTextBoxValue(caption: "Page", value: pageIndex, submit: true, timeout: timeout)
                        .WaitLoad(force: false, timeout: timeout);
                }
            }
            return default(WebForm);
        }

        #endregion FindGridRow

        #region FindGridRow_1

        public static WebForm
            FindGridRow_1(
                this WebForm mtGrid,
                GridCellInfo gridCellInfo,
                ulong waitRowTimeout = WaitRowTimeout,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) {
            mtGrid.ResolveGridColumn_1(ref gridCellInfo, timeout: timeout);
            var pageCount = mtGrid.GetGridPageCount_1(timeout);
            var pageIndex = ((pageCount == 1) ? 1 : mtGrid.ReadDropBoxValue<uint>(mt.DropBox_GridPageIndex_1,timeout));
            var gridRow = FindGridRow_1(mtGrid, gridCellInfo, pageIndex, pageCount, waitRowTimeout, timeout);
            if ((gridRow == default(WebForm)) && (pageIndex > 1)) {
                gridRow = mtGrid.
                    EnterDropBoxValue(control: mt.DropBox_GridPageIndex_1, value: 1, dropDown: false, timeout: timeout).
                    WaitLoad(force: false, timeout: timeout).
                    FindGridRow_1(gridCellInfo, 1, --pageIndex, waitRowTimeout, timeout);
            }
            if ((gridRow == default(WebForm)) && throwNotFound) {
                Assert.Fail(FindGridRowMessageFormat, mtGrid.FullName, gridCellInfo);
            }
            return gridRow;
        }

        private static WebForm
            FindGridRow_1(
                this WebForm mtGrid,
                GridCellInfo gridCellInfo,
                uint pageIndex,
                uint pageEndIndex,
                ulong waitRowTimeout = WaitRowTimeout,
                ulong timeout = ulong.MinValue
            ) {
            while (pageIndex <= pageEndIndex) {
                var gridRowIndex =
                    mtGrid.Position(
                        mt.GridRow_ByColumnIndex_And_CellValue_1,
                        (new[] {gridCellInfo.ColumnIndex, gridCellInfo.Value}),
                        timeout: waitRowTimeout
                        );
                --gridRowIndex; //header
                if (gridRowIndex > 0) {
                    var gridRow = mtGrid.GetForm(mt.GridRow_ByIndex_1, gridRowIndex, waitLoad: false);
                    return gridRow;
                }
                if (++pageIndex <= pageEndIndex) {
                    mtGrid.
                        EnterDropBoxValue(control: mt.DropBox_GridPageIndex_1, value: pageIndex, dropDown: false, timeout: timeout).
                        WaitLoad(force: false, timeout: timeout);
                }
            }
            return default(WebForm);
        }

        #endregion FindGridRow_1

        #endregion Find Grid Row

        #region CheckGridRow

        public const string CheckGridRowMessageFormat = (@"Check exists grid row: [{0}\{1}]");

        public static WebForm
            CheckGridRow(
                this WebForm mtGrid,
                GridCellInfo gridCellInfo,
                bool exists,
                ulong waitRowTimeout = WaitRowTimeout,
                ulong timeout = ulong.MinValue,
                string message = null
            ) {
            var gridRow = FindGridRow(mtGrid, gridCellInfo, waitRowTimeout, timeout, throwNotFound: false);
            var actualExists = (gridRow != default(WebForm));
            if (message == null) {
                message = string.Format(CheckGridRowMessageFormat, mtGrid.FullName, gridCellInfo);
            }
            global::WebComponents.WebForms.WebFormExt.
                    ValidateValue(
                        expectedValue: exists,
                        actualValue: actualExists,
                        @equals: true,
                        throwOnFailure: true,
                        message: message
                );
            return mtGrid;
        }

        public static WebForm
            CheckGridRow_1(
                this WebForm mtGrid,
                GridCellInfo gridCellInfo,
                bool exists,
                ulong waitRowTimeout = WaitRowTimeout,
                ulong timeout = ulong.MinValue,
                string message = null
            ) {
            var gridRow = FindGridRow_1(mtGrid, gridCellInfo, waitRowTimeout, timeout, throwNotFound: false);
            var actualExists = (gridRow != default(WebForm));
            if (message == null) {
                message = string.Format(CheckGridRowMessageFormat, mtGrid.FullName, gridCellInfo);
            }
            global::WebComponents.WebForms.WebFormExt.
                    ValidateValue(
                        expectedValue: exists,
                        actualValue: actualExists,
                        @equals: true,
                        throwOnFailure: true,
                        message: message
                );
            return mtGrid;
        }

        #endregion CheckGridRow

        #region Select Grid Row

        #region SelectGridRow

        public static WebForm
            SelectGridRow(
                this WebForm mtGrid,
                GridCellInfo gridCellInfo,
                bool select = true,
                bool switchToRow = false,
                ulong waitRowTimeout = WaitRowTimeout,
                ulong timeout = ulong.MinValue
            ) {
            var gridRow =
                FindGridRow(
                    mtGrid,
                    gridCellInfo,
                    waitRowTimeout,
                    timeout,
                    throwNotFound: true
                    );
            gridRow.
                EnterCheckBoxValue(
                    control: mt.CheckBox_Select_GridRow,
                    value: select,
                    timeout: timeout
                );
            return (switchToRow ? gridRow : mtGrid);
        }

        public static WebForm
            SelectSingleGridRow(
                this WebForm mtGrid,
                GridCellInfo gridCellInfo,
                bool switchToRow = false,
                ulong waitRowTimeout = WaitRowTimeout,
                ulong timeout = ulong.MinValue
            ) {
            var gridRow =
                FindGridRow(
                    mtGrid,
                    gridCellInfo,
                    waitRowTimeout,
                    timeout,
                    throwNotFound: true
                    );
            gridRow.
                EnterCheckBoxValue(
                    control: mt.RadioButton_Select_GridRow,
                    value: true,
                    timeout: timeout
                );
            return (switchToRow ? gridRow : mtGrid);
        }

        #endregion Select Grid Row

        #region SelectGridRow_1

        public static WebForm
            SelectGridRow_1(
                this WebForm mtGrid,
                GridCellInfo gridCellInfo,
                bool select = true,
                bool switchToRow = false,
                ulong waitRowTimeout = WaitRowTimeout,
                ulong timeout = ulong.MinValue
            ) {
            var gridRow =
                FindGridRow_1(
                    mtGrid,
                    gridCellInfo,
                    waitRowTimeout,
                    timeout,
                    throwNotFound: true
                    );
            gridRow.
                EnterCheckBoxValue(
                    control: mt.CheckBox_Select_GridRow_1,
                    value: select,
                    timeout: timeout
                );
            return (switchToRow ? gridRow : mtGrid);
        }

        public static WebForm
            SelectSingleGridRow_1(
                this WebForm mtGrid,
                GridCellInfo gridCellInfo,
                bool switchToRow = false,
                ulong waitRowTimeout = WaitRowTimeout,
                ulong timeout = ulong.MinValue
            ) {
            var gridRow =
                FindGridRow_1(
                    mtGrid,
                    gridCellInfo,
                    waitRowTimeout,
                    timeout,
                    throwNotFound: true
                    );
            gridRow.
                EnterCheckBoxValue(
                    control: mt.RadioButton_Select_GridRow_1,
                    value: true,
                    timeout: timeout
                );
            return
                (switchToRow
                     ? gridRow
                     : mtGrid
                );
        }

        #endregion SelectGridRow_1

        #endregion Select Grid Row

        #region GetGridRowCell

        public static WebForm
            GetGridRowCell(
                this WebForm mtGridRow,
                GridCellInfo gridCellInfo,
                ulong timeout = ulong.MinValue
            ) {
            var mtGrid = mtGridRow.ParentForm;
            mtGrid.ResolveGridColumn(
                ref gridCellInfo,
                timeout: timeout
                );
            var gridRowCell =
                mtGridRow.GetForm(
                    control: mt.GridRowCell_ByColumnIndex,
                    caption: gridCellInfo.ColumnIndex,
                    timeout: timeout
                    );
            return gridRowCell;
        }

        public static WebForm
            GetGridRowCell_1(
                this WebForm mtGridRow,
                GridCellInfo gridCellInfo,
                ulong timeout = ulong.MinValue
            ) {
            var mtGrid = mtGridRow.ParentForm;
            mtGrid.ResolveGridColumn_1(
                ref gridCellInfo,
                timeout: timeout
                );
            var gridRowCell =
                mtGridRow.GetForm(
                    control: mt.GridRowCell_ByColumnIndex_1,
                    caption: gridCellInfo.ColumnIndex,
                    timeout: timeout
                    );
            return gridRowCell;
        }

        #endregion GetGridRowCell

        #region ValidateGridRow

        public static WebForm
            ValidateGridRow(
                this WebForm mtGridRow,
                GridCellInfo gridCellInfo,
                bool @equals = true,
                ulong timeout = ulong.MinValue
            ) {
            var gridRowCell = GetGridRowCell(mtGridRow, gridCellInfo, timeout);
            var positioningArg = string.Format("text()='{0}'", gridCellInfo.Value);
            gridRowCell
                .WithPositioning(
                    positioningArg
                ).CheckDisplayed(
                    control: _.descendant_or_self,
                    caption: positioningArg,
                    displayed: @equals,
                    timeout: timeout
                );
            return mtGridRow;
        }

        public static WebForm
            ValidateGridRow_1(
                this WebForm mtGridRow,
                GridCellInfo gridCellInfo,
                bool @equals = true,
                ulong timeout = ulong.MinValue
            ) {
            var gridRowCell = GetGridRowCell_1(mtGridRow, gridCellInfo, timeout);
            var positioningArg = string.Format("text()='{0}'", gridCellInfo.Value);
            gridRowCell
                .WithPositioning(
                    positioningArg
                ).CheckDisplayed(
                    control: _.descendant_or_self,
                    caption: positioningArg,
                    displayed: @equals,
                    timeout: timeout
                );
            return mtGridRow;
        }

        #endregion ValidateGridRow
    }
}
