﻿using System.Globalization;
using System.ServiceProcess;
using LogComponents;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestComponents;
using UtilityComponents;
using WebComponents;
using MetraTech.WebComponents;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraTech.TestComponents
{
    public abstract class MetraTechTestSuite : TestController
    {
        #region Properties and Fields

        protected static MetraTechWebSite WebSite { get; private set; }
        protected override CultureInfo Culture { get { return env.Culture; } }

        #endregion Properties and Fields

        #region Test Setup

        [TestInitialize]
        public void SetupTest()
        {
            LogManager.LogInfo("BEGIN setup test '{0}'.", TestContext.TestName);
            ProcessTestSetup();
            LogManager.LogInfo("END setup test '{0}'.", TestContext.TestName);
        }

        protected virtual void ProcessTestSetup() { LoadWebSite(); }

        protected virtual void LoadWebSite()
        {
            var webSiteUrl = GetWebSiteLoadUrl();
            if ((WebSite != null) && WebSite.IsLoaded && (WebSite.Url == webSiteUrl)) {
                return;
            }
            WebBrowser.LoadWebSite<MetraTechWebSite>(webSiteUrl);
            WebSite = ((MetraTechWebSite)WebBrowser.WebSite);
        }

        protected abstract string GetWebSiteLoadUrl();

        #endregion Test Setup

        #region Test Cleanup

        [TestCleanup]
        public void CleanupTest()
        {
            LogManager.LogInfo("BEGIN cleanup test '{0}'.", TestContext.TestName);
            ProcessTestCleanup();
            LogManager.LogInfo("END cleanup test '{0}'.", TestContext.TestName);
        }

        protected virtual UnitTestOutcome ProcessTestCleanup()
        {
            var testOutcome = TestContext.CurrentTestOutcome;
            var testPassed = (testOutcome == UnitTestOutcome.Passed);
            var logMessage = string.Format("Test status '{0}'.", testOutcome.ToString().ToUpper());
            var logRecordType = (testPassed ? LogRecordType.INFO : LogRecordType.FATAL);
            LogManager.LogRecord(logMessage, recordType: logRecordType, takeScreenshot: !testPassed);
            if (!testPassed) {
                _TryLogOut();
            }
            return testOutcome;
        }

// ReSharper disable InconsistentNaming
        protected abstract bool _TryLogOut();
// ReSharper restore InconsistentNaming

        #endregion Test Cleanup

        #region Services

        protected const ulong ServiceTimeout = 600000UL; // 10 min.

        protected static void StartService(params string[] services)
        {
            foreach (var service in services) {
                var serviceStatus = ServiceExt.StartLocal(service, ServiceTimeout, throwTimedOut: false);
                Assert.AreEqual(
                    ServiceControllerStatus.Running,
                    serviceStatus,
                    "Start local service[name:'{0}'] with timeout[{1}] millisec.",
                    service, ServiceTimeout
                    );
            }
        }

        protected static void StopService(params string[] services)
        {
            foreach (var service in services) {
                var serviceStatus = ServiceExt.StopLocal(service, ServiceTimeout, throwTimedOut: false);
                Assert.AreEqual(
                    ServiceControllerStatus.Stopped,
                    serviceStatus,
                    "Stop local service[name:'{0}'] with timeout[{1}] millisec.",
                    service, ServiceTimeout
                    );
            }
        }

        protected static void RestartService(params string[] services)
        {
            foreach (var service in services) {
                var serviceStatus = ServiceExt.RestartLocal(service, ServiceTimeout, throwTimedOut: false);
                Assert.AreEqual(
                    ServiceControllerStatus.Running,
                    serviceStatus,
                    "Restart local service[name:'{0}'] with timeout[{1}] millisec.",
                    service, ServiceTimeout
                    );
            }
        }

        #endregion Services

        #region Process

        protected const int ProcessTimeout = 600000; // 10 min.

        protected static int
            StartAndWaitForExit(
                string fileName,
                string arguments,
                int timeout = ProcessTimeout
            ) {
            var exitCode = ProcessExt.StartAndWaitForExit(fileName, arguments, timeout);
            Assert.IsTrue(
                exitCode.HasValue,
                "Exit process [name:'{0}', args:<{1}>] with timeout[{2}] millisec.",
                fileName, arguments, timeout
                );
            return exitCode.Value;
        }

        protected static int
            StartProcessAndWaitForExit<
                TArgument>(
                string fileName,
                TArgument[] args,
                int timeout = ProcessTimeout
            ) {
            var exitCode = ProcessExt.StartAndWaitForExit(fileName, args, timeout);
            var arguments = ProcessExt.FormatArguments(args);
            Assert.IsTrue(
                exitCode.HasValue,
                "Exit process [name:'{0}', args:<{1}>] with timeout[{2}] millisec.",
                fileName, arguments, timeout
                );
            return exitCode.Value;
        }

        #endregion Process
    }
}
