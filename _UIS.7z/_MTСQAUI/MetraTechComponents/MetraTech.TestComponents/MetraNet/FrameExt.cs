﻿using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;


namespace MetraTech.TestComponents.MetraNet
{
    public static class FrameExt
    {
        #region Navigate AccountToolbar

        /// <summary>
        /// Navigates [<see cref="mn.ToolbarMenu"/>, '<paramref name="menu"/>'].
        /// Clicks [<see cref="mn.ToolbarMenuItem"/>, '<paramref name="menuItem"/>'].
        /// Returns <see cref="WebFormExt.Page(WebForm,bool,bool,ulong)"/>.
        /// </summary>
        public static WebPage
            NavigateAccountToolbar(
                this WebForm mnFrame,
                string menu,
                string menuItem,
                bool waitLoad = false,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var mainContentIframe = mnFrame.Page().GetFrame(caption: null);
            var toolbarMenu = mainContentIframe.ExpandForm(mn.ToolbarMenu, menu, timeout: timeout);
            toolbarMenu.Click(mn.ToolbarMenuItem, menuItem,timeout);
            var page = mnFrame.Page(waitLoad, force, timeout);
            return page;
        }

        
        /// <summary>
        /// Navigates <see cref="NavigateAccountToolbar"/>.
        /// Returns frame by <see cref="MetraNet.PageExt.GetFrame(WebPage,object,bool,bool,ulong)"/> with caption (<paramref name="caption"/>??<paramref name="menuItem"/>).
        /// </summary>
        public static WebForm
            NavigateAccountToolbarToFrame(
                this WebForm mnFrame,
                string menu,
                string menuItem,
                string caption = null,
                bool waitLoad = false,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            if (caption == null) {
                caption = menuItem;
            }
            var frame = mnFrame
                .NavigateAccountToolbar(menu, menuItem, waitLoad, force, timeout)
                .GetFrame(caption: caption, timeout: timeout)
                ;
            return frame;
        }

        /// <summary>
        /// Navigates <see cref="NavigateAccountToolbar"/>.
        /// Returns frame by <see cref="MetraNet.PageExt.GetFrame_1(WebPage,object,bool,bool,ulong)"/> with caption (<paramref name="caption"/>??<paramref name="menuItem"/>).
        /// </summary>
        public static WebForm
            NavigateAccountToolbarToFrame_1(
                this WebForm mnFrame,
                string menu,
                string menuItem,
                string caption = null,
                bool waitLoad = false,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            if (caption == null) {
                caption = menuItem;
            }
            var frame = mnFrame
                .NavigateAccountToolbar(menu, menuItem, waitLoad, force, timeout)
                .GetFrame_1(caption: caption, timeout: timeout)
                ;
            return frame;
        }

        #endregion Navigate AccountToolbar
    }
}
