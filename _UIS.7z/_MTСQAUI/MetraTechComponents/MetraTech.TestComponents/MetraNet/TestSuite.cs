﻿using System;
using WebComponents;
using WebComponents.WebElements;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraTech.TestComponents.MetraNet
{
    public abstract class MetraNetTestSuite : MetraTechTestSuite
    {
        protected override string GetWebSiteLoadUrl() { return env.MetraNetWebSiteUrl; }

        protected override bool _TryLogOut()
        {
            try {
                WebSite.LogOut();
                return true;
            } catch (Exception exception) {
                LogUnhandledException(exception);
            }
            try {
                WebBrowser.SwitchToMainWindow(2560UL);
                if (WebSite.IsPageLoaded(mn.LoginPage, force: true, timeout:2560UL)) {
                    return true;
                }
                var mainPage = WebSite.WaitPageLoaded(mn.MainPage, timeout:2560UL);
                mainPage.Container.Click(timeout: 640UL);
                var logoutButtonDisplayed = mainPage.WaitDisplayed(_.Button, "Logout", throwTimedOut:false, timeout:2560UL);
                if (!logoutButtonDisplayed) {
                    mainPage.Reload(force: true, timeout: 5120UL);
                }
                mainPage.Click(_.Button, "Logout", timeout: 2560UL);
                mainPage.WaitDispose();
                WebSite.WaitPageLoaded(mn.LoginPage);
                return true;
            } catch (Exception exception) {
                LogUnhandledException(exception);
                return false;
            }
        }
    }
}
