﻿using MetraTech.DomainModel.BaseTypes;
using UtilityComponents;
using WebComponents;
using WebComponents.WebForms;
using MetraTech.WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mn = MetraTech.WebComponents.WebControls.MetraNet;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraTech.TestComponents.MetraNet
{
    public static class PageExt
    {
        #region Frames Names

        /// <summary>
        /// Used in <see cref="GetFrame(WebPage, object, bool, bool, ulong)"/> method.
        /// <seealso cref="GetFrame(WebPage, object, object[], bool, bool, ulong)"/>
        /// </summary>
        public const string MainContentIframe = ("MainContentIframe");

        /// <summary>
        /// Used in <see cref="GetFrame_1(WebPage, object, bool, bool, ulong)"/> method.
        /// <seealso cref="GetFrame_1(WebPage, object, object[], bool, bool, ulong)"/>
        /// </summary>
        public const string TicketFrame = ("ticketFrame");

        /// <summary>
        /// Frame placed on "Finder" tab on "Account" sidebar.
        /// </summary>
        private const string AccountSelector = "AccountSelector";

        #endregion Frames Names

        #region Log In

        public static WebPage
            LogInAsAdmin(
                this WebSite mtWebSite,
                bool changePassword = false,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) { return LogIn(mtWebSite, env.MetraNetAdmin, changePassword, newPassword, timeout); }

        public static WebPage
            LogIn(
                this WebSite mtWebSite,
                Account account,
                bool changePassword = false,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) { return LogIn(mtWebSite, account.UserName, account.Password_, changePassword, newPassword, timeout); }

        public static WebPage
            LogIn(
                this WebSite mtWebSite,
                string userName,
                string password,
                bool changePassword = false,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) {
            var isLoginPageLoaded = mtWebSite.IsPageLoaded(mn.LoginPage, force: true, timeout: 2648UL);
            var loginPage = (isLoginPageLoaded ? mtWebSite.Page() : mtWebSite.LoadPage(mn.LoginPage, timeout: timeout));
            return loginPage.LogIn(userName, password, changePassword, newPassword, timeout);
        }


        public static WebPage
            LogInAsAdmin(
                this WebPage mnLogInPage,
                bool changePassword = false,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) { return LogIn(mnLogInPage, env.MetraNetAdmin, changePassword, newPassword, timeout); }

        public static WebPage
            LogIn(
                this WebPage mnLogInPage,
                Account account,
                bool changePassword = false,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) { return LogIn(mnLogInPage, account.UserName, account.Password_, changePassword, newPassword, timeout); }

        public static WebPage
            LogIn(
                this WebPage mnLogInPage,
                string userName,
                string password,
                bool changePassword = false,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) {
            mnLogInPage
                .GetForm(mn.LoginPane)
                .EnterTextBoxValue(control: mn.PlaceholderTextBox, caption: "User Name", value: userName, timeout: timeout)
                .EnterTextBoxValue(control: mn.PlaceholderTextBox, caption: "Password", value: password, timeout: timeout)
                .Click(_.Button, "Log In", timeout)
                ;
            if (changePassword) {
                ChangePassword(mnLogInPage, password, newPassword, timeout);
            }
            var loadedPage = mnLogInPage.Site().WaitPageLoaded(mn.MainPage, timeout: timeout);
            return loadedPage;
        }

        private static void
            ChangePassword(
                WebPage mnLogInPage,
                string oldPassword,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) {
            if (newPassword == null) {
                newPassword = env.Password.Format(oldPassword);
            }
            mnLogInPage.
                WaitLoad(timeout: timeout).
                GetForm(mn.LoginChangePasswordPane).
                CheckDisplayed(_.Label, "Your Password Expired", timeout: timeout).
                EnterTextBoxValue(control: mn.PlaceholderTextBox, caption: "Password", value: oldPassword, timeout: timeout).
                EnterTextBoxValue(control: mn.PlaceholderTextBox, caption: "New Password", value: newPassword, timeout: timeout).
                EnterTextBoxValue(control: mn.PlaceholderTextBox, caption: "Confirm New Password", value: newPassword, timeout: timeout).
                Click(_.Button, "OK", timeout);
        }

        #endregion Log In

        #region Log Out

        public static WebPage
            LogOut(
                this WebPage mnMainPage,
                string logOutPageControl = mn.LoginPage,
                ulong timeout = ulong.MinValue
            ) {
            return
                mnMainPage
                    .DisposeByClick(_.Button, "Logout", timeout)
                    .WaitPageLoaded(control: logOutPageControl, timeout: timeout);
        }

        public static WebPage
            LogOut(
                this WebSite mtWebSite,
                string logOutPageControl = mn.LoginPage,
                ulong timeout = ulong.MinValue
            ) { return mtWebSite.Page().LogOut(logOutPageControl, timeout); }

        #endregion Log Out

        #region Get Frame

        /// <summary>
        /// Returns <see cref="MainContentIframe"/> on MetraNet main page.
        /// </summary>
        public static WebForm
            GetFrame(
                this WebPage mnMainPage,
                object caption,
                bool waitLoad = true,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) { return GetFrame(mnMainPage, caption, (new object[0]), waitLoad, force, timeout); }

        /// <summary>
        /// Returns <see cref="MainContentIframe"/>\<param name="framePath"/> on MetraNet main page.
        /// </summary>
// ReSharper disable CoVariantArrayConversion
        public static WebForm
            GetFrame(
                this WebPage mnMainPage,
                object caption,
                object[] framePath,
                bool waitLoad = true,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) { return GetFrame(mnMainPage, caption, (new[] {MainContentIframe}), framePath, waitLoad, force, timeout); }
// ReSharper restore CoVariantArrayConversion


        /// <summary>
        /// Returns <see cref="MainContentIframe"/>\<see cref="ticketFrame"/> on MetraNet main page.
        /// </summary>
        public static WebForm
            GetFrame_1(
                this WebPage mnMainPage,
                object caption,
                bool waitLoad = true,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) { return GetFrame_1(mnMainPage, caption, (new object[0]), waitLoad, force, timeout); }

        /// <summary>
        /// Returns frame <see cref="MainContentIframe"/>\<see cref="ticketFrame"/>\<param name="framePath"/> on MetraNet main page.
        /// </summary>
// ReSharper disable CoVariantArrayConversion
        public static WebForm
            GetFrame_1(
                this WebPage mnMainPage,
                object caption,
                object[] framePath,
                bool waitLoad = true,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) { return GetFrame(mnMainPage, caption, (new[] {MainContentIframe, TicketFrame}), framePath, waitLoad, force, timeout); }
// ReSharper restore CoVariantArrayConversion


        private static WebForm
            GetFrame(
                WebPage mnMainPage,
                object caption,
                object[] framePathPrefix,
                object[] framePath,
                bool waitLoad,
                bool force,
                ulong timeout
            ) {
            framePath = framePath.Copy();
            ArrayExt.Insert(ref framePath, 0, framePathPrefix);
            if (caption == null) {
                caption = framePath;
            }
            var frame = mnMainPage.GetForm(_.Frame, caption, framePath, waitLoad, force, timeout);
            return frame;
        }

        #endregion Get Frame

        #region Navigate AccountSidebar

        /// <summary>
        /// Navigates [<see cref="mn.Sidebar"/>, 'east'].
        /// Clicks [<see cref="mn.Tab"/>, '<paramref name="tab"/>'].
        /// Returns [<see cref="mn.Sidebar"/>, 'east'] or frame placed on the specified tab.
        /// </summary>
        public static WebForm
            NavigateAccountSidebar(
                this WebPage mnMainPage,
                string tab,
                ulong timeout = ulong.MinValue
            ) {
            var accountSidebar = mnMainPage.ExpandForm(mn.Sidebar, "east", timeout: timeout);
            accountSidebar.ClickWithReload(mn.Tab, tab, timeout: timeout);
            var accountSidebarTabFrame = accountSidebar.GetAccountSidebarTabFrame(tab, timeout);
            return accountSidebarTabFrame;
        }

        /// <summary>
        /// Returns [<see cref="mn.Sidebar"/>, 'east'] or frame placed on the specified tab.
        /// </summary>
        public static WebForm
            GetAccountSidebarTabFrame(
                this WebForm accountSidebar,
                string tab,
                ulong timeout = ulong.MinValue
            ) {
            switch (tab) {
                case "Finder": {
                    return accountSidebar.GetForm(_.Frame, tab, AccountSelector, timeout: timeout);
                }
                default: return accountSidebar;
            }
        }

        #endregion Navigate AccountSidebar

        #region Navigate MetraSidebar

        /// <summary>
        /// Navigates [<see cref="mn.Sidebar"/>, 'west']\[<see cref="mt.Menu"/>, '<paramref name="metraMenu"/>']\[<see cref="mt.Menu"/>, '<paramref name="menu"/>'].
        /// Clicks [<see cref="mt.MenuItem"/>, '<paramref name="menuItem"/>'].
        /// Returns <paramref name="mnMainPage"/>.
        /// </summary>
        public static WebPage
            NavigateMetraSidebar(
                this WebPage mnMainPage,
                string metraMenu,
                string menu,
                string menuItem,
                ulong timeout = ulong.MinValue
            ) {
            var westSidebar = mnMainPage.ExpandForm(mn.Sidebar, "west", timeout: timeout);
            westSidebar
                .ExpandForm(mt.Menu, metraMenu, timeout: timeout)
                .ExpandForm(mt.Menu, menu, timeout: timeout)
                .Click(mt.MenuItem, menuItem, timeout)
                ;
            return mnMainPage;
        }
        

        /// <summary>
        /// Navigates <see cref="NavigateMetraSidebar"/>.
        /// Returns frame by <see cref="GetFrame(WebPage,object,bool,bool,ulong)"/> with caption (<paramref name="caption"/>??<paramref name="menuItem"/>).
        /// </summary>
        public static WebForm
            NavigateMetraSidebarToFrame(
                this WebPage mnMainPage,
                string metraMenu,
                string menu,
                string menuItem,
                string caption = null,
                ulong timeout = ulong.MinValue
            ) {
            if (caption == null) {
                caption = menuItem;
            }
            var frame = mnMainPage
                .NavigateMetraSidebar(metraMenu, menu, menuItem, timeout)
                .GetFrame(caption: caption, timeout: timeout)
                ;
            return frame;
        }

        /// <summary>
        /// Navigates <see cref="NavigateMetraSidebar"/>.
        /// Returns frame by <see cref="GetFrame_1(WebPage,object,bool,bool,ulong)"/> with caption (<paramref name="caption"/>??<paramref name="menuItem"/>).
        /// </summary>
        public static WebForm
            NavigateMetraSidebarToFrame_1(
                this WebPage mnMainPage,
                string metraMenu,
                string menu,
                string menuItem,
                string caption = null,
                ulong timeout = ulong.MinValue
            ) { 
            if (caption == null) {
                caption = menuItem;
            }
            var frame = mnMainPage
                .NavigateMetraSidebar(metraMenu, menu, menuItem, timeout)
                .GetFrame_1(caption: caption, timeout: timeout)
                ;
            return frame;
        }

        #endregion Navigate MetraSidebar

        #region Load Frame

        /// <summary>
        /// Loads account via [<see cref="mn.MainPage"/>]\[<see cref="mn.QuickSearch_FindBox"/>] control.
        /// Returns frame by <see cref="GetFrame(WebPage,object,bool,bool,ulong)"/> with caption (<paramref name="caption"/>??"Account Summary").
        /// </summary>
        public static WebForm
            LoadAccountSummaryFrame(
                this WebPage mnMainPage,
                string enterValue,
                string dropdownValue = null,
                string caption = null,
                ulong timeout = ulong.MinValue
            ) {
            if (caption == null) {
                caption = "Account 360";
            }
            var accountSummaryFrame =
                mnMainPage.
                    EnterFindBoxValue(
                        control: mn.QuickSearch_FindBox,
                        enterValue: enterValue,
                        dropdownValue: dropdownValue,
                        timeout: timeout
                    ).Page().GetFrame(
                        caption,
                        timeout: timeout
                    );
            return accountSummaryFrame;
        }

        /// <summary>
        /// Loads "Advanced Find" frame by clicking [<see cref="mn.MainPage"/>]\[<see cref="_.Button"/>, 'Advanced Find'].
        /// Returns frame by <see cref="GetFrame(WebPage,object,bool,bool,ulong)"/> with caption (<paramref name="caption"/>??"Advanced Find").
        /// </summary>
        public static WebForm
            LoadAdvancedFindFrame(
                this WebPage mnMainPage,
                string caption = null,
                ulong timeout = ulong.MinValue
            ) {
            if (caption == null) {
                caption = "Advanced Find";
            }
            var advancedFindFrame =
                mnMainPage.
                    Click(
                        _.Button, "Advanced Find",
                        timeout
                    ).Page().GetFrame(
                        caption,
                        timeout: timeout
                    );
            return advancedFindFrame;
        }

        #endregion Load Frame
    }
}
