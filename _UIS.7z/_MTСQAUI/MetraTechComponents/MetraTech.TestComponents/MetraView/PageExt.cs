﻿using System.Collections.Generic;
using MetraTech.DomainModel.BaseTypes;
using UtilityComponents;
using WebComponents;
using WebComponents.WebForms;
using MetraTech.WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mv = MetraTech.WebComponents.WebControls.MetraView;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraTech.TestComponents.MetraView
{
    public static class PageExt
    {
        #region TabPageControls

        private static readonly Dictionary<string, string>
            TabPageControls = (new Dictionary<string, string> {
                {"Home", mv.HomePage},
                {"Bill & Payments", mv.BillPaymentsPage},
                {"My Reports", mv.ReportsPage},
                {"Account Info", mv.AccountInfoPage},
                {"My Subscriptions", mv.SubscriptionsPage},
                {"Admin", mv.AdminPage},
                {"My Activity", mv.ActivityPage},
            });

        private static readonly Dictionary<string[], Dictionary<string, string>>
            NestedTabPageControls = (new Dictionary<string[], Dictionary<string, string>> {
                {(new [] {
                    mv.BillPaymentsPage,
                    mv.BillingHistoryPage,
                    mv.PaymentMethodsPage,
                    mv.PaymentHistoryPage,
                    mv.DownloadInvoicePage
                    }), (new Dictionary<string, string> {
                    {"View Bill", mv.BillPaymentsPage},
                    {"Billing History", mv.BillingHistoryPage},
                    {"Payment Methods", mv.PaymentMethodsPage},
                    {"Payment History", mv.PaymentHistoryPage},
                    {"Downloads", mv.DownloadInvoicePage},
                })},
                {(new [] {
                    mv.AccountInfoPage,
                    mv.ChangePasswordPage,
                    mv.RegionalSettingsPage,
                    mv.InvoiceMethodPage,
                    mv.AccountSecurityPage
                    }), (new Dictionary<string, string> {
                    {"Change Password", mv.ChangePasswordPage},
                    {"Regional Settings", mv.RegionalSettingsPage},
                    {"Invoice Method", mv.InvoiceMethodPage},
                    {"Account Security", mv.AccountSecurityPage},
                })},
                {(new [] {
                    mv.AdminPage,
                    mv.ConfigureSitePage
                    }), (new Dictionary<string, string> {
                    {"Configure Site", mv.ConfigureSitePage},
                })},
            });

        #endregion TabPageControls
        
        #region Log In

        public static WebPage
            LogInAsAdmin(
                this WebSite mtWebSite,
                bool changePassword = false,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) { return LogIn(mtWebSite, env.MetraViewAdmin, changePassword, newPassword, timeout); }

        public static WebPage
            LogIn(
                this WebSite mtWebSite,
                Account account,
                bool changePassword = false,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) { return LogIn(mtWebSite, account.UserName, account.Password_, changePassword, newPassword, timeout); }

        public static WebPage
            LogIn(
                this WebSite mtWebSite,
                string userName,
                string password,
                bool changePassword = false,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) {
            var isLoginPageLoaded = mtWebSite.IsPageLoaded(mv.LoginPage, force: true, timeout: 2648UL);
            var loginPage = (isLoginPageLoaded ? mtWebSite.Page() : mtWebSite.LoadPage(mv.LoginPage, timeout: timeout));
            return loginPage.LogIn(userName, password, changePassword, newPassword, timeout);
        }


        public static WebPage
            LogInAsAdmin(
                this WebPage mvLogInPage,
                bool changePassword = false,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) { return LogIn(mvLogInPage, env.MetraViewAdmin, changePassword, newPassword, timeout); }

        public static WebPage
            LogIn(
                this WebPage mvLogInPage,
                Account account,
                bool changePassword = false,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) { return LogIn(mvLogInPage, account.UserName, account.Password_, changePassword, newPassword, timeout); }

        public static WebPage
            LogIn(
                this WebPage mvLogInPage,
                string userName,
                string password,
                bool changePassword = false,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) {
            mvLogInPage
                .EnterTextBoxValue(caption: "User Name", value: userName, timeout: timeout)
                .EnterTextBoxValue(caption: "Password", value: password, timeout: timeout)
                .Click(_.Button, "Login", timeout)
                ;
            if (changePassword) {
                ChangePassword(mvLogInPage, password, newPassword, timeout);
            }
            var loadedPage = mvLogInPage.Site().WaitPageLoaded(mv.HomePage, timeout: timeout);
            return loadedPage;
        }

        private static void
            ChangePassword(
                WebPage mvLogInPage,
                string oldPassword,
                string newPassword = null,
                ulong timeout = ulong.MinValue
            ) {
            if (newPassword == null) {
                newPassword = env.Password.Format(oldPassword);
            }
            mvLogInPage.
                WaitLoad(timeout: timeout).
                CheckDisplayed(_.Label, "Your Password Expired", timeout: timeout).
                EnterTextBoxValue(caption: "Old Password", value: oldPassword, timeout: timeout).
                EnterTextBoxValue(caption: "New Password", value: newPassword, timeout: timeout).
                EnterTextBoxValue(caption: "Confirm Password", value: newPassword, timeout: timeout).
                Click(_.Button, "OK", timeout);
        }

        #endregion Log In

        #region Log Out

        public static WebPage
            LogOut(
                this WebPage mvPage,
                string loadPageControl = mv.LoginPage,
                ulong timeout = ulong.MinValue
            ) {
            return
                mvPage.
                    DisposeByClick(mv.Tab, "Logout", timeout).
                    WaitPageLoaded(control: loadPageControl, timeout: timeout);
        }

        public static WebPage
            LogOut(
                this WebSite mtWebSite,
                string loadPageControl = mv.LoginPage,
                ulong timeout = ulong.MinValue
            ) { return mtWebSite.Page().LogOut(loadPageControl, timeout); }

        #endregion Log Out

        #region Navigate MetraView

        /// <summary>
        /// Clicks [<see cref="mv.Tab"/>, '<paramref name="tab"/>'].
        /// If <paramref name="nestedTab"/> specified clicks [<see cref="mv.Tab"/>, '<paramref name="nestedTab"/>'].
        /// Returns loaded page.
        /// </summary>
        public static WebPage
            NavigateMetraView(
                this WebPage mvPage,
                string tab,
                string nestedTab = null,
                ulong timeout = ulong.MinValue
            ) {
            var loadPageControl = TabPageControls[tab];
            var loadPage = mvPage.Click(mv.Tab, tab).Site().WaitPageLoaded(loadPageControl);
            if (nestedTab != null) {
                loadPageControl = NestedTabPageControls.Get(loadPageControl)[nestedTab];
                loadPage = loadPage.Click(mv.Tab, nestedTab).Site().WaitPageLoaded(loadPageControl);
            }
            return loadPage;
        }

        /// <summary>
        /// Clicks [<see cref="mv.Tab"/>, '<paramref name="nestedTab"/>'].
        /// Returns loaded page.
        /// </summary>
        public static WebPage
            NavigateMetraView(
                this WebPage mvPage,
                string nestedTab,
                ulong timeout = ulong.MinValue
            ) {
            var loadPageControl = NestedTabPageControls.Get(mvPage.Control)[nestedTab];
            var loadPage = mvPage.Click(mv.Tab, nestedTab).Site().WaitPageLoaded(loadPageControl);
            return loadPage;
        }

        #endregion Navigate MetraView
    }
}
