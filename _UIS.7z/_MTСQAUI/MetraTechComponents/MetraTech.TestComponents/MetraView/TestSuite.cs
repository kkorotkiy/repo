﻿using System;
using WebComponents;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mv = MetraTech.WebComponents.WebControls.MetraView;
using env = MetraTech.TestSystem.Interaction.EnvironmentConfiguration;


namespace MetraTech.TestComponents.MetraView
{
    public abstract class MetraViewTestSuite : MetraTechTestSuite
    {
        protected override string GetWebSiteLoadUrl() { return env.MetraViewWebSiteUrl; }

        protected override bool _TryLogOut()
        {
            try {
                WebSite.LogOut();
                return true;
            } catch (Exception exception) {
                LogUnhandledException(exception);
            }
            try {
                WebBrowser.SwitchToMainWindow(2560UL);
                if (WebSite.IsPageLoaded(mv.LoginPage, force: true, timeout:2560UL)) {
                    return true;
                }
                var mainPage = WebSite.Page();
                var logoutButtonDisplayed = mainPage.WaitDisplayed(mv.Tab, "Logout", throwTimedOut:false, timeout:2560UL);
                if (!logoutButtonDisplayed) {
                    mainPage.Reload(force: true, timeout: 5120UL);
                }
                mainPage.Click(mv.Tab, "Logout", timeout: 2560UL);
                mainPage.WaitDispose();
                WebSite.WaitPageLoaded(mv.LoginPage);
                return true;
            } catch (Exception exception) {
                LogUnhandledException(exception);
                return false;
            }
        }
    }
}
