﻿using UtilityComponents;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using mt = MetraTech.WebComponents.WebControls.MetraTech;
using mv = MetraTech.WebComponents.WebControls.MetraView;


namespace MetraTech.TestComponents.MetraView
{
    public static class TreeExt
    {
        #region Navigate

        public static WebForm
            NavigateTreeNode(
                this WebForm webForm,
                params string[] nodeNames
            ) {
            foreach (var nodeName in nodeNames) {
                webForm = webForm.ExpandForm(mv.TreeNode, nodeName);
            }
            return webForm;
        }

        public static WebForm
            NavigateTreeLeaf(
                this WebForm webForm,
                params string[] nodeNames
            ) {
            var leafIndex = (nodeNames.Length - 1);
            var leafName = nodeNames[leafIndex];
            ArrayExt.RemoveAt(ref nodeNames, leafIndex);
            return webForm.NavigateTreeNode(nodeNames).GetForm(mv.TreeLeaf, leafName);
        }

        #endregion Navigate

        #region Read Value

        public static TValue
            ReadTreeNodeValue<
                TValue>(
                this WebForm webForm,
                params string[] nodeNames
            ) { return webForm.NavigateTreeNode(nodeNames).ReadElementValue<TValue>(mv.TreeNodeValue); }

        public static TValue
            ReadTreeLeafValue<
                TValue>(
                this WebForm webForm,
                params string[] nodeNames
            ) { return webForm.NavigateTreeLeaf(nodeNames).ReadElementValue<TValue>(mv.TreeLeafValue); }

        #endregion Read Value

        #region Validate Value

        public static WebForm
            ValidateTreeNodeValue<
                TValue>(
                this WebForm webForm,
                TValue expectedValue,
                params string[] nodeNames
            ) { return webForm.NavigateTreeNode(nodeNames).ValidateElementValue(expectedValue, mv.TreeNodeValue); }

        public static WebForm
            ValidateTreeLeafValue<
                TValue>(
                this WebForm webForm,
                TValue expectedValue,
                params string[] nodeNames
            ) { return webForm.NavigateTreeLeaf(nodeNames).ValidateElementValue(expectedValue, mv.TreeLeafValue); }

        #endregion Validate Value
    }
}
