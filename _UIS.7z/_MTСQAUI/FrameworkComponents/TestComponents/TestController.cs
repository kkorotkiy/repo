﻿using System;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using LogComponents;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UtilityComponents;


namespace TestComponents
{
    public struct GridCellInfo
    {
        public const string Format = ("[columnIndex:'{0}', columnName:'{1}', cellValue:'{2}']");

        public readonly int ColumnIndex;
        public readonly string ColumnName;
        public readonly object Value;

        public GridCellInfo(string columnName, object value = null) : this(-1, columnName, value) {}
        public GridCellInfo(int columnIndex, object value = null) : this(columnIndex, null, value) {}

        public GridCellInfo(int columnIndex, string columnName, object value = null) {
            ColumnIndex = columnIndex;
            ColumnName = columnName;
            Value = value;
        }
        
        public override string ToString() { return string.Format(Format, ColumnIndex, ColumnName, Value); }
    }


    public abstract class TestController
    {
        #region TestAssembly

        public const string TestAssemblyDescription = ("TestAssembly");

        public static Assembly DetermineTestAssembly(TestContext testContext)
        {
            var appDomain = AppDomain.CurrentDomain;
            var assemblies = appDomain.GetAssemblies();
            var testAssembly = assemblies.Where(IsTestAssembly).Single();
            return testAssembly;
        }

        public static bool IsTestAssembly(Assembly assembly)
        {
            var assemblyDescrAttrType = typeof(AssemblyDescriptionAttribute);
            var assemblyDescrAttrs = assembly.GetCustomAttributes(assemblyDescrAttrType, inherit: false);
            foreach (var obj in assemblyDescrAttrs) {
                var descrAttr = (obj as AssemblyDescriptionAttribute);
                if ((descrAttr != null) && (descrAttr.Description == TestAssemblyDescription)) {
                    return true;
                }
            }
            return false;
        }

        public static MethodInfo GetTestAssemblyInitializeMethod(Assembly testAssembly)
        {
            var types = testAssembly.GetTypes();
            var testClasses = types.Where(type => type.GetCustomAttributes<TestClassAttribute>().Any());
            foreach (var testClass in testClasses) {
                var testClassMethods = testClass.GetMethods(BindingFlags.Static|BindingFlags.Public|BindingFlags.Instance);
                var testAssemblyInitializeMethod =
                    testClassMethods
                        .SingleOrDefault(
                            m => TypeExt.GetCustomAttributes<AssemblyInitializeAttribute>(m).Any()
                        );
                if (testAssemblyInitializeMethod != default(MethodInfo)) {
                    return testAssemblyInitializeMethod;
                }
            }
            return default(MethodInfo);
        }

        #endregion TestAssembly

        #region TestSession

        public static string TestSessionName { get; private set; }
        protected static Assembly TestAssembly { get; private set; }
        protected static MethodInfo TestAssemblyInitializeMethod { get; private set; }

        protected static void InitializeTestSession(TestContext testContext)
        {
            TestAssembly = DetermineTestAssembly(testContext);
            TestAssemblyInitializeMethod = GetTestAssemblyInitializeMethod(TestAssembly);
            TestSessionName = TestAssembly.GetName().Name;
            DeployItems(testContext);
            CreateScreenshotsDirectory(testContext);
        }

        private static void DeployItems(TestContext testContext)
        {
            if (TestAssemblyInitializeMethod == null) {
                return;
            }
            var deploymentItems =
                TypeExt.GetCustomAttributes<
                    DeploymentItemAttribute>(
                    TestAssemblyInitializeMethod
                    ,inherit: false
                    );
            foreach (var deploymentItem in deploymentItems) {
                if (!DeployFile(testContext, deploymentItem)) {
                    DeployDirectory(testContext, deploymentItem);
                }
            }
        }

        #endregion TestSession

        #region Take Screenshot

        protected const string TestScreenshotsDirectoryName = ("TestScreenshots");
        protected static string TestScreenshotsDirectoryPath { get; private set; }
        protected static int ScreenshotsCount { get; private set; }

        private static void CreateScreenshotsDirectory(TestContext testContext)
        {
            TestScreenshotsDirectoryPath = Path.Combine(
                testContext.TestRunDirectory,
                TestScreenshotsDirectoryName
                );
            Directory.CreateDirectory(TestScreenshotsDirectoryPath).Refresh();
            ScreenshotsCount = -1;

            var logScreenshotsDirectoryPath = Path.Combine(
                testContext.TestRunDirectory,
                ScreenshotManager.DefaultDirectoryName
                );
            ScreenshotManager.DirectoryPath = logScreenshotsDirectoryPath;
        }

        protected static string TakeScreenshot(string namePrefix, string name)
        {
            var filePath = (++ScreenshotsCount).ToString(ScreenshotManager.FileNameFormat);
            filePath = PathExt.AddExtension(filePath, namePrefix);
            filePath = PathExt.AddExtension(filePath, name);
            filePath = PathExt.AddExtension(filePath, ScreenshotManager.FileExtension);
            filePath = Path.Combine(TestScreenshotsDirectoryPath, filePath);
            ScreenshotManager.TakeScreenshotToFile(filePath);
            return filePath;
        }

        protected virtual string TakeScreenshot(string name = null) { return TakeScreenshot(QualifiedTestName, name); }

        #endregion Take Screenshot

        #region TestContext

        // ReSharper disable InconsistentNaming
        public const string UITestCategory = ("UITest");
        // ReSharper restore InconsistentNaming
        
        public TestContext TestContext { get; set; }
        protected virtual string QualifiedTestName { get { return FormatQualifiedTestName(TestContext); } }

        public static string FormatQualifiedTestSuiteName(TestContext testContext, bool full = false)
        {
            var testSuiteName = testContext.FullyQualifiedTestClassName;
            if (!full) {
                testSuiteName = testSuiteName.Split('.').Last();
            }
            return testSuiteName;
        }

        public static string FormatQualifiedTestName(TestContext testContext, bool full = false)
        {
            var testSuiteName = FormatQualifiedTestSuiteName(testContext, full);
            var testName = (testSuiteName+'.'+testContext.TestName);
            return testName;
        }

        #endregion TestContext

        #region Deploy Items

        public static bool
            DeployFile(
                TestContext testContext,
                DeploymentItemAttribute deploymentItem
            ) {
            var filePath = Environment.ExpandEnvironmentVariables(deploymentItem.Path);
            if (!File.Exists(filePath)) {
                return false;
            }
            var fileName = Path.GetFileName(filePath);
            if (string.IsNullOrWhiteSpace(fileName)) {
                return false;
            }
            var outputDirectoryPath = GetOutputDirectoryPath(testContext, deploymentItem);
            var destinationFileName = Path.Combine(outputDirectoryPath, fileName);
            File.Copy(filePath, destinationFileName, overwrite: true);
            return true;
        }

        public static bool
            DeployDirectory(
                TestContext testContext,
                DeploymentItemAttribute deploymentItem
            ) {
            var directoryPath = Environment.ExpandEnvironmentVariables(deploymentItem.Path);
            if (!Directory.Exists(directoryPath)) {
                return false;
            }
            var directoryName = Path.GetDirectoryName(directoryPath);
            if (string.IsNullOrWhiteSpace(directoryName)) {
                return false;
            }
            var outputDirectoryPath = GetOutputDirectoryPath(testContext, deploymentItem);
            var directory = (new DirectoryInfo(directoryPath));
            CopyFiles(directory, outputDirectoryPath);
            return false;
        }

        private static void
            CopyFiles(
                DirectoryInfo directory,
                string outputDirectoryPath
            ) {
            var files = directory.GetFiles();
            foreach (var file in files) {
                var destinationFileName = Path.Combine(outputDirectoryPath, file.Name);
                file.CopyTo(destinationFileName, overwrite: true);
            }
            var subDirectories = directory.GetDirectories();
            foreach (var subDirectory in subDirectories) {
                var outputSubDirectoryPath = Path.Combine(outputDirectoryPath, subDirectory.Name);
                if (!Directory.Exists(outputSubDirectoryPath)) {
                    Directory.CreateDirectory(outputSubDirectoryPath).Refresh();
                }
                CopyFiles(subDirectory, outputSubDirectoryPath);
            }
        }

        private static string
            GetOutputDirectoryPath(
                TestContext testContext,
                DeploymentItemAttribute deploymentItem
            ) {
            var outputDirectoryPath = deploymentItem.OutputDirectory;
            if (!Directory.Exists(outputDirectoryPath)) {
                if (!Path.IsPathRooted(outputDirectoryPath)) {
                    outputDirectoryPath = Path.Combine(testContext.DeploymentDirectory, outputDirectoryPath);
                }
                Directory.CreateDirectory(outputDirectoryPath).Refresh();
            }
            return outputDirectoryPath;
        }

        #endregion Deploy Items

        #region Initializers

        protected static TItem[] @Array<TItem>(params TItem[] items) { return items; }
        protected static object[] @Array(params object[] items) { return items; }


        protected static GridCellInfo
            @Cell(string columnName, object value = null) { return (new GridCellInfo(columnName, value)); }

        protected static GridCellInfo
            @Cell(int columnIndex, object value = null) { return (new GridCellInfo(columnIndex, value)); }

        #endregion Initializers

        #region Localization

        protected abstract CultureInfo Culture { get; }

        #region DateTime

        protected virtual string
            @Today(
                int addDays = 0,
                int addMonths = 0,
                int addYears = 0
            ) { return FormatDate(DateTime.Now.AddMonths(addYears*12+addMonths).AddDays(addDays)); }

        protected virtual string
            @TodayUtc(
                int addDays = 0,
                int addMonths = 0,
                int addYears = 0
            ) { return FormatDate(DateTime.UtcNow.AddMonths(addYears*12+addMonths).AddDays(addDays)); }

        protected virtual string
            @FormatDate(
                DateTime dateTime
            ) {
            var formatProvider = Culture.DateTimeFormat;
            var formatPattern = formatProvider.ShortDatePattern;
            var dateFormat = dateTime.ToString(formatPattern, formatProvider);
            return dateFormat;
        }

        protected virtual string
            @FormatDateTime(
                DateTime dateTime,
                string formatPattern = null
            ) {
            var formatProvider = Culture.DateTimeFormat;
            string dateTimeFormat;
            if (formatPattern == null) {
                dateTimeFormat = dateTime.ToString(formatProvider);
            } else {
                dateTimeFormat = dateTime.ToString(formatPattern, formatProvider);
            }
            return dateTimeFormat;
        }

        protected virtual string
            @FormatDateTime(
                DateTime? dateTime,
                string formatPattern = null,
                string message = null,
                params object[] parameters
            ) {
            if (message == null) {
                message = ("Cannot format Nullable<DateTime> with no value set.");
            }
            Assert.IsTrue(dateTime.HasValue, message, parameters);
            return @FormatDateTime(dateTime.Value, formatPattern);
        }

        #endregion DateTime

        #region Number

        protected virtual string
            @Number(decimal number) { return number.ToString("N", Culture.NumberFormat); }

        protected virtual string
            @Currency(decimal number) { return number.ToString("C", Culture.NumberFormat); }

        protected virtual string
            @Percentage(decimal number) { return number.ToString("P", Culture.NumberFormat); }

        #endregion Number

        #endregion Localization        

        #region Exception Handlers

        public const string TestUnhandledException =
            ("TEST_UNHANDLED_EXCEPTION has been caught while executing test '{0}'.");

        public void
            LogUnhandledException(
                Exception exception,
                string message = null,
                params object[] args
            ) {
            if (message != null) {
                message = (Environment.NewLine + string.Format(message, args));
            }
            message = (string.Format(TestUnhandledException, QualifiedTestName)+message);
            LogManager.LogRecord(message, exception, LogRecordType.ERROR, takeScreenshot: true);
        }

        #endregion Exception Handlers
    }
}