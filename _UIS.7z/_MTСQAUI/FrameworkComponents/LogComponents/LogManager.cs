﻿using System;
using System.Diagnostics;
using UtilityComponents;
using appConfig = System.Configuration.ConfigurationManager;


namespace LogComponents
{
    public static class LogLevel
    {
        public const byte Default = Byte.MinValue;
        public const byte Debug = Byte.MaxValue;
    }

    public enum LogRecordType : byte {
        FATAL,
        ERROR,
        WARNING,
        INFO,
    }


    internal sealed class LogRecord
    {
        #region Properties and Fields

        public DateTime DateTime { get; set; }
        public StackFrame TargetSite { get; set; }
        public LogRecordType RecordType { get; set; }
        public bool HasScreenshot { get; set; }
        public string ScreenshotFilePath { get; set; }
        public string Message { get; set; }
        public Exception Exception { get; set; }

        #endregion Properties and Fields

        #region ToString

        private const string TimeFormat = ("hh:mm:ss.fff");
        private const string TargetSiteFormat = ("[{0}][{1}][{2}]");
        private const string Format = ("[{0}][{1}]{2}[{3}] {4}");
        private const string FormatWithScreenshot = ("[{0}][{1}]{2}[{3}][{4}] {5}");
        private static readonly string ExceptionFormat = (Environment.NewLine+"[Exception] {0}");

        public override string ToString() { return ToString(LogLevel.Default); }

        public string ToString(byte level)
        {            
            var date = DateTime.ToShortDateString();
            var time = DateTime.ToString(TimeFormat);
            var targetSite = string.Empty;
            if (level >= LogLevel.Debug) {
                targetSite = FormatTargetSite();
            }
            string record;
            if (HasScreenshot) {
                var screenshotNumber = ScreenshotManager.GetScreenshotNumber(ScreenshotFilePath);
                record = string.Format(FormatWithScreenshot, date, time, targetSite, RecordType, screenshotNumber, Message);
            } else {
                record = string.Format(Format, date, time, targetSite, RecordType, Message);
            }
            if (Exception != null) {
                record += string.Format(ExceptionFormat, Exception);
            }
            record += Environment.NewLine;
            return record;
        }

        private string FormatTargetSite()
        {
            var targetSiteMethod = TargetSite.GetMethod();
            var targetSiteType = (targetSiteMethod.DeclaringType ?? targetSiteMethod.ReflectedType);
            var targetSiteTypeName = targetSiteType.FullName;
            var targetSite = string.Format(
                TargetSiteFormat,
                targetSiteMethod.Module.Name,
                targetSiteTypeName,
                targetSiteMethod.Name
                );
            return targetSite;
        }        

        #endregion ToString
    }


    public sealed class LogManager
    {
        #region Properties and Fields

        public static byte LogLevel { get; set; }    

        static LogManager() {
            LogLevel = Cast.As<byte>(appConfig.AppSettings["LogLevel"]);
        }

        #endregion Properties and Fields

        #region LogRecord

        public static void LogInfo(string message, params object[] args) {
            LogRecord(string.Format(message, args), recordType:LogRecordType.INFO, skipFrames:2);
        }

        public static void LogWarning(string message, params object[] args) {
            LogRecord(string.Format(message, args), recordType:LogRecordType.WARNING, skipFrames:2);
        }

        public static void LogError(string message, params object[] args) {
            LogRecord(string.Format(message, args), recordType:LogRecordType.ERROR, skipFrames: 2);
        }

        public static void
            LogException(
                Exception exception,
                LogRecordType recordType = LogRecordType.INFO,
                bool takeScreenshot = false,
                byte level = LogComponents.LogLevel.Default
            ) { LogRecord(null, exception, recordType, takeScreenshot, level, skipFrames: 2); }

        public static void
            LogRecord(
                string message,
                Exception exception = null,
                LogRecordType recordType = LogRecordType.INFO,
                bool takeScreenshot = false,
                byte level = LogComponents.LogLevel.Default,
                int skipFrames = 1
            ) {
            var isFatal = (recordType == LogRecordType.FATAL);
            if ((LogLevel < level) && !isFatal) {
                return;
            }
            var screenshotFilePath = default(string);
            takeScreenshot = (takeScreenshot || isFatal);
            if (takeScreenshot) {
                screenshotFilePath = ScreenshotManager.TakeScreenshot();
            }
            var targetSite = (new StackFrame(skipFrames, fNeedFileInfo:true));
            var logRecord =
                (new LogRecord {
                    DateTime = DateTime.Now,
                    TargetSite = targetSite,
                    RecordType = recordType,
                    HasScreenshot = takeScreenshot,
                    ScreenshotFilePath = screenshotFilePath,
                    Message = message,
                    Exception = exception,
                });
            var record = logRecord.ToString(level);
            Console.Write(record);
        }

        #endregion LogRecord        
    }
}
