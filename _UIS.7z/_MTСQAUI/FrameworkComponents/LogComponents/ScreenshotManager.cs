﻿using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;


namespace LogComponents
{
    public static class ScreenshotManager
    {
        #region Properties and Fields

        public const string DefaultDirectoryName = ("LogScreenshots");
        public const string FileNameFormat = ("D4");
        public const string DefaultFileExtension = (".bmp");
        
        public static string DirectoryPath {
            get {
                if (string.IsNullOrWhiteSpace(_directoryPath)) {
                    _directoryPath = DefaultDirectoryName;
                    _directoryPath = Path.GetFullPath(_directoryPath);
                }
                return _directoryPath;
            }
            set {
                if (value != null) {
                    value = Environment.ExpandEnvironmentVariables(value);
                    value = Path.GetFullPath(value);
                }
                if (_directoryPath != value) {
                    _directoryPath = value;
                    _count = -1;
                }
            }
        }
        private static string _directoryPath;

        public static string FileExtension {
            get { return _fileExtension; }
            set {
                if (_fileExtension != value) {
                    _fileExtension = value;
                    _count = -1;
                }
            }
        }
        private static string _fileExtension;

        static ScreenshotManager() {
            FileExtension = DefaultFileExtension;
        }

        #endregion Properties and Fields

        #region Screenshot File

        public static int Count {
            get {
                if (_count > -1) {
                    return _count;
                }
                if (!Directory.Exists(DirectoryPath)) {
                    _count = -1;
                } else {
                    var files = GetFiles();
                    _count = ((files.Length != 0) ? files.Max<string, int>(GetScreenshotNumber) : 0);
                }
                return _count;
            }
            private set { _count = value; }
        }
        private static int _count = -1;

        public static string GetNextFilePath()
        {
            var fileNumber = (Count + 1);
            var fileName = fileNumber.ToString(FileNameFormat);
            fileName = Path.ChangeExtension(fileName, FileExtension);
            var filePath = Path.Combine(DirectoryPath, fileName);
            return filePath;
        }

        public static string[] GetFiles()
        {
            var searchPattern = ("*" + FileExtension);
            var files = Directory.GetFiles(DirectoryPath, searchPattern, SearchOption.TopDirectoryOnly);
            files = files.Where(IsScreenshotFile).ToArray();
            return files;
        }

        public static bool IsScreenshotFile(string filePath)
        {
            var fileExtension = Path.GetExtension(filePath);
            var fileName = Path.GetFileNameWithoutExtension(filePath);
            var isScreenshot =
                ((fileExtension == FileExtension)
                 && (fileName != null)
                 && (fileName.Length == 4)
                 && fileName.All(char.IsDigit)
                );
            return isScreenshot;
        }

        public static int GetScreenshotNumber(string filePath)
        {
            var fileName = Path.GetFileNameWithoutExtension(filePath);
            int number;
            if (!int.TryParse(fileName, out number)) {
                number = -1;
            }
            return number;
        }

        #endregion Screenshot File

        #region Take Screenshot

        public static string TakeScreenshot()
        {
            if (!Directory.Exists(DirectoryPath)) {
                Directory.CreateDirectory(DirectoryPath).Refresh();
            }
            var filePath = GetNextFilePath();
            var taken = TakeScreenshotToFile(filePath);
            if (taken) { Count++; }
            else { filePath = null; }
            return filePath;
        }

        public static bool
            TakeScreenshotToFile(
                string filePath,
                bool expandEnvironmentVariables = false
            ) {
            if (expandEnvironmentVariables) {
                filePath = Environment.ExpandEnvironmentVariables(filePath);
            }
            bool taken;
            try {
                var bitmap = (new Bitmap(
                    Screen.PrimaryScreen.Bounds.Width,
                    Screen.PrimaryScreen.Bounds.Height
                    ));
                using (bitmap) {
                    var graphics = Graphics.FromImage(bitmap);
                    using (graphics) {
                        graphics.CopyFromScreen(
                            Screen.PrimaryScreen.Bounds.X,
                            Screen.PrimaryScreen.Bounds.Y,
                            0,
                            0,
                            bitmap.Size,
                            CopyPixelOperation.SourceCopy
                            );
                        bitmap.Save(filePath);
                        taken = true;
                    }
                }
            } catch (Exception exception) {
                Console.WriteLine(exception);
                taken = false;
            }
            return taken;
        }

        #endregion Take Screenshot
    }
}
