﻿using System;


namespace WebComponents.WebElements
{
    public class CheckBoxWebElement : WebElement
    {
        protected CheckBoxWebElement() { }


        protected override object ReadValue() { return Selected; }

        public override bool ClearValue() { WebBrowser.ScrollTo(Native); return true; }

        public override bool EnterValue<TValue>(TValue value)
        {
            if (ReferenceEquals(value, null)) {
                return false;
            }
            bool selected = Convert.ToBoolean(value);
            if (selected != Selected) {
                WebBrowser.ScrollTo(Native);
                Native.Click();
                return true;
            }
            return false;
        }        
    }
}
