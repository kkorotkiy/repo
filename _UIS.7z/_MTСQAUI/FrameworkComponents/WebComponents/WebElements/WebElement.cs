﻿using System;
using System.Drawing;
using LogComponents;
using OpenQA.Selenium;
using OpenQA.Selenium.Remote;
using UtilityComponents;


namespace WebComponents.WebElements
{
    public class WebElement
    {
        #region Properties and Fields

        protected internal virtual RemoteWebElement Native { get; private set; }

        public virtual string TagName { get { return Native.TagName; } }
        public virtual string Text { get { return Native.Text; } }

        public virtual bool Selected { get { return Native.Selected; } }
        public virtual bool Enabled { get { return Native.Enabled; } }
        public virtual bool? Displayed {
            get {
                try {
                    return Native.Displayed;
                } catch (Exception exception) {
                    LogManager.LogException(exception, level:LogLevel.Debug);
                    return null;
                }
            }
        }

        public virtual Size Size { get { return Native.Size; } }
        public virtual Point Location { get { return Native.Location; } }

        #endregion Properties and Fields

        #region Attributes

        public virtual string Id { get { return GetAttributeValue("id"); } }
        public virtual string Name { get { return GetAttributeValue("name"); } }
        public virtual string Class { get { return GetAttributeValue("class"); } }
        public virtual string Style { get { return GetAttributeValue("style"); } }

        public virtual string
            GetAttributeValue(string attributeName) { return Native.GetAttribute(attributeName); }

        #endregion Attributes

        #region Factory Methods

        protected WebElement() { }

        public static WebElement New(IWebElement native)
        {
            var webElement = (new WebElement());
            webElement.Initialize(native);
            return webElement;
        }

        public static WebElement New(Type type, IWebElement native)
        {
            var instance = Activator.CreateInstance(type, nonPublic: true);
            var webElement = ((WebElement) instance);
            webElement.Initialize(native);
            return webElement;
        }
        
        public static TWebElement
            New<TWebElement>(
                IWebElement native
            ) where TWebElement : WebElement {
            var type = typeof(TWebElement);
            var instance = Activator.CreateInstance(type, nonPublic: true);
            var webElement = ((TWebElement) instance);
            webElement.Initialize(native);
            return webElement;
        }

        private void Initialize(IWebElement native) { Native = (native as RemoteWebElement); }

        #endregion Factory Methods

        #region Actions

        public virtual bool Click() { WebBrowser.ScrollTo(Native); Native.Click(); return true; }

        #endregion Actions

        #region RCE Value

        protected virtual object ReadValue() { return Text; }

        public virtual TValue
            ReadValue<TValue>() { WebBrowser.ScrollTo(Native); return Cast.As<TValue>(ReadValue()); }

        public virtual bool
            ClearValue() { WebBrowser.ScrollTo(Native); Native.Clear(); return true; }

        protected virtual void SendKeys(string text) { Native.SendKeys(text); }

        public virtual bool EnterValue<TValue>(TValue value)
        {
            if (ReferenceEquals(value, null)) {
                return false;
            }
            var text = value.ToString();
            WebBrowser.ScrollTo(Native);
            SendKeys(text);
            return true;
        }        

        #endregion RCE Value
    }


    public sealed class WebElementMock : WebElement
    {
        protected internal override RemoteWebElement Native { get { return null; } }
        public override string TagName { get { return null; } }
        public override string Text { get { return null; } }
        public override bool Selected { get { return false; } }
        public override bool Enabled { get { return false; } }
        public override bool? Displayed { get { return false; } }
        public override Size Size { get { return Size.Empty; } }
        public override Point Location { get { return Point.Empty; } }
        public override string GetAttributeValue(string attributeName) { return null; }
        public override bool Click() { return false; }
        protected override object ReadValue() { return null; }
        public override bool ClearValue() { return false; }
        public override bool EnterValue<TValue>(TValue value) { return false; }
    }
}
