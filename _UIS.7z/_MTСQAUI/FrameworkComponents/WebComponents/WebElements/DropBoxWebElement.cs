﻿using OpenQA.Selenium.Support.UI;


namespace WebComponents.WebElements
{
    public class DropBoxWebElement : WebElement
    {
        #region Properties and Fields

        protected virtual SelectElement NativeSelect {
            get {
                if (_nativeSelect == null) {
                    _nativeSelect = (new SelectElement(Native));
                }
                return _nativeSelect;
            }
        }
        private SelectElement _nativeSelect;

        #endregion Properties and Fields

        #region C-tors

        protected DropBoxWebElement() { }

        #endregion C-tors

        #region RCE Value

        protected override object
            ReadValue(
            ) { return NativeSelect.SelectedOption.Text; }

        public override bool
            ClearValue(
            ) { WebBrowser.ScrollTo(Native); NativeSelect.DeselectAll(); return true; }


        public override bool
            EnterValue<
                TValue>(
                TValue value
            ) { return EnterValue(value, dropDown: false); }

        public bool
            EnterValue<
                TValue>(
                TValue value,
                bool dropDown
            ) {
            if (ReferenceEquals(value, null)) {
                return false;
            }
            var text = value.ToString();
            WebBrowser.ScrollTo(Native);
            if (dropDown) {
                Native.Click();
                NativeSelect.SelectByText(text);
                try {
                    Native.Click();
                } catch {
                    return true;
                }
            } else {
                NativeSelect.SelectByText(text);
            }
            return true;
        }

        #endregion RCE Value
    }
}
