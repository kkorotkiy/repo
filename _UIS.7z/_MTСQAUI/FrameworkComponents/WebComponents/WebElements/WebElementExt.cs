﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using OpenQA.Selenium;
using UtilityComponents;
using WebComponents.WebControls;


namespace WebComponents.WebElements
{
    public static class WebElementExt
    {
        #region Find

        public static TWebElement
            Find<
                TWebElement>(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue
            ) where TWebElement : WebElement {
            return ((TWebElement) Find(webElementInfo, timeout));
        }

        public static WebElement
            Find(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) {
            IWebElement nativeWebElement;
            try {
                nativeWebElement = WebBrowser.FindElement(webElementInfo.XPath, timeout);
            } catch (Exception exception) {
                if ((  (exception is NoSuchFrameException)
                    || (exception is NoSuchElementException)
                    || (exception is NotFoundException)
                    || (exception is WebDriverTimeoutException)
                    || (exception is TimeoutException)
                    //|| (exception is InvalidSelectorException)
                    ) && !throwNotFound
                   ) {
                    return (new WebElementMock());
                }
                throw;
            }
            var webElement = WebElement.New(webElementInfo.WebElementType, nativeWebElement);
            return webElement;
        }


        public static IEnumerable<TWebElement>
            FindAll<
                TWebElement>(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue
            ) where TWebElement : WebElement {
            return FindAll(webElementInfo, timeout).Cast<TWebElement>();
        }

        public static IEnumerable<WebElement>
            FindAll(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue
            ) {
            IEnumerable<IWebElement> nativeWebElements;
            try {
                nativeWebElements = WebBrowser.FindElements(webElementInfo.XPath, timeout);
            } catch (Exception exception) {
                if (   (exception is NoSuchFrameException)
                    || (exception is NoSuchElementException)
                    || (exception is NotFoundException)
                    || (exception is WebDriverTimeoutException)
                    || (exception is TimeoutException)
                    //|| (exception is InvalidSelectorException)
                   ) {
                    return Enumerable.Empty<WebElement>();
                }
                throw;
            }
            var type = webElementInfo.WebElementType;
            var webElements = nativeWebElements.Select(native => WebElement.New(type, native));
            return webElements;
        }

        #endregion Find

        #region Properties

        #region Displayed

        public static bool
            Exists(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue
            ) { return !(webElementInfo.Find(timeout, throwNotFound: false) is WebElementMock); }


        public static bool
            Displayed(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue
            ) {
            bool? displayed = null;
            Func<bool> displayedHasValue =
                (() => {
                    var webElement = webElementInfo.Find(timeout: 160UL, throwNotFound: false);
                    displayed = webElement.Displayed;
                    return displayed.HasValue;
                });
            WebBrowser.Wait(displayedHasValue, timeout);
            return displayed.Value;
        }

        public static bool
            DisplayedAny(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue
            ) { return webElementInfo.FindAll(timeout).Any(webElement => webElement.Displayed.IsTrue()); }

        #endregion Displayed

        #region Location

        public static Point
            Location(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) { return webElementInfo.Find(timeout, throwNotFound).Location; }

        public static int
            Position(
                this WebElementInfo webElementInfo,
                bool skipNotDisplayed = false,
                string precedingSiblingXPath = WebControlPattern.preceding_sibling,
                ulong timeout = ulong.MinValue
            ) {
            if (skipNotDisplayed) {
                if (!webElementInfo.Displayed(timeout)) {
                    return 0;
                }
            } else if (!webElementInfo.Exists(timeout)) {
                return 0;
            }
            var precedingSibling = WebElementInfo.New(webElementInfo, precedingSiblingXPath);
            var precedingSiblingCount = (
                 skipNotDisplayed
                     ? precedingSibling.Count((webElement => webElement.Displayed.IsTrue()), timeout)
                     : precedingSibling.Count(timeout: timeout)
                );
            var position = (precedingSiblingCount + 1);
            return position;
        }

        public static Size
            Size(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) { return webElementInfo.Find(timeout, throwNotFound).Size; }


        public static int
            Count(
                this WebElementInfo webElementInfo,
                Func<WebElement, bool> predicate = null,
                ulong timeout = ulong.MinValue
            ) {
            var webElements = webElementInfo.FindAll(timeout);
            var count = (
                 (predicate != null)
                     ? webElements.Count(predicate)
                     : webElements.Count()
                );
            return count;
        }

        #endregion Location

        #region Attributes

        public static string
            Id(this WebElementInfo webElementInfo,
               ulong timeout = ulong.MinValue,
               bool throwNotFound = true
            ) { return webElementInfo.Find(timeout, throwNotFound).Id; }

        public static string
            Class(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) { return webElementInfo.Find(timeout, throwNotFound).Class; }

        public static string
            Style(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) { return webElementInfo.Find(timeout, throwNotFound).Style; }


        public static string
            AttributeValue(
                this WebElementInfo webElementInfo,
                string attributeName,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) {
            var webElement = webElementInfo.Find(timeout, throwNotFound);
            var attributeValue = webElement.GetAttributeValue(attributeName);
            return attributeValue;
        }

        #endregion Attributes
        
        #endregion Properties

        #region Actions

        #region Wait

        public static bool
            WaitExists(
                this WebElementInfo webElementInfo,
                bool exists = true,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            Func<bool> existCondition = (() => (webElementInfo.Exists(timeout: 160UL) == exists));
            return WebBrowser.Wait(existCondition, timeout, throwTimedOut);
        }

        public static bool
            WaitDisplayed(
                this WebElementInfo webElementInfo,
                bool displayed = true,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            Func<bool> displayedCondition =
                (() => {
                    var webElement = webElementInfo.Find(timeout: 160UL, throwNotFound: false);
                    var webElementDisplayed = webElement.Displayed;
                    return (webElementDisplayed.HasValue && (webElementDisplayed.Value == displayed));
                });
            return WebBrowser.Wait(displayedCondition, timeout, throwTimedOut);
        }

        public static bool
            WaitDisplayedAny(
                this WebElementInfo webElementInfo,
                bool displayed = true,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            Func<bool> displayedCondition = (() => (webElementInfo.DisplayedAny(timeout: 320UL) == displayed));
            return WebBrowser.Wait(displayedCondition, timeout, throwTimedOut);
        }

        #endregion Wait

        #region Focus

        public static Point
            GetFocus(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) { return webElementInfo.Find(timeout, throwNotFound).GetFocus(); }

        public static Point
            GetFocus(
                this WebElement webElement
            ) { return WebBrowser.Focus(webElement.Native); }

        #endregion Focus

        #region Click

        public static bool
            Click(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) { return webElementInfo.Find(timeout, throwNotFound).Click(); }

        public static bool
            ClickOverFocus(
                this WebElementInfo webElementInfo,
                int? offsetX = null,
                int? offsetY = null,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) { return webElementInfo.Find(timeout, throwNotFound).ClickOverFocus(offsetX, offsetY); }

        public static bool
            ClickOverFocus(
                this WebElement webElement,
                int? offsetX = null,
                int? offsetY = null
            ) {
            if (webElement is WebElementMock) {
                return false;
            }
            WebBrowser.ScrollTo(webElement.Native);
            WebBrowser.MoveToAndClick(webElement.Native, offsetX, offsetY);
            return true;
        }

        #endregion Click

        #region DragAndDrop

        public static Point
            DragAndDrop(
                this WebElementInfo webElementInfo,
                WebElementInfo webElementTargetInfo,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) {
            var webElement = webElementInfo.Find(timeout, throwNotFound);
            var webElementTarget = webElementTargetInfo.Find(timeout, throwNotFound);
            return webElement.DragAndDrop(webElementTarget);
        }

        public static Point
            DragAndDrop(
                this WebElement webElement,
                WebElement webElementTarget
            ) { return WebBrowser.DragAndDrop(webElement.Native, webElementTarget.Native); }

        public static Point
            DragAndDropToOffset(
                this WebElementInfo webElementInfo,
                int offsetX,
                int offsetY,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) { return webElementInfo.Find(timeout, throwNotFound).DragAndDropToOffset(offsetX, offsetY); }

        public static Point
            DragAndDropToOffset(
                this WebElement webElement,
                int offsetX,
                int offsetY
            ) { return WebBrowser.DragAndDropToOffset(webElement.Native, offsetX, offsetY); }

        #endregion DragAndDrop

        #endregion Actions

        #region RCE Value

        public static TValue
            ReadValue<
                TValue>(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) { return webElementInfo.Find(timeout, throwNotFound).ReadValue<TValue>(); }

        public static bool
            ClearValue(
                this WebElementInfo webElementInfo,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) { return webElementInfo.Find(timeout, throwNotFound).ClearValue(); }

        public static bool
            EnterValue<
                TValue>(
                this WebElementInfo webElementInfo,
                TValue value,
                ulong timeout = ulong.MinValue,
                bool throwNotFound = true
            ) { return webElementInfo.Find(timeout, throwNotFound).EnterValue(value); }

        #endregion RCE Value
    }
}