﻿using System;


namespace WebComponents.WebElements
{
    public class WebElementInfo
    {
        #region Properties and Fields

        public const string PositioningFormat = ("({0})[{1}]");
        public string  XPath { get; private set; }
        public Type WebElementType { get; private set; }

        #endregion Properties and Fields

        #region Factory Methods

        private WebElementInfo() { }

        public static WebElementInfo
            New(string xPath,
                object positioningArg = null
            ) { return New<WebElement>(xPath, positioningArg); }

        public static WebElementInfo
            New<TWebElement>(
                string xPath,
                object positioningArg = null
            ) where TWebElement : WebElement {
            if (positioningArg != null) {
                xPath = string.Format(PositioningFormat, xPath, positioningArg);
            }
            var webElementInfo =
                (new WebElementInfo {
                    XPath = xPath,
                    WebElementType = typeof(TWebElement)
                });
            return webElementInfo;
        }

        public static WebElementInfo
            New(WebElementInfo ancestor,
                string relativeXPath,
                object positioningArg = null
            ) { return New<WebElement>(ancestor, relativeXPath, positioningArg); }

        public static WebElementInfo
            New<TWebElement>(
                WebElementInfo ancestor,
                string relativeXPath,
                object positioningArg = null
            ) where TWebElement : WebElement {
            return New<TWebElement>((ancestor.XPath + relativeXPath), positioningArg);
        }

        #endregion Factory Methods

        #region Clone

        public static TWebElementInfo
            Clone<
                TWebElementInfo>(
                TWebElementInfo webElementInfo
            ) where TWebElementInfo : WebElementInfo {
            TWebElementInfo clone;
            if (webElementInfo == null) {
                clone = default(TWebElementInfo);
            } else {
                clone = ((TWebElementInfo) webElementInfo.Clone());
            }
            return clone;
        }

        public virtual WebElementInfo Clone() { return ((WebElementInfo) MemberwiseClone()); }

        #endregion Clone
    }
}
