﻿

namespace WebComponents.WebElements
{
    public class TextBoxWebElement : WebElement
    {
        #region C-tors

        protected TextBoxWebElement() { }

        #endregion C-tors

        #region RCE Value

        protected override object
            ReadValue(
            ) { return GetAttributeValue("value"); }


        public override bool
            ClearValue(
            ) { WebBrowser.ScrollTo(Native); Native.Click(); Native.Clear(); return true; }


        public override bool
            EnterValue<
                TValue>(
                TValue value
            ) { return EnterValue(value, clear: false); }

        public bool
            EnterValue<
                TValue>(
                TValue value,
                bool clear
            ) {
            if (clear) {
                ClearValue();
            }
            if (ReferenceEquals(value, null)) {
                return false;
            }
            var text = value.ToString();
            if (!clear) {
                WebBrowser.ScrollTo(Native);
            }
            SendKeys(text);
            return true;
        }

        #endregion RCE Value
    }
}
