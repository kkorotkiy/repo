﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using LogComponents;
using WebComponents.WebControls;
using UtilityComponents;
using UtilityComponents.Native;
using WM = UtilityComponents.Native.WindowMessages;
using BM = UtilityComponents.Native.ButtonMessages;
using uCmd = UtilityComponents.Native.User32.uCmd_Param;
using fuFlags = UtilityComponents.Native.User32.fuFlags_Param;
using appConfig = System.Configuration.ConfigurationManager;


namespace WebComponents
{
    public enum WebDriverType : byte {
        InternetExplorer = 0,
        Firefox = 1,
        Chrome = 2,
    }


    public static class WebBrowser
    {
        public enum ScrollMode : byte { Bottom = 0, Top = 1 }

        #region Constants

        #region Scripts

        public const string GetDocumentReadyStateJs = (@"return document.readyState;");
        public const string MoveWindowJs = (@"window.moveTo(arguments[0], arguments[1]);");
        public const string ResizeWindowJs = (@"window.resizeTo(arguments[0], arguments[1]);");

        public const string MaximizeWindowJs = (@"
window.moveTo(0, 0);
window.resizeTo(screen.width, screen.height);
");
        public const string GetElementByClassNameJs = (@"
function getElementByClassName(frameName, tagName, className)
{{
    var hasClassName = new RegExp('(?:^|\\s){0}(?:$|\\s)');

    var frame = document.getElementById(frameName);
    var allElements = frame.contentWindow.document.getElementsByTagName(tagName);

    for (var i = 0; i < allElements.length; i++)
    {{
	    var element = allElements[i];
        var elementClassName = element.className;

	    if (elementClassName != null && hasClassName.test(elementClassName) && elementClassName.indexOf(className) != -1)
        {{
            return element;
        }}
    }}

    return null;
}}

return getElementByClassName(arguments[0], arguments[1], arguments[2]);
");
        public const string ScrollElementIntoViewJs = (@"return arguments[0].scrollIntoView(arguments[1]);");
        public const string ClickElementJs = (@"return arguments[0].click();");

        #endregion Scripts

        #region Exceptions

        private const string
            FileDownloadNotSupportedException =
                (@"File downloading is not supported for ""{0}"".");

        private const string
            AutoCompletePasswordsNotSupportedException =
                (@"AutoComplete passwords is not supported for ""{0}"".");

        #endregion Exceptions

        #endregion Constants

        #region Properties and Fields

        private static Process _process;
        private static Process _driverServerProcess;

        private static IWebDriver _webDriver;
        private static IWindow _webDriverWindow;
        private static ITimeouts _webDriverTimeouts;
        private static WebDriverWait _webDriverWait;
        private static Actions _webDriverActions;
        private static IJavaScriptExecutor _jsExecutor;

        public static bool IsLaunched { get; private set; }
        public static WebDriverType Type { get; private set; }
        public static string Url { get { return _webDriver.Url; } }
        
        static WebBrowser() {
            DefaultTimeout = Cast.As<ulong>(appConfig.AppSettings["WebDriverTimeout"]);
            HttpResponseTimeout = Cast.As<ulong>(appConfig.AppSettings["HttpResponseTimeout"]);
            var type = Cast.AsEnum<WebDriverType?>(appConfig.AppSettings["WebDriverType"]);
            Type = (type ?? default(WebDriverType));
        }

        #endregion Properties and Fields

        #region Launch

        public static void Launch(WebDriverType type, bool maximize = true) {
            Type = type;
            Launch(maximize);
        }

        public static void Launch(bool maximize = true)
        {
            _webDriver = InstantiateWebDriver(Type);
            _webDriverWindow = _webDriver.Manage().Window;
            _windowHandlesCount = _webDriver.WindowHandles.Count;
            MainWindowHandle = _webDriver.CurrentWindowHandle;
            _webDriverTimeouts = _webDriver.Manage().Timeouts();
            _webDriverWait = (new WebDriverWait(_webDriver, default(TimeSpan)));
            ResetTimeouts();
            _webDriverActions = (new Actions(_webDriver));
            _jsExecutor = ((IJavaScriptExecutor) _webDriver);
            IsLaunched = true;
            if (maximize) { Maximize(); }
        }

        private static IWebDriver InstantiateWebDriver(WebDriverType type)
        {
            IWebDriver webDriver;
            string processName;
            string driverServerProcessName;
            Func<IWebDriver> constructor;
            switch (type) {
                case WebDriverType.InternetExplorer: {
                    driverServerProcessName = "IEDriverServer";
                    processName = "iexplore";
                    var options =
                        (new InternetExplorerOptions {
                            //InitialBrowserUrl = Settings.Default.WebSiteUrl,
                            EnableNativeEvents = true,
                            EnablePersistentHover = false,
                            IntroduceInstabilityByIgnoringProtectedModeSettings = true,
                            UnexpectedAlertBehavior = InternetExplorerUnexpectedAlertBehavior.Ignore
                        });
                    var driverService = InternetExplorerDriverService.CreateDefaultService();
                    var commandTimeout = TimeSpan.FromMilliseconds(HttpResponseTimeout);
                    constructor = (() => (new InternetExplorerDriver(driverService, options, commandTimeout)));
                    break;
                }
                case WebDriverType.Firefox: {
                    driverServerProcessName = null;
                    processName = "firefox";
                    constructor = (() => (new FirefoxDriver()));
                    break;
                }
                case WebDriverType.Chrome: {
                    driverServerProcessName = null;
                    processName = "chrome";
                    constructor = (() => (new ChromeDriver()));
                    break;
                }
                default: {
                    throw (new InvalidEnumArgumentException("type",(int)type,typeof(WebDriverType)));
                }
            }
            webDriver = InstantiateWebDriver(driverServerProcessName, processName, constructor);
            return webDriver;
        }

        private static IWebDriver
            InstantiateWebDriver(
                string driverServerProcessName,
                string processName,
                Func<IWebDriver> constructor
            ) {
            var driverServerProcesses = Process.GetProcessesByName(driverServerProcessName);
            var processes = Process.GetProcessesByName(processName);
            var webDriver = constructor();
            _driverServerProcess =
                ProcessExt.GetSingleProcessWithMainWindowTitle(
                    driverServerProcessName,
                    exceptList: driverServerProcesses
                    );
            _process =
                ProcessExt.GetSingleProcessWithMainWindowTitle(
                    processName,
                    exceptList: processes
                    );
            return webDriver;
        }

        #endregion Launch

        #region Window

        public static string Title { get { return _process.MainWindowTitle; } }
        public static Point Position {
            get { try { return _webDriverWindow.Position; } catch { return Point.Empty; } }
#pragma warning disable 642
            set { try { _webDriverWindow.Position = value; } catch { ; } }
#pragma warning restore 642
        }
        public static Size Size {
            get { try { return _webDriverWindow.Size; } catch { return Size.Empty; } }
#pragma warning disable 642
            set { try { _webDriverWindow.Size = value; } catch { ; } }
#pragma warning restore 642
        }

        public static void Maximize(ulong timeout = ulong.MinValue)
        {
            var windowArea = (Size.Height*Size.Width);
            _webDriverWindow.Maximize();
            Func<bool> maximizeWindow = (() => (windowArea <= (Size.Height*Size.Width)));
            Wait(maximizeWindow, timeout, throwTimedOut: false);
        }

        #endregion Window

        #region Timeouts

        public static readonly ulong DefaultTimeout;
        public static readonly ulong HttpResponseTimeout;

        public static ulong ImplicitTimeout {
            get { return _implicitTimeout; }
            set {
                var timeout = TimeSpan.FromMilliseconds(value);
                _webDriverTimeouts.ImplicitlyWait(timeout);
                _implicitTimeout = value;
            }
        }
        private static ulong _implicitTimeout;

        public static ulong ScriptTimeout {
            get { return _scriptTimeout; }
            set {
                var timeout = TimeSpan.FromMilliseconds(value);
                _webDriverTimeouts.SetScriptTimeout(timeout);
                _scriptTimeout = value;
            }
        }
        private static ulong _scriptTimeout;

        public static void ResetTimeouts() {
            ImplicitTimeout = DefaultTimeout;
            ScriptTimeout = DefaultTimeout;
        }

        #endregion Timeouts

        #region WebSite

        public static WebSite WebSite { get; private set; }
        
        public static void LoadWebSite(string url = null) { LoadWebSite<WebSite>(url); }

        public static void LoadWebSite<TWebSite>(string url = null) where TWebSite : WebSite
        {
            UnloadWebSite();
            WebSite = WebSite.CreateInstance<TWebSite>(url);
            WebSite.Load();
        }

        public static void UnloadWebSite()
        {
            if (WebSite == null) {
                return;
            }
            WebSite.Unload();
            WebSite = null;
        }

        #endregion WebSite

        #region WebBrowser Actions

        #region Expand To FullScreen

        private static void ExpandToFullScreen(int timeout = 1600)
        {
            switch (Type) {
                case WebDriverType.InternetExplorer: {
                    ExpandIEToFullScreen(timeout);
                    break;
                }
                default: {
                    Maximize();
                    break;
                }
            }
        }

        private static void ExpandIEToFullScreen(int timeout)
        {
            var hWnd = User32.FindWindowEx(_process.MainWindowHandle, IntPtr.Zero, "WorkerW", "Navigation Bar");
            if (hWnd == IntPtr.Zero) {
                return;
            }
            Thread.Sleep(timeout);
            User32.RECT rect;
            User32.GetWindowRect(hWnd, out rect);
            if (rect.Y > 0) {
                User32.SendKeys(_process.Id, "{F11}");
                var count = -1;
                do {
                    Thread.Sleep(512);
                    hWnd = User32.FindWindowEx(_process.MainWindowHandle, IntPtr.Zero, "WorkerW", "Navigation Bar");
                    if (hWnd == IntPtr.Zero) {
                        if (++count < 4) {
                            continue;
                        }
                        break;
                    }
                    User32.GetWindowRect(hWnd, out rect);
                } while ((rect.Y > 0) && (++count < 4));
            }
        }

        #endregion Expand To FullScreen

        #region Exit FullScreen Mode

        private static void ExitFullScreenMode(int timeout = 1600)
        {
            switch (Type) {
                case WebDriverType.InternetExplorer: {
                    ExitIEFullScreenMode(timeout);
                    break;
                }
            }
        }
        
        private static void ExitIEFullScreenMode(int timeout)
        {
            var hWnd = User32.FindWindowEx(_process.MainWindowHandle, IntPtr.Zero, "WorkerW", "Navigation Bar");
            if (hWnd == IntPtr.Zero) {
                return;
            }
            Thread.Sleep(timeout);
            User32.RECT rect;
            User32.GetWindowRect(hWnd, out rect);
            if (rect.Y < 0) {
                User32.SendKeys(_process.Id, "{F11}");
                var count = -1;
                do {
                    Thread.Sleep(512);
                    hWnd = User32.FindWindowEx(_process.MainWindowHandle, IntPtr.Zero, "WorkerW", "Navigation Bar");
                    if (hWnd == IntPtr.Zero) {
                        if (++count < 4) {
                            continue;
                        }
                        break;
                    }
                    User32.GetWindowRect(hWnd, out rect);
                } while ((rect.Y < 0) && (++count < 4));
            }
        }

        #endregion Exit FullScreen Mode

        #region AutoCompletePasswords

        private static void
            AutoCompletePasswords(
                bool no = true,
                bool dontOfferAgain = true,
                int timeout = 1280
            ) {
            switch (Type) {
                case WebDriverType.InternetExplorer: {
                    AutoCompletePasswordsForIE(no, dontOfferAgain, timeout);
                    break;
                }
                default: {
                    throw (new NotSupportedException(string.Format(
                        AutoCompletePasswordsNotSupportedException,
                            Type)));
                }
            }
        }

        private static void
            AutoCompletePasswordsForIE(
                bool no,
                bool dontOfferAgain,
                int timeout
            ) {
            IntPtr hWnd = User32.WaitWindow(null, "AutoComplete Passwords", timeout);
            if (hWnd == IntPtr.Zero) {
                return;
            }
            if (dontOfferAgain) {
                var hWnd1 = User32.FindWindowEx(hWnd, IntPtr.Zero, "Button", "&Don't offer to remember any more passwords");
                if (hWnd1 != IntPtr.Zero) {
                    User32.Click(hWnd1);
                }
            }
            var lpszWindow = (no ? "&No" : "&Yes");
            hWnd = User32.FindWindowEx(hWnd, IntPtr.Zero, "Button", lpszWindow);
            User32.Click(hWnd);
        }

        #endregion AutoCompletePasswords

        #region Download File

        private static void
            DownloadFile(
                string filePath = null,
                int timeout = 300000, // 5 min.
                params object[] args
            ) {
            switch (Type) {
                case WebDriverType.InternetExplorer: {
                    DownloadFileFromIE(filePath, timeout, args);
                    break;
                }
                default: {
                        throw (new NotSupportedException(string.Format(
                            FileDownloadNotSupportedException,
                                Type)));
                }
            }
        }

        private static void
            DownloadFileFromIE(
                string filePath,
                int timeout,
                params object[] args
            ) {
            IntPtr hWnd = User32.WaitWindow(null, "File Download", timeout, delay: 3200);
            hWnd = User32.FindWindowEx(hWnd, IntPtr.Zero, "Button", "&Save");
            User32.Click(hWnd);

            hWnd = User32.WaitWindow(null, "Save As", 4000);
            if (filePath != null) {
                filePath = Environment.ExpandEnvironmentVariables(filePath);
                var hWnd1 = User32.GetWindow(hWnd, uCmd._CHILD);
                hWnd1 = User32.GetWindow(hWnd1, uCmd._CHILD);
                hWnd1 = User32.GetWindow(hWnd1, uCmd._CHILD);
                hWnd1 = User32.GetWindow(hWnd1, uCmd._CHILD);
                hWnd1 = User32.GetWindow(hWnd1, uCmd._CHILD);
                User32.SendMessage(hWnd1, WM._SETTEXT, ((uint)string.Empty.Length), (new StringBuilder(string.Empty, string.Empty.Length)));
                User32.SendMessage(hWnd1, WM._SETTEXT, ((uint)filePath.Length), (new StringBuilder(filePath, filePath.Length)));
            }
            hWnd = User32.FindWindowEx(hWnd, IntPtr.Zero, "Button", "&Save");
            User32.ClickTimeout(hWnd, fuFlags._NORMAL, 2000U);

            hWnd = User32.WaitWindow(null, "Confirm Save As", 4000, 0);
            if (hWnd != IntPtr.Zero) {
                hWnd = User32.GetWindow(hWnd, uCmd._CHILD);
                hWnd = User32.GetWindow(hWnd, uCmd._CHILD);
                hWnd = User32.GetWindow(hWnd, uCmd._HWNDLAST);
                hWnd = User32.GetWindow(hWnd, uCmd._HWNDPREV);
                hWnd = User32.GetWindow(hWnd, uCmd._CHILD);
                User32.Click(hWnd);
            }

            hWnd = User32.WaitWindow(null, "Download complete", timeout);
            hWnd = User32.FindWindowEx(hWnd, IntPtr.Zero, "Button", "Close");
            User32.Click(hWnd);

            if (args.Length > 0) {
                var procs = Process.GetProcessesByName("iexplore");
                foreach (var proc in procs) {
                    if (proc.MainWindowTitle.Contains(Convert.ToString(args[0]))) {
                        uint lpdwResult;
                        User32.SendMessageTimeout(proc.MainWindowHandle, WM._CLOSE, 0, null, fuFlags._NORMAL, 2000U, out lpdwResult);
                        //prc.Kill();
                    }
                }
            }
        }

        #endregion Download File

        #region Navigate

        public static void Navigate(string url) { _webDriver.Navigate().GoToUrl(url); }

        public static void Refresh() { _webDriver.Navigate().Refresh(); }

        public static void StopLoading() { User32.SendKeys(_process.MainWindowHandle, "{ESC}"); }

        #endregion Navigate

        #region SwitchTo

        #region SwitchToDocument

        private const string __main_doc = ("__main_doc");

        public static object[] FramePath { get { return _framePath.ToArray(); } }
        private static readonly List<object> _framePath = (new List<object>(0));

        private static string DocumentPath { 
            get {
                if (_framePath.Count == 0) {
                    return __main_doc;
                }
                var frames = _framePath.Select(doc => doc.ToString()).ToArray();
                var documentPath = Path.Combine(frames);
                documentPath = Path.Combine(__main_doc, documentPath);
                return documentPath;
            } 
        }

        private static bool
            SwitchToDefaultContent(
                bool waitReady = false,
                ulong timeout = ulong.MinValue
            ) {
            _webDriver.SwitchTo().DefaultContent();
            _framePath.Clear();
            var documentReady = false;
            if (waitReady) {
                documentReady = WaitDocumentReady(timeout);
            }
            return documentReady;
        }

        public static bool
            SwitchToMainDocument(
                bool force = false,
                bool waitReady = false,
                ulong timeout = ulong.MinValue
            ) { return SwitchToDocument(force, waitReady, timeout); }

        public static bool
            SwitchToDocument(
                bool force = false,
                bool waitReady = false,
                ulong timeout = ulong.MinValue,
                params object[] framePath
            ) {
            var documentReady = false;
            if (force) {
                documentReady = _SwitchToDocument(waitReady, timeout, framePath);
            } else {
                var needToSwitch = !_framePath.SequenceEqual(framePath);
                if (needToSwitch) {
                    documentReady = _SwitchToDocument(waitReady, timeout, framePath);
                } else if (waitReady) {
                    documentReady = WaitDocumentReady(timeout);
                }
            }
            return documentReady;
        }

        private static bool
            _SwitchToDocument(
                bool waitReady,
                ulong timeout,
                params object[] framePath
            ) {
            var documentReady = SwitchToDefaultContent(waitReady, timeout);
            if (framePath.Length > 0) {
                documentReady = SwitchToFrame(waitReady, timeout, framePath);
            }
            return documentReady;
        }

        public static bool
            WaitDocumentReady(
                ulong timeout = ulong.MinValue
            ) {
            if (timeout <= ulong.MinValue) {
                timeout = ImplicitTimeout;
            }
            bool documentReady;
            string documentReadyState;
            string document = DocumentPath;
            IWebElement documentBody = null;
            var now = DateTime.Now;
            double waittime;
            do {
                try {
                    if (documentBody == null) {
                        documentBody = FindElement(WebControlPattern.Frame, timeout);
                    }
                    documentReadyState = ExecuteScript<string>(GetDocumentReadyStateJs);
                } catch {
                    documentReadyState = ("<unknown>");
                }
                waittime = (DateTime.Now - now).TotalMilliseconds;
                documentReady = (documentReadyState == "complete");
                LogManager.LogRecord(string.Format("document:'{0}' readyState:'{1}' waittime:{2}", document, documentReadyState, waittime), level: LogLevel.Debug);
            } while (!documentReady && (waittime < timeout))
                ;
            return documentReady;
        }

        #endregion SwitchToDocument

        #region SwitchToFrame

        public static bool
            SwitchToFrame(
                bool waitReady = false,
                ulong timeout = ulong.MinValue,
                params object[] framePath
            ) { return _SwitchToFrame(framePath, waitReady, timeout); }

        private static bool
            _SwitchToFrame(
                IEnumerable args,
                bool waitReady,
                ulong timeout
            ) {
            var documentReady = false;
            foreach (var arg in args) {
                var frameName = (arg as string);
                if (frameName != null) {
                    documentReady = SwitchToFrame(frameName, waitReady, timeout);
                    continue;
                }
                var framePath = (arg as IEnumerable);
                if (framePath != null) {
                    documentReady = _SwitchToFrame(framePath, waitReady, timeout);
                    continue;
                }
                var frameIndex = ((int) arg); {
                    documentReady = SwitchToFrame(frameIndex, waitReady, timeout);
                }
            }
            return documentReady;
        }


        public static bool
            SwitchToFrame(
                string name,
                bool waitReady = false,
                ulong timeout = ulong.MinValue
            ) {
            _webDriver.SwitchTo().Frame(name);
            _framePath.Add(name);
            var documentReady = false;
            if (waitReady) {
                documentReady = WaitDocumentReady(timeout);
            }
            return documentReady;
        }

        public static bool
            SwitchToFrame(
                int index,
                bool waitReady = false,
                ulong timeout = ulong.MinValue
            ) {
            _webDriver.SwitchTo().Frame(index);
            _framePath.Add(index);
            var documentReady = false;
            if (waitReady) {
                documentReady = WaitDocumentReady(timeout);
            }
            return documentReady;
        }

        #endregion SwitchToFrame

        #region SwitchToWindow

        public static ReadOnlyCollection<string> WindowHandles { get { return _webDriver.WindowHandles; } }
        private static int _windowHandlesCount;

        public static string MainWindowHandle { get; private set; }
        public static string CurrentWindowHandle {
            get {
                try {
                    return _webDriver.CurrentWindowHandle;
                } catch (NoSuchWindowException) {
                    return null;
                }
            }
        }
        public static string CurrentWindowTitle { get { return _webDriver.Title; } }

        public static bool
            SwitchToWindow(
                string handle,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            if (CurrentWindowHandle == handle) {
                return true;
            }
            _webDriver.SwitchTo().Window(handle);
            Func<bool> switchToWindow = (() => (CurrentWindowHandle == handle));
            var isWindowReady = Wait(switchToWindow, timeout, throwTimedOut);
            if (isWindowReady) {
                _webDriverWindow = _webDriver.Manage().Window;
                _webDriverTimeouts = _webDriver.Manage().Timeouts();
                ImplicitTimeout = _implicitTimeout;
                ScriptTimeout = _scriptTimeout;
            }
            return isWindowReady;
        }

        public static bool
            SwitchToMainWindow(
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) { return SwitchToWindow(MainWindowHandle, timeout, throwTimedOut); }

        public static bool
            SwitchToOpenedWindow(
                out string handle,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            var isWindowOpened = WaitWindowOpened(out handle, timeout, throwTimedOut);
            if (!isWindowOpened) {
                return false;
            }
            var isWindowReady = SwitchToWindow(handle, timeout, throwTimedOut);
            isWindowReady = (isWindowReady && WaitWindowRendered(timeout, throwTimedOut));
            return isWindowReady;
        }

        public static bool
            CloseWindow(
                string handle,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            if (!SwitchToWindow(handle, timeout, throwTimedOut)) {
                return false;
            }
            if (WindowHandles.Count < 2) {
                Quit(timeout);
                return true;
            }
            _webDriver.Close();
            var isWindowClosed = WaitWindowClosed(handle, timeout, throwTimedOut);
            isWindowClosed = (isWindowClosed && SwitchToMainWindow(timeout, throwTimedOut));
            return isWindowClosed;
        }
        
        public static bool
            CloseWindow(
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) { return CloseWindow(CurrentWindowHandle, timeout, throwTimedOut); }


        public static bool
            WaitWindowOpened(
                out string handle,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            Func<bool> windowOpened = (() => (_windowHandlesCount < WindowHandles.Count));
            var isWindowOpened = Wait(windowOpened, timeout, throwTimedOut);
            if (isWindowOpened) {
                handle = WindowHandles.First(hdl => (hdl != CurrentWindowHandle));
                _windowHandlesCount = WindowHandles.Count;
            } else {
                handle = null;
            }
            return isWindowOpened;
        }

        private static bool
            WaitWindowRendered(
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            Func<bool> windowRendered = (() => (Size != Size.Empty));
            return Wait(windowRendered, timeout, throwTimedOut);
        }


        public static bool
            WaitWindowClosed(
                string handle,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            Func<bool> windowClosed = (() => !WindowHandles.Contains(handle));
            var isWindowClosed = Wait(windowClosed, timeout, throwTimedOut);
            if (isWindowClosed) {
                _windowHandlesCount = WindowHandles.Count;
            }
            isWindowClosed = (isWindowClosed && WaitWindowEscaped(timeout, throwTimedOut: false));
            return isWindowClosed;
        }

        private static bool
            WaitWindowEscaped(
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            Func<bool> windowDestroyed = (() => (Size == Size.Empty));
            return Wait(windowDestroyed, timeout, throwTimedOut);
        }

        #endregion SwitchToWindow

        #endregion SwitchTo

        #region Execute Script

        public static object
            ExecuteScript(
                string script,
                params object[] args
            ) { return ExecuteScript<object>(script, args); }

        public static TOut
            ExecuteScript<
                TOut>(
                string script,
                params object[] args
            ) { return Cast.As<TOut>(_jsExecutor.ExecuteScript(script, args)); }


        public static object
            ExecuteScriptAsync(
                string script,
                params object[] args
            ) { return ExecuteScriptAsync<object>(script, args); }

        public static TOut
            ExecuteScriptAsync<
                TOut>(
                string script,
                params object[] args
            ) { return Cast.As<TOut>(_jsExecutor.ExecuteAsyncScript(script, args)); }

        #endregion Execute Script

        #region Wait

        public static void
            Wait(
                ulong timeout = ulong.MinValue
            ) { Wait(null, timeout, throwTimedOut: false); }

        public static bool
            Wait(
                Func<bool> condition,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            if (timeout <= ulong.MinValue) {
                timeout = ImplicitTimeout;
            }
            var timeSpan = TimeSpan.FromMilliseconds(timeout);
            _webDriverWait.Timeout = timeSpan;
            try {
                var conditionState = (
                     (condition != null)
                         ? _webDriverWait.Until(__ => condition())
                         : _webDriverWait.Until(__ => false)
                    );
                return conditionState;
            } catch (Exception exception) {
                if ((  (exception is TimeoutException)
                    || (exception is WebDriverTimeoutException)
                    ) && !throwTimedOut
                   ) {
                    return false;
                }
                throw;
            }
        }

        #endregion Wait

        #endregion WebBrowser Actions

        #region WebElement Actions

        #region Find

        public static IWebElement
            FindElement(
                string xPath,
                ulong timeout = ulong.MinValue
            ) {
            IWebElement webElement;
            if (timeout > ulong.MinValue) {
                var implicitTimeout = ImplicitTimeout;
                ImplicitTimeout = timeout;
                try {
                    webElement = _webDriver.FindElement(By.XPath(xPath));
                } finally {
                    ImplicitTimeout = implicitTimeout;
                }
            } else {
                webElement = _webDriver.FindElement(By.XPath(xPath));
            }
            return webElement;
        }

        public static IEnumerable<IWebElement>
            FindElements(
                string xPath,
                ulong timeout = ulong.MinValue
            ) {
            IEnumerable<IWebElement> webElements;
            if (timeout > ulong.MinValue) {
                var implicitTimeout = ImplicitTimeout;
                ImplicitTimeout = timeout;
                try {
                    webElements = _webDriver.FindElements(By.XPath(xPath));
                } finally {
                    ImplicitTimeout = implicitTimeout;
                }
            } else {
                webElements = _webDriver.FindElements(By.XPath(xPath));
            }
            return webElements;
        }

        #endregion Find

        #region Focus

        public static Point
            ScrollTo(
                IWebElement element,
                ScrollMode mode = default(ScrollMode)
            ) {
            var alignWithTop = (mode == ScrollMode.Top);
            ExecuteScript(ScrollElementIntoViewJs, element, alignWithTop);
            return element.Location;
        }

        public static Point
            MoveTo(
                IWebElement element,
                int? offsetX = null,
                int? offsetY = null
            ) {
            var location = element.Location;
            if (offsetX.HasValue && offsetY.HasValue) {
                location.Offset(offsetX.Value, offsetY.Value);
                _webDriverActions.MoveToElement(element, offsetX.Value, offsetY.Value).Perform();
            } else {
                _webDriverActions.MoveToElement(element).Perform();
            }
            return location;
        }

        public static Point
            Focus(
                IWebElement element
            ) { ScrollTo(element); return MoveTo(element); }

        #endregion Focus

        #region Click

        public static void
            Click(
                IWebElement element
            ) {
            //ExecuteScript(ClickElementJs, element);
            _webDriverActions.Click(element).Perform();
        }

        public static Point
            MoveToAndClick(
                IWebElement element,
                int? offsetX = null,
                int? offsetY = null
            ) {
            var location = element.Location;
            if (offsetX.HasValue && offsetY.HasValue) {
                location.Offset(offsetX.Value, offsetY.Value);
                _webDriverActions.MoveToElement(element, offsetX.Value, offsetY.Value).Click().Perform();
            } else {
                _webDriverActions.MoveToElement(element).Click().Perform();
            }
            return location;
        }

        #endregion Click

        #region DragAndDrop

        public static Point
            DragAndDrop(
                IWebElement element,
                IWebElement elementTarget
            ) {
            _webDriverActions.DragAndDrop(element, elementTarget).Perform();
            return elementTarget.Location;
        }

        public static Point
            DragAndDropToOffset(
                IWebElement element,
                int offsetX,
                int offsetY
            ) {
            _webDriverActions.DragAndDropToOffset(element, offsetX, offsetY).Perform();
            return element.Location;
        }

        #endregion DragAndDrop

        #endregion WebElement Actions

        #region Quit

        public static void Quit(ulong timeout = ulong.MinValue)
        {
            UnloadWebSite();
            WaitWebDriverQuit(timeout);
            WaitWindowDestroyed(timeout);
            IsLaunched = false;
        }

        private static void WaitWebDriverQuit(ulong timeout)
        {
            if (timeout <= ulong.MinValue) {
                timeout = ImplicitTimeout;
            }
            Exception exception = null;
            var timeSpan = TimeSpan.FromMilliseconds(timeout);
            var webDriverQuit = (new Thread(() => {try{_webDriver.Quit();}catch(Exception e){exception=e;}}));
            webDriverQuit.Start();
            webDriverQuit.Join(timeSpan);
            var exceptionThrown = (exception != null);
            if (webDriverQuit.IsAlive || exceptionThrown) {
                if (exceptionThrown) {
                    LogManager.LogException(exception, takeScreenshot: true);
                    exception = null;
                }
                ProcessExt.Kill(_process, _driverServerProcess);
                webDriverQuit.Join(timeSpan);
                if (webDriverQuit.IsAlive) {
                    webDriverQuit.Abort();
                }
            }
        }

        private static void WaitWindowDestroyed(ulong timeout)
        {
            var isWindowDestroyed = WaitWindowEscaped(timeout, throwTimedOut: false);
            if (!isWindowDestroyed) {
                ProcessExt.Kill(_process, _driverServerProcess);
            }
        }

        #endregion Quit
    }
}
