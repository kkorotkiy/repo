﻿
namespace WebComponents.WebControls
{
    public static class WebControlPattern
    {
        #region Pages

        public const string Page = ("html/*[self::body or self::frameset]");
        public const string PageTitle = ("html/head/title");

        #endregion Pages

        #region Frames

        public const string Frame = ("html/*[self::body or self::frameset]");

        #endregion Frames

        #region Elements

        #region Any

        public const string Any = ("//*[text()='{0}']");
        public const string Any_ById = ("//*[@id='{0}']");

        #endregion Any

        #region Label

        public const string div = ("//div");
        public const string span = ("//span");
        public const string td = ("//td");
        public const string ul = ("//ul");
        public const string b = ("//b");
        public const string br = ("//br");
        public const string strong = ("//strong");
        public const string label = ("//label");
        public const string Label = ("//*[(self::label or self::strong or self::br or self::b or self::ul or self::td or self::span or self::div or self::li) and ((text()='{0}') or (normalize-space(text())='{0}'))]");

        #endregion Label

        #region Image

        public const string img = ("//img");
        public const string Image = ("//img[@alt='{0}']");

        #endregion Image

        #region Link

        public const string a = ("//a");
        public const string Link = ("//a[descendant-or-self::*[text()='{0}']]");
        public const string Link_ByTooltip = ("//a[descendant-or-self::*[(@title='{0}') or (@alt='{0}')]]");
        public const string LinkImage = ("//a[descendant-or-self::*[text()='{0}']]/img[1]");
        public const string LinkImage_ByTooltip = ("//a[descendant-or-self::*[(@title='{0}') or (@alt='{0}')]]/img[1]");

        #endregion Link

        #region Button

        public const string button = ("//button");
        public const string Button = ("//*[self::button[descendant-or-self::*[(text()='{0}') or (normalize-space(text())='{0}')]] or self::input[(@type='submit') and (@value='{0}')]]");

        #endregion Button

        #region Input

        public const string input = ("//input");

        #endregion Input

        #region CheckBox

        public const string CheckBox = ("//input[(type='CheckBox') or (type='checkbox') or (type='Radio') or (type='radio')]");

        #endregion CheckBox

        #region TextBox

        public const string TextBox = ("//*[self::input[(type='text') or (type='password')] or self::textarea]");

        #endregion TextBox

        #region DropBox

        public const string DropBox = ("//option[text()='{0}']/parent::select");
        public const string DropBoxElement = ("/option[@value='{0}']");

        #endregion DropBox

        #endregion Elements

        #region Axes

        public const string parent = ("/parent::*");
        public const string preceding_sibling = ("/preceding-sibling::*");
        public const string self = ("/self::*");
        public const string descendant_or_self = ("/descendant-or-self::*");
        public const string last_child = ("/*[position()=last()]");
        public const string following_sibling = ("/following-sibling::*");

        #endregion Axes
    }
}
