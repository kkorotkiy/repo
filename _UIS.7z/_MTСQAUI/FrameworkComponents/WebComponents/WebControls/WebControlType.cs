﻿
namespace WebComponents.WebControls
{
    public static class WebControlType
    {
        #region Pages

        public const string Page = ("_.Page");
        public const string PageTitle = ("_.PageTitle");

        #endregion Pages

        #region Frames

        public const string Frame = ("_.Frame");

        #endregion Frames

        #region Elements

        #region Any

        public const string Any = ("_.Any");
        public const string Any_ById = ("_.Any_ById");

        #endregion Any

        #region Label

        public const string div = ("_.div");
        public const string span = ("_.span");
        public const string td = ("_.td");
        public const string ul = ("_.ul");
        public const string b = ("_.b");
        public const string br = ("_.br");
        public const string strong = ("_.strong");
        public const string label = ("_.label");
        public const string Label = ("_.Label");

        #endregion Label

        #region Image

        public const string img = ("_.img");
        public const string Image = ("_.Image");

        #endregion Image

        #region Link

        public const string a = ("_.a");
        public const string Link = ("_.Link");
        public const string Link_ByTooltip = ("_.Link_ByTooltip");
        public const string LinkImage = ("_.LinkImage");
        public const string LinkImage_ByTooltip = ("_.LinkImage_ByTooltip");

        #endregion Link

        #region Button

        public const string button = ("_.button");
        public const string Button = ("_.Button");

        #endregion Button

        #region Input

        public const string input = ("_.input");

        #endregion Input

        #region CheckBox

        public const string CheckBox = ("_.CheckBox");

        #endregion CheckBox

        #region TextBox

        public const string TextBox = ("_.TextBox");

        #endregion TextBox

        #region DropBox

        public const string DropBox = ("_.DropBox");
        public const string DropBoxElement = ("_.DropBoxElement");

        #endregion DropBox

        #endregion Elements

        #region Axes

        public const string parent = ("_.parent");
        public const string preceding_sibling = ("_.preceding_sibling");
        public const string self = ("_.self");
        public const string descendant_or_self = ("_.descendant_or_self");
        public const string last_child = ("_.last_child");
        public const string following_sibling = ("_.following_sibling");

        #endregion Axes
    }
}
