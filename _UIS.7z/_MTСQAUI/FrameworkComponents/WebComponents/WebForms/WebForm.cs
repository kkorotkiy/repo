﻿using System;
using System.IO;
using OpenQA.Selenium;
using LogComponents;
using UtilityComponents;
using WebComponents.WebControls;
using WebComponents.WebElements;
using _ = WebComponents.WebControls.WebControlType;


namespace WebComponents.WebForms
{
    public class WebForm
    {
        #region Exceptions

        private const string
            TrySwitchToWebFormException =
                ("Exception was thrown while trying switch to webForm[{0}].");

        private const string
            CantFindAncestorByCaptionException =
                ("Can't find ancestor form with caption '{0}' for webForm[{1}].");

        #endregion Exceptions

        #region Properties and Fields

        public virtual WebForm ParentForm { get; private set; }

        public virtual object Frame { get; private set; }

        public virtual object[] FramePath {
            get {
                if (_framePath == null) {
                    _framePath = Cast.AsArray<object>(Frame, emptyOnNull: true);
                    if (ParentForm != null) {
                        ArrayExt.Insert(ref _framePath, 0, ParentForm.FramePath);
                    }
                }
                return _framePath;
            } 
        }
        private object[] _framePath;

        public virtual WebElementInfo Container { get; private set; }
        public virtual string Control { get; private set; }
        public virtual string Caption { get; private set; }
        public virtual object InitialCaption { get; private set; }

        public const string NameFormat = ("[{0}, '{1}']");
        public virtual string Name {
            get {
                if (_name == null) {
                    _name = string.Format(NameFormat, Control, Caption);
                }
                return _name;
            }
        }
        private string _name;

        public virtual string FullName {
            get {
                if (_fullName == null) {
                    if (ParentForm != null) {
                        _fullName = Path.Combine(ParentForm.FullName, Name);
                    } else {
                        _fullName = Name;
                    }
                }
                return _fullName;
            }
        }
        private string _fullName;

        public virtual string QuotedFullName {
            get {
                if (_quotedFullName == null) {
                    _quotedFullName = ("["+FullName+"]");
                }
                return _quotedFullName;
            }
        }
        private string _quotedFullName;

        public object PositioningArg { get; set; }

        #endregion Properties and Fields

        #region C-tors

        protected WebForm() { }

        #endregion C-tors

        #region GetElement

        public virtual WebElementInfo
            GetElement(
                string control,
                object caption = null
            ) { return GetElement<WebElement>(control, caption); }

        public virtual WebElementInfo
            GetElement<
                TWebElement>(
                string control,
                object caption = null
            ) where TWebElement : WebElement {
            var webElementXPath = WebBrowser.WebSite.FormatXPath(control, caption);
            var webElementInfo = WebElementInfo.New<TWebElement>(Container, webElementXPath, PositioningArg);
            return webElementInfo;
        }

        #endregion GetElement

        #region GetForm

        public virtual WebForm
            GetForm(
                string control,
                object caption = null,
                object frame = null,
                bool waitLoad = true,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var innerFrame = (frame != null);
            var container = GetFormContainer(control, caption, innerFrame);
            var formattedCaption = WebBrowser.WebSite.FormatCaption(caption);
            var webForm =
                (new WebForm {
                    ParentForm = this,
                    Frame = frame,
                    Container = container,
                    Control = control,
                    Caption = formattedCaption,
                    InitialCaption = caption
                });
            if (waitLoad) {
                webForm.WaitLoad(force, timeout);
            }
            return webForm;
        }

        protected virtual WebElementInfo
            GetFormContainer(
                string control,
                object caption,
                bool innerFrame
            ) {
            var containerXPath = WebBrowser.WebSite.FormatXPath(control, caption);
            var container =
                (innerFrame
                     ? WebElementInfo.New(containerXPath, PositioningArg)
                     : WebElementInfo.New(Container, containerXPath, PositioningArg)
                );
            return container;
        }

        #endregion GetForm

        #region SwitchToForm

        protected virtual bool
            TrySwitchToForm(
                bool force,
                bool waitReady,
                bool rollbackOnFailure,
                ulong timeout = ulong.MinValue
            ) {
            bool isFormReady;
            var currentFramePath = WebBrowser.FramePath;
            try {
                isFormReady = SwitchToForm(force, waitReady, timeout);
            } catch (Exception exception) {
                isFormReady = false;
                LogManager.LogRecord(string.Format(TrySwitchToWebFormException, FullName), exception, LogRecordType.ERROR, takeScreenshot: true);
                if (rollbackOnFailure) {
                    WebBrowser.SwitchToDocument(framePath: currentFramePath);
                }
            }
            return isFormReady;
        }

        public virtual bool
            SwitchToForm(
                bool force = false,
                bool waitReady = false,
                ulong timeout = ulong.MinValue
            ) { return WebBrowser.SwitchToDocument(force, waitReady, timeout, FramePath); }

        public virtual WebForm
            SwitchToParentForm(
                bool waitLoad = false,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var parentForm = ParentForm;
            if (parentForm == null) {
                return this;
            }
            if (waitLoad) {
                parentForm.WaitLoad(force, timeout);
            } else {
                parentForm.SwitchToForm();
            }
            return parentForm;
        }

        public virtual WebForm
            SwitchToAncestorForm(
                object caption,
                bool waitLoad = false,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var ancestorFormCaption = WebBrowser.WebSite.FormatCaption(caption);
            var ancestorForm = ParentForm;
            if (ancestorForm == null) {
                return this;
            }
            do {
                var captionEquals =
                    string.Equals(
                        ancestorForm.Caption,
                        ancestorFormCaption,
                        StringComparison.OrdinalIgnoreCase
                        );
                if (captionEquals) {
                    if (waitLoad) {
                        ancestorForm.WaitLoad(force, timeout);
                    } else {
                        ancestorForm.SwitchToForm();
                    }
                    return ancestorForm;
                }
                ancestorForm = ancestorForm.ParentForm;
            } while (ancestorForm != null)
                ;
            throw (new Exception(string.Format(
                CantFindAncestorByCaptionException,
                    ancestorFormCaption,
                    FullName)
                ));
        }

        public virtual WebForm
            SwitchToAncestorForm(
                byte level,
                bool waitLoad = false,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var ancestorForm = this;
            while ((level > 0) && (ancestorForm.ParentForm != null)) {
                ancestorForm = ancestorForm.ParentForm;
                --level;
            }
            if (!ReferenceEquals(ancestorForm, this)) {
                if (waitLoad) {
                    ancestorForm.WaitLoad(force, timeout);
                } else {
                    ancestorForm.SwitchToForm();
                }
            }
            return ancestorForm;
        }

        #endregion SwitchToForm

        #region Load/Dispose

        public virtual bool
            IsLoaded(
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var isFormReady = TrySwitchToForm(force, waitReady: true, rollbackOnFailure: true, timeout: timeout);
            isFormReady = (isFormReady && Container.Displayed(timeout));
            var isLoaded = (isFormReady && WebBrowser.WebSite.WaitWebFormLoaded(this, timeout, throwTimedOut: false));
            return isLoaded;
        }

        public virtual WebForm
            WaitLoad(
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var attempt = 0;
            do {
                try {
                    var isFormReady = SwitchToForm(force, waitReady: true, timeout: timeout);
                    isFormReady = (isFormReady && Container.WaitDisplayed(true, timeout, throwTimedOut: false));
                    isFormReady = (isFormReady && WebBrowser.WebSite.WaitWebFormLoaded(this, timeout, throwTimedOut: false));
                    WebFormExt.
                        ValidateValue(
                            expectedValue: true,
                            actualValue: isFormReady,
                            @equals: true,
                            message: ("Wait is loaded web form: " + QuotedFullName)
                        );
                    return this;
                } catch (InvalidSelectorException exception) {
                    LogManager.LogException(exception, takeScreenshot: true);
                    if (++attempt > 4) {
                        throw;
                    }
                }
            } while (true);
        }
        
        public virtual WebForm
            WaitDispose(
                ulong timeout = ulong.MinValue
            ) {
            if (Frame == null) {
                WebBrowser.WaitDocumentReady(timeout);
            } else {
                var isFormReady =
                    TrySwitchToForm(
                        force: true,
                        waitReady: true,
                        rollbackOnFailure: false,
                        timeout: 1280UL
                        );
                if (!isFormReady) {
                    return this;
                }
            }
            try {
                if (Container.XPath != WebControlPattern.Frame) {
                    Container.WaitDisplayed(false, timeout, throwTimedOut: false);
                } else if (InitialCaption != null) {
                    var containerXPath = WebBrowser.WebSite.FormatXPath(_.Any, InitialCaption);
                    var container = WebElementInfo.New(containerXPath);
                    container.WaitDisplayed(false, timeout, throwTimedOut: false);
                }
            } catch (InvalidSelectorException exception) {
                LogManager.LogException(exception, level:LogLevel.Debug);
            }
            return this;
        }

        #endregion Load/Dispose

        #region ToString

        public override string ToString() { return ToString(full: false); }

        public virtual string ToString(bool full, bool quoted = false) {
            return (full ? (quoted ? QuotedFullName : FullName) : Name);
        }

        #endregion ToString
    }
}
