﻿using System.IO;
using WebComponents.WebControls;
using WebComponents.WebElements;
using _ = WebComponents.WebControls.WebControlType;


namespace WebComponents.WebForms
{
    public class WebPage : WebForm
    {
        #region Properties and Fields

        public override WebElementInfo Container { get { return _container; } }
        private readonly WebElementInfo _container;

        protected virtual WebElementInfo Title {
            get {
                if (_title == null) {
                    var titleXPath = WebBrowser.WebSite.GetXPath(_.PageTitle);
                    _title = WebElementInfo.New(titleXPath);
                }
                return _title;
            }
        }
        private WebElementInfo _title;

        public override string Caption {
            get {
                string caption;
                try {
                    caption = Title.ReadValue<string>(throwNotFound: false);
                } catch {
                    caption = null;
                }
                if (!string.IsNullOrWhiteSpace(caption)) {
                    caption = caption.ToUpper();
                }
                return caption;
            }
        }

        public override string Control { get { return _control; } }
        private readonly string _control;

        public virtual string Alias { get { return _alias; } }
        private readonly string _alias;

        public virtual string WindowHandle { get { return _windowHandle; } }
        private readonly string _windowHandle;

        public string PageUrl { get; protected set; }
        public virtual string Url {
            get {
                if (_url == null) {
                    var webSite = WebBrowser.WebSite;
                    if (PageUrl == null) {
                        PageUrl = webSite.GetPageUrl(Control);
                    }
                    _url = Path.Combine(webSite.Url, PageUrl);
                }
                return _url;
            }
        }
        private string _url;

        #endregion Properties and Fields

        #region C-tors

        protected internal
            WebPage(
                string alias,
                string windowHandle,
                string control = _.Page,
                string pageUrl = null
            ) {
            _alias = alias;
            _windowHandle = windowHandle;
            _control = control;
            PageUrl = pageUrl;
            var containerXPath = WebBrowser.WebSite.GetXPath(control);
            _container = WebElementInfo.New(containerXPath);
        }

        #endregion C-tors

        #region Load/Dispose

        public virtual WebPage
            Reload(
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            WebBrowser.Refresh();
            WaitLoad(force, timeout);
            return this;
        }

        public override WebForm
            WaitDispose(
                ulong timeout = ulong.MinValue
            ) {
            WebBrowser.Wait(640UL);
            if (Container.XPath != WebControlPattern.Page) {
                WebBrowser.WaitDocumentReady(timeout);
                Container.WaitDisplayed(false, timeout, throwTimedOut: false);
            }
            return this;
        }

        #endregion Load/Dispose
    }
}
