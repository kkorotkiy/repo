﻿using _ = WebComponents.WebControls.WebControlType;


namespace WebComponents.WebForms
{
    public static class WebPageExt
    {
        #region Actions

        #region Dispose

        public static WebSite
            DisposeByClick(
                this WebPage webPage,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) { return webPage.Click(control, caption, timeout).WaitDispose(timeout).Site(); }
                
        public static WebSite
            CloseByClick(
                this WebPage webPage,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            var webSite = webPage.Click(control, caption, timeout).Site();
            webSite.WaitPageClosed(webPage, timeout);
            return webSite;
        }

        public static WebSite
            Close(
                this WebPage webPage,
                ulong timeout = ulong.MinValue
            ) {
            var webSite = webPage.Site();
            webSite.ClosePage(webPage, timeout);
            return webSite;
        }

        #endregion Dispose

        #region SwitchTo

        public static WebPage
            SwitchToPage(
                this WebPage webPage,
                bool waitLoad = true,
                bool force = true,
                ulong timeout = ulong.MinValue
            ) { webPage.Site().SwitchToPage(webPage, waitLoad, force, timeout); return webPage; }

        #endregion SwitchTo

        public static void
            Maximize(
                this WebPage webPage,
                ulong timeout = ulong.MinValue
            ) { WebBrowser.Maximize(timeout); }

        #endregion Actions
    }
}
