﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using LogComponents;
using WebComponents.WebControls;
using WebComponents.WebElements;
using _ = WebComponents.WebControls.WebControlType;


namespace WebComponents.WebForms
{
    public static class WebFormExt
    {
        #region WebElement

        #region Format

        public const string WebElementFormat = (@"[{0}\[{1}, '{2}']]");

        public static string
            FormatElement(
                this WebForm webForm,
                string control,
                object caption = null
            ) { return string.Format(WebElementFormat, webForm.FullName, control, caption); }

        #endregion Format

        #region Displayed

        public static bool
            Exists(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) { return webForm.GetElement(control, caption).Exists(timeout); }

        public static bool
            Displayed(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) { return webForm.GetElement(control, caption).Displayed(timeout); }

        public static bool
            DisplayedAny(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) { return webForm.GetElement(control, caption).DisplayedAny(timeout); }

        #endregion Displayed

        #region Location

        public static int
            Position(
                this WebForm webForm,
                string control,
                object caption = null,
                bool skipNotDisplayed = false,
                string precedingSiblingXPath = WebControlPattern.preceding_sibling,
                ulong timeout = ulong.MinValue
            ) { return webForm.GetElement(control, caption).Position(skipNotDisplayed, precedingSiblingXPath, timeout); }

        #endregion Location

        #endregion WebElement

        #region Actions

        #region Wait

        public static WebForm
            Wait(
                this WebForm webForm,
                ulong timeout = uint.MinValue
            ) {
            WebBrowser.Wait(timeout);
            return webForm;
        }

        public static bool
            Wait(
                this WebForm webForm,
                Func<bool> condition,
                ulong timeout = uint.MinValue,
                bool throwTimedOut = true
            ) { return WebBrowser.Wait(condition, timeout, throwTimedOut); }

        public static bool
            WaitExists(
                this WebForm webForm,
                string control,
                object caption = null,
                bool exists = true,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) { return webForm.GetElement(control, caption).WaitExists(exists, timeout, throwTimedOut); }

        public static bool
            WaitDisplayed(
                this WebForm webForm,
                string control,
                object caption = null,
                bool displayed = true,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) { return webForm.GetElement(control, caption).WaitDisplayed(displayed, timeout, throwTimedOut); }

        public static bool
            WaitDisplayedAny(
                this WebForm webForm,
                string control,
                object caption = null,
                bool displayed = true,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) { return webForm.GetElement(control, caption).WaitDisplayedAny(displayed, timeout, throwTimedOut); }

        #endregion Wait

        #region Focus

        public static WebForm
            GetFocus(
                this WebForm webForm,
                string control = _.self,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            var webElementInfo = webForm.GetElement(control, caption);
            webElementInfo.GetFocus(timeout);
            return webForm;
        }

        #endregion Focus

        #region Check

        public const string
            CheckDisplayedMessageFormat =
                ("Check displayed element: " + WebElementFormat);

        public static WebForm
            CheckDisplayed(
                this WebForm webForm,
                string control,
                object caption = null,
                bool displayed = true,
                ulong timeout = ulong.MinValue,
                string message = null
            ) {
            var webElementInfo = webForm.GetElement(control, caption);
            var isDisplayedValid = webElementInfo.WaitDisplayed(displayed, timeout, throwTimedOut: false);
            var actualDisplayed =
                (!isDisplayedValid && !displayed
                 || isDisplayedValid && displayed
                );
            ValidateValue(
                expectedValue: displayed,
                actualValue: actualDisplayed,
                @equals: true,
                throwOnFailure: true,
                message: (message ?? CheckDisplayedMessageFormat),
                parameters: (new[] {webForm.FullName, control, caption})
                );
            if (actualDisplayed) {
                webElementInfo.GetFocus(timeout);
            }
            return webForm;
        }

        public static WebForm
            CheckExists(
                this WebForm webForm,
                string control,
                object caption = null,
                bool exists = true,
                ulong timeout = ulong.MinValue
            ) {
            var webElementInfo = webForm.GetElement(control, caption);
            webElementInfo.WaitExists(exists, timeout);
            return webForm;
        }

        #endregion Check

        #region Click

        public static WebForm
            Click(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            var webElementInfo = webForm.GetElement(control, caption);
            var webElement = webElementInfo.Find(timeout);
            webElement.Click();
            return webForm;
        }

        public static WebForm
            ClickWithReload(
                this WebForm webForm,
                string control,
                object caption = null,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) { return Click(webForm, control, caption, timeout).WaitLoad(force, timeout); }

        #endregion Click

        #region Expand/Collapse

        #region Expand

        public static WebForm
            ExpandForm(
                this WebForm parentForm,
                string control,
                object caption = null,
                object frame = null,
                bool switchToForm = true,
                bool waitLoad = true,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var webForm = parentForm.GetForm(control, caption, frame, waitLoad: false);
            if (waitLoad) {
                var formIsSelfBody = webForm.Site().IsFormSelfBody(webForm.Control);
                if (formIsSelfBody.HasValue && !formIsSelfBody.Value) {
                    webForm.WaitLoad(force, timeout);
                } else {
                    webForm.SwitchToForm(force, waitReady: true, timeout: timeout);
                }
            }
            webForm.Expand(timeout);
            return (switchToForm ? webForm : parentForm);
        }
        
        public static WebForm
            Expand(
                this WebForm webForm,
                ulong timeout = ulong.MinValue
            ) {
            var webSite = webForm.Site();
            var formBody = webSite.GetFormUsageControl(webForm.Control, usage: "body");
            if (formBody == null) {
                return webForm;
            }
            var byButton = webSite.GetFormUsageControl(webForm.Control, usage: "button-expand");
            if (byButton == null) {
                return webForm;
            }
            return Expand(webForm, formBody, byButton, timeout);
        }

        public static WebForm
            Expand(
                this WebForm webForm,
                string formBody,
                string byButton,
                ulong timeout = ulong.MinValue
            ) {
            webForm.GetFocus(timeout: timeout);
            var body = webForm.GetForm(formBody, webForm.InitialCaption, waitLoad: false);
            var bodyIsDisplayed = body.IsLoaded(timeout: 320UL);
            if (bodyIsDisplayed) {
                return webForm;
            }
            webForm.Click(byButton, webForm.InitialCaption, timeout);
            body.WaitLoad(force: false, timeout: timeout);
            return webForm;
        }

        #endregion Expand

        #region Collapse

        public static WebForm
            CollapseForm(
                this WebForm parentForm,
                string control,
                object caption = null,
                object frame = null,
                bool switchToForm = false,
                bool waitLoad = true,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var webForm = parentForm.GetForm(control, caption, frame, waitLoad: false);
            if (waitLoad) {
                var formIsSelfBody = webForm.Site().IsFormSelfBody(webForm.Control);
                if (formIsSelfBody.HasValue && !formIsSelfBody.Value) {
                    webForm.WaitLoad(force, timeout);
                } else {
                    webForm.SwitchToForm(force, waitReady: true, timeout: timeout);
                }
            }
            webForm.Collapse(timeout);
            return (switchToForm ? webForm : parentForm);
        }

        public static WebForm
            Collapse(
                this WebForm webForm,
                ulong timeout = ulong.MinValue
            ) {
            var webSite = webForm.Site();
            var formBody = webSite.GetFormUsageControl(webForm.Control, usage: "body");
            if (formBody == null) {
                return webForm;
            }
            var byButton = webSite.GetFormUsageControl(webForm.Control, usage: "button-collapse");
            if (byButton == null) {
                return webForm;
            }
            return Collapse(webForm, formBody, byButton, timeout);
        }

        public static WebForm
            Collapse(
                this WebForm webForm,
                string formBody,
                string byButton,
                ulong timeout = ulong.MinValue
            ) {
            webForm.GetFocus(timeout: timeout);
            var body = webForm.GetForm(formBody, webForm.InitialCaption, waitLoad: false);
            var bodyIsDisplayed = body.IsLoaded(timeout: 320UL);
            if (!bodyIsDisplayed) {
                return webForm;
            }
            webForm.Click(byButton, webForm.InitialCaption, timeout);
            body.WaitDispose(timeout);
            return webForm;
        }

        #endregion Collapse

        public static WebForm
            Maximize(
                this WebForm webForm,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var maximizeButtonControl =
                webForm.Site(
                    ).GetFormUsageControl(
                        webForm.Control,
                        usage: "button-maximize"
                    );
            if (maximizeButtonControl == null) {
                return webForm;
            }
            var maximizeButton = webForm.GetElement(maximizeButtonControl);
            if (!maximizeButton.Displayed(timeout)) {
                return webForm;
            }
            maximizeButton.Click(timeout);
            webForm.WaitLoad(force, timeout);
            return webForm;
        }

        public static WebForm
            Restore(
                this WebForm webForm,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var restoreButtonControl =
                webForm.Site(
                    ).GetFormUsageControl(
                        webForm.Control,
                        usage: "button-restore"
                    );
            if (restoreButtonControl == null) {
                return webForm;
            }
            var restoreButton = webForm.GetElement(restoreButtonControl);
            if (!restoreButton.Displayed(timeout)) {
                return webForm;
            }
            restoreButton.Click(timeout);
            webForm.WaitLoad(force, timeout);
            return webForm;
        }        

        #endregion Expand/Collapse

        #region SwitchTo

        public static WebPage
            Page(
                this WebForm webForm,
                bool waitLoad = false,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) { return webForm.Site().Page(waitLoad, force, timeout); }

        public static WebSite
            Site(
                this WebForm webForm
            ) { return WebBrowser.WebSite; }

        #endregion SwitchTo

        #region Positioning

        public static WebForm
            WithPositioning(
                this WebForm webForm,
                object arg
            ) {
            webForm.PositioningArg = arg;
            return webForm;
        }

        public static WebForm
            ClearPositioning(
                this WebForm webForm
            ) { return WithPositioning(webForm, null); }

        #endregion Positioning

        #region Dispose

        public static WebForm
            Close(
                this WebForm webForm,
                bool waitLoad = false,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var closeButton =
                webForm.Site(
                    ).GetFormUsageControl(
                        webForm.Control,
                        usage: "button-close"
                    );
            if (closeButton == null) {
                return webForm;
            }
            return
                webForm.
                    DisposeByClick(
                        control: closeButton,
                        waitLoad: waitLoad,
                        force: force,
                        timeout: timeout
                    );
            }

        public static WebForm
            DisposeByClick(
                this WebForm webForm,
                string control,
                object caption = null,
                bool waitLoad = false,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            return
                webForm.
                    Click(control, caption, timeout).
                    WaitDispose(timeout).
                    SwitchToParentForm(waitLoad, force, timeout);
        }

        #endregion Dispose

        #endregion Actions

        #region VRCE Value

        #region Validate Value
        
        public const string
            ValidateValueMessageFormat =
                ("Validate value of element: " + WebElementFormat);
        
        #region ValidateTextBoxValue

        public static WebForm
            ValidateTextBoxValue<
                TValue>(
                this WebForm webForm,
                TValue expectedValue,
                string control,
                object caption = null,
                bool @equals = true,
                ulong timeout = ulong.MinValue,
                string message = null
            ) {
            bool isValid;
            return
                ValidateTextBoxValue(
                    webForm,
                    out isValid,
                    expectedValue,
                    @equals,
                    control,
                    caption,
                    timeout,
                    throwOnFailure: true,
                    message: message
                    );
        }

        public static WebForm
            ValidateTextBoxValue<
                TValue>(
                this WebForm webForm,
                out bool isValid,
                TValue expectedValue,
                bool @equals,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue,
                bool throwOnFailure = true,
                string message = null
            ) {
            var actualValue =
                ReadTextBoxValue<
                    TValue>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
            isValid =
                ValidateValue(
                    expectedValue,
                    actualValue,
                    @equals,
                    throwOnFailure,
                    (message ?? ValidateValueMessageFormat),
                    parameters: (new[] {webForm.FullName, control, caption})
                    );
            return
                webForm;
        }

        #endregion ValidateTextBoxValue

        #region ValidateCheckBoxValue

        public static WebForm
            ValidateCheckBoxValue(
                this WebForm webForm,
                bool? expectedValue,
                string control,
                object caption = null,
                bool @equals = true,
                ulong timeout = ulong.MinValue,
                string message = null
            ) {
            bool isValid;
            return
                ValidateCheckBoxValue(
                    webForm,
                    out isValid,
                    expectedValue,
                    @equals,
                    control,
                    caption,
                    timeout,
                    throwOnFailure: true,
                    message: message
                    );
        }

        public static WebForm
            ValidateCheckBoxValue(
                this WebForm webForm,
                out bool isValid,
                bool? expectedValue,
                bool @equals,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue,
                bool throwOnFailure = true,
                string message = null
            ) {
            var actualValue =
                ReadCheckBoxValue(
                    webForm,
                    control,
                    caption,
                    timeout
                    );
            isValid =
                ValidateValue(
                    expectedValue,
                    actualValue,
                    @equals,
                    throwOnFailure,
                    (message ?? ValidateValueMessageFormat),
                    parameters: (new[] {webForm.FullName, control, caption})
                    );
            return
                webForm;
        }

        #endregion ValidateCheckBoxValue

        #region ValidateDropBoxValue

        public static WebForm
            ValidateDropBoxValue<
                TValue>(
                this WebForm webForm,
                TValue expectedValue,
                string control,
                object caption = null,
                bool @equals = true,
                ulong timeout = ulong.MinValue,
                string message = null
            ) {
            bool isValid;
            return
                ValidateDropBoxValue(
                    webForm,
                    out isValid,
                    expectedValue,
                    @equals,
                    control,
                    caption,
                    timeout,
                    throwOnFailure: true,
                    message: message
                    );
        }

        public static WebForm
            ValidateDropBoxValue<
                TValue>(
                this WebForm webForm,
                out bool isValid,
                TValue expectedValue,
                bool @equals,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue,
                bool throwOnFailure = true,
                string message = null
            ) {
            var actualValue =
                ReadDropBoxValue<
                    TValue>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
            isValid =
                ValidateValue(
                    expectedValue,
                    actualValue,
                    @equals,
                    throwOnFailure,
                    (message ?? ValidateValueMessageFormat),
                    parameters: (new[] {webForm.FullName, control, caption})
                    );
            return
                webForm;
        }

        #endregion ValidateDropBoxValue

        #region ValidateElementValue

        public static WebForm
            ValidateElementValue<
                TValue>(
                this WebForm webForm,
                TValue expectedValue,
                string control,
                object caption = null,
                bool @equals = true,
                ulong timeout = ulong.MinValue,
                string message = null
            ) {
            return
                ValidateElementValue<
                    TValue,
                    WebElement>(
                        webForm,
                        expectedValue,
                        control,
                        caption,
                        @equals,
                        timeout,
                        message
                    );
        }

        public static WebForm
            ValidateElementValue<
                TValue>(
                this WebForm webForm,
                out bool isValid,
                TValue expectedValue,
                bool @equals,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue,
                bool throwOnFailure = true,
                string message = null
            ) {
            return
                ValidateElementValue<
                    TValue,
                    WebElement>(
                        webForm,
                        out isValid,
                        expectedValue,
                        @equals,
                        control,
                        caption,
                        timeout,
                        throwOnFailure,
                        message
                    );
        }

        
        public static WebForm
            ValidateElementValue<
                TValue,
                TWebElement>(
                this WebForm webForm,
                TValue expectedValue,
                string control,
                object caption = null,
                bool @equals = true,
                ulong timeout = ulong.MinValue,
                string message = null
            ) where TWebElement : WebElement {
            bool isValid;
            return
                ValidateElementValue<
                    TValue,
                    TWebElement>(
                        webForm,
                        out isValid,
                        expectedValue,
                        @equals,
                        control,
                        caption,
                        timeout,
                        throwOnFailure: true,
                        message: message
                    );
        }

        public static WebForm
            ValidateElementValue<
                TValue,
                TWebElement>(
                this WebForm webForm,
                out bool isValid,
                TValue expectedValue,
                bool @equals,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue,
                bool throwOnFailure = true,
                string message = null
            ) where TWebElement : WebElement {
            var actualValue =
                ReadElementValue<
                    TValue,
                    TWebElement>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
            isValid =
                ValidateValue(
                    expectedValue,
                    actualValue,
                    @equals,
                    throwOnFailure,
                    (message ?? ValidateValueMessageFormat),
                    parameters: (new[] {webForm.FullName, control, caption})
                    );
            return
                webForm;
        }

        #endregion ValidateElementValue

        public static bool
            ValidateValue<
                TValue>(
                TValue expectedValue,
                TValue actualValue,
                bool @equals,
                bool throwOnFailure = true,
                string message = null,
                params object[] parameters
            ) {
            bool isValid;
            try {
                if (@equals) {
                    Assert.AreEqual(expectedValue, actualValue, message, parameters);
                } else {
                    Assert.AreNotEqual(expectedValue, actualValue, message, parameters);
                }
                isValid = true;
            } catch (Exception exception) {
                isValid = false;
                if (!string.IsNullOrWhiteSpace(message)) {
                    message = string.Format(message, parameters);
                }
                if (throwOnFailure) {
                    LogManager.LogRecord(message, exception, LogRecordType.ERROR, takeScreenshot: true);
                    throw;
                }
                LogManager.LogRecord(message, exception, LogRecordType.WARNING, takeScreenshot: true);
            }
            return isValid;
        }

        #endregion Validate Value

        #region Read Value

        public static TValue
            ReadTextBoxValue<
                TValue>(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                ReadElementValue<
                    TValue,
                    TextBoxWebElement>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
        }

        public static bool?
            ReadCheckBoxValue(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                ReadElementValue<
                    bool?,
                    CheckBoxWebElement>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
        }

        public static TValue
            ReadDropBoxValue<
                TValue>(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                ReadElementValue<
                    TValue,
                    DropBoxWebElement>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
        }

        #region ReadElementValue

        public static TValue
            ReadElementValue<
                TValue>(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                ReadElementValue<
                    TValue,
                    WebElement>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
        }

        public static TValue
            ReadElementValue<
                TValue,
                TWebElement>(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) where TWebElement: WebElement {
            var webElementInfo = webForm.GetElement<TWebElement>(control, caption);
            var webElement = webElementInfo.Find<TWebElement>(timeout);
            var value = webElement.ReadValue<TValue>();
            return value;
        }

        #endregion ReadElementValue

        #endregion Read Value

        #region Clear Value

        public static WebForm
            ClearTextBoxValue(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                ClearElementValue<
                    TextBoxWebElement>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
        }

        public static WebForm
            ClearCheckBoxValue(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                ClearElementValue<
                    CheckBoxWebElement>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
        }

        public static WebForm
            ClearDropBoxValue(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                ClearElementValue<
                    DropBoxWebElement>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
        }

        #region ClearElementValue

        public static WebForm
            ClearElementValue(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                ClearElementValue<
                    WebElement>(
                        webForm,
                        control,
                        caption,
                        timeout
                    );
        }

        public static WebForm
            ClearElementValue<
                TWebElement>(
                this WebForm webForm,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) where TWebElement : WebElement {
            var webElementInfo = webForm.GetElement<TWebElement>(control, caption);
            var webElement = webElementInfo.Find<TWebElement>(timeout);
            webElement.ClearValue();
            return webForm;
        }

        #endregion ClearElementValue

        #endregion Clear Value

        #region Enter Value

        public static WebForm
            EnterTextBoxValue<
                TValue>(
                this WebForm webForm,
                TValue value,
                string control,
                object caption = null,
                bool clear = true,
                bool submit = false,
                ulong timeout = ulong.MinValue
            ) {
            if (ReferenceEquals(value, null)) {
                return webForm;
            }
            var textBoxInfo = webForm.GetElement<TextBoxWebElement>(control, caption);
            var textBox = textBoxInfo.Find<TextBoxWebElement>(timeout);
            textBox.EnterValue(value, clear);
            if (submit) {
                textBox.EnterValue(Keys.Enter, clear: false);
            }
            return webForm;
        }

        public static WebForm
            EnterCheckBoxValue(
                this WebForm webForm,
                bool? value,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                EnterElementValue<
                    bool?,
                    CheckBoxWebElement>(
                        webForm,
                        value,
                        control,
                        caption,
                        timeout
                    );
        }

        #region EnterDropBoxValue

        public static WebForm
            EnterDropBoxValue<
                TValue>(
                this WebForm webForm,
                TValue value,
                bool dropDown = true,
                ulong timeout = ulong.MinValue
            ) {
            return
                EnterDropBoxValue(
                    webForm,
                    value,
                    _.DropBox,
                    value,
                    dropDown,
                    timeout
                    );
        }
        
        public static WebForm
            EnterDropBoxValue<
                TValue>(
                this WebForm webForm,
                TValue value,
                string control,
                object caption = null,
                bool dropDown = true,
                ulong timeout = ulong.MinValue
            ) {
            if (ReferenceEquals(value, null)) {
                return webForm;
            }
            var dropBoxInfo = webForm.GetElement<DropBoxWebElement>(control, caption);
            var dropBox = dropBoxInfo.Find<DropBoxWebElement>(timeout);
            dropBox.EnterValue(value, dropDown);
            return webForm;
        }

        #endregion EnterDropBoxValue

        #region EnterElementValue

        public static WebForm
            EnterElementValue<
                TValue>(
                this WebForm webForm,
                TValue value,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) {
            return
                EnterElementValue<
                    TValue,
                    WebElement>(
                        webForm,
                        value,
                        control,
                        caption,
                        timeout
                    );
        }

        public static WebForm
            EnterElementValue<
                TValue,
                TWebElement>(
                this WebForm webForm,
                TValue value,
                string control,
                object caption = null,
                ulong timeout = ulong.MinValue
            ) where TWebElement : WebElement {
            if (ReferenceEquals(value, null)) {
                return webForm;
            }
            var webElementInfo = webForm.GetElement<TWebElement>(control, caption);
            var webElement = webElementInfo.Find<TWebElement>(timeout);
            webElement.EnterValue(value);
            return webForm;
        }

        #endregion EnterElementValue

        #endregion Enter Value

        #endregion VRCE Value
    }
}
