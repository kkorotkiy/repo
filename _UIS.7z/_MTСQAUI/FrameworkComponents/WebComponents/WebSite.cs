﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using UtilityComponents;
using WebComponents.WebControls;
using WebComponents.WebElements;
using WebComponents.WebForms;
using _ = WebComponents.WebControls.WebControlType;
using appConfig = System.Configuration.ConfigurationManager;


namespace WebComponents
{
    public class WebSite
    {
        #region Exceptions

        private const string CannotNavigateNotLoadedWebSiteException = ("Cannot navigate to webPage[alias:'{0}']. {1} is not loaded.");
        private const string CantFindWebPageByAliasException = ("Can't find webPage[alias:'{0}']");
        private const string WebPageNotOpenedException = ("Wait opened page[alias:'{0}']");

        #endregion Exceptions

        #region Properties and Fields

        public const string DefaultUrl = (@"http://localhost");
        public virtual string Url { get { return (_url ?? (_url = DefaultUrl)); } }
        private string _url;


        public const string DefaultWebControlsDirectoryPath = (@"WebControls");
        public virtual string WebControlsDirectoryPath {
            get {
                if (_webControlsDirectoryPath == null) {
                    _webControlsDirectoryPath = Environment
                        .ExpandEnvironmentVariables(appConfig.AppSettings["WebControlsDirectoryPath"]);
                    if (string.IsNullOrWhiteSpace(_webControlsDirectoryPath)) {
                        _webControlsDirectoryPath = DefaultWebControlsDirectoryPath;
                    }
                    _webControlsDirectoryPath = Path.GetFullPath(_webControlsDirectoryPath);
                }
                return _webControlsDirectoryPath;
            }
        }
        private string _webControlsDirectoryPath;

        public virtual string[] WebControlsFiles {
            get {
                if (_webControlsFiles == null) {
                    if (Directory.Exists(WebControlsDirectoryPath)) {
                        _webControlsFiles = Directory.GetFiles(WebControlsDirectoryPath);
                    } else {
                        _webControlsFiles = (new string[0]);
                    }
                }
                return _webControlsFiles;
            }
        }
        private string[] _webControlsFiles;


        private const string FullNameFormat = (@"{0}[url:""{1}""]");
        public string Name { get; private set; }
        public string FullName { get { return (_fullName ?? (_fullName = string.Format(FullNameFormat, Name, Url))); } }
        private string _fullName;

        public override string ToString() { return FullName; }

        #endregion Properties and Fields        

        #region Factory Methods

        protected WebSite() {
            _controls =
                (new Dictionary<string, string> {
                    #region Pages
                    {_.Page, WebControlPattern.Page},
                    {_.PageTitle, WebControlPattern.PageTitle},
                    #endregion Pages
                    #region Frames
                    {_.Frame, WebControlPattern.Frame},
                    #endregion Frames
                    #region Elements
                    #region Any
                    {_.Any, WebControlPattern.Any},
                    {_.Any_ById, WebControlPattern.Any_ById},
                    #endregion Any
                    #region Label
                    {_.div, WebControlPattern.div},
                    {_.span, WebControlPattern.span},
                    {_.td, WebControlPattern.td},
                    {_.ul, WebControlPattern.ul},
                    {_.b, WebControlPattern.b},
                    {_.br, WebControlPattern.br},
                    {_.strong, WebControlPattern.strong},
                    {_.label, WebControlPattern.label},
                    {_.Label, WebControlPattern.Label},
                    #endregion Label
                    #region Image
                    {_.img, WebControlPattern.img},
                    {_.Image, WebControlPattern.Image},
                    #endregion Image
                    #region Link
                    {_.a, WebControlPattern.a},
                    {_.Link, WebControlPattern.Link},
                    {_.Link_ByTooltip, WebControlPattern.Link_ByTooltip},
                    {_.LinkImage, WebControlPattern.LinkImage},
                    {_.LinkImage_ByTooltip, WebControlPattern.LinkImage_ByTooltip},
                    #endregion Link
                    #region Button
                    {_.button, WebControlPattern.button},
                    {_.Button, WebControlPattern.Button},
                    #endregion Button
                    #region Input
                    {_.input, WebControlPattern.input},
                    #endregion Input
                    #region CheckBox
                    {_.CheckBox, WebControlPattern.CheckBox},
                    #endregion CheckBox
                    #region TextBox
                    {_.TextBox, WebControlPattern.TextBox},
                    #endregion TextBox
                    #region DropBox
                    {_.DropBox, WebControlPattern.DropBox},
                    {_.DropBoxElement, WebControlPattern.DropBoxElement},
                    #endregion DropBox
                    #endregion Elements
                    #region Axes
                    {_.parent, WebControlPattern.parent},
                    {_.preceding_sibling, WebControlPattern.preceding_sibling},
                    {_.self, WebControlPattern.self},
                    {_.following_sibling, WebControlPattern.following_sibling},
                    {_.last_child, WebControlPattern.last_child},
                    {_.descendant_or_self, WebControlPattern.descendant_or_self},
                    #endregion Axes
                });
            _forms = (new List<XElement>(0));
            _pages = (new List<XElement>(0));
        }

        internal static TWebSite CreateInstance<TWebSite>(string url = null) where TWebSite : WebSite
        {
            var webSiteType = typeof(TWebSite);
            var webSite = ((TWebSite) Activator.CreateInstance(webSiteType, nonPublic: true));
            webSite._url = url;
            webSite.Name = webSiteType.Name;
            return webSite;
        }

        #endregion Factory Methods

        #region Load/Unload

        public bool IsLoaded { get; protected set; }

        protected internal void Load(bool force = false )
        {
            if (force || !IsLoaded) {
                ProcessLoad();
                IsLoaded = true;
            }
        }

        protected virtual void ProcessLoad(bool force = false) { LoadControls(); }

        protected virtual void LoadControls() { 
            foreach (var filePath in WebControlsFiles) {
                LoadControlsFromFile(filePath, _controls, _forms, _pages);
            }
        }

        protected virtual void
            LoadControlsFromFile(
                string filePath,
                Dictionary<string, string> controls,
                List<XElement> forms,
                List<XElement> pages
            ) {
            var webControlsDoc = XDocument.Load(filePath);
            Debug.Assert((webControlsDoc.Root != null), "webControlsDoc.Root != null");
            var webForms = webControlsDoc.Root.Elements("WebForm").ToArray();
            forms.AddRange(webForms);
            var webPages = webControlsDoc.Root.Elements("WebPage").ToArray();
            pages.AddRange(webPages);
            var webFormControls = webForms.SelectMany(form => form.Elements("WebControl"));
            var webPageControls = webPages.SelectMany(page => page.Elements("WebControl"));
            var webControls = webControlsDoc.Root.Elements("WebControl").Concat(webFormControls).Concat(webPageControls);
            foreach (var webControl in webControls) {
                var webControlType = webControl.Elements("WebControlType").Single().Value;
                var webControlPattern = webControl.Elements("WebControlPattern").Single().Value;
                controls.Set(webControlType, webControlPattern);
            }
        }


        protected internal void Unload(bool force = false)
        {
            if (force || IsLoaded) {
                ProcessUnload(force);
                IsLoaded = false;
            }
        }

        protected virtual void ProcessUnload(bool force = false)
        {
            _controls.Clear();
            _forms.Clear();
            _pages.Clear();
        }

        #endregion Load/Unload

        #region Caption

        public const string DefaultCaptionSeparator = ("~");

        public virtual string CaptionSeparator {
            get {
                if (_captionSeparator == null) {
                    _captionSeparator = DefaultCaptionSeparator;
                }
                return _captionSeparator;
            }
        }
        private string _captionSeparator;

        public virtual string FormatCaption(object caption, bool toUpper = false)
        {
            object[] captionArray = Cast.AsArray<object>(caption, emptyOnNull: true);
            var captionStr = String.Join(CaptionSeparator, captionArray);
            if (toUpper) {
                captionStr = captionStr.ToUpper();
            }
            return captionStr;
        }

        public virtual object[] LocalizeCaption(params object[] captions) { return captions; }

        #endregion Caption
        
        #region Controls

        public virtual IEnumerable<string> ControlTypes { get { return _controls.Keys; } }
        public virtual IEnumerable<string> ControlPatterns { get { return _controls.Values; } }
        protected Dictionary<string, string> _controls;

        public virtual string GetXPath(string control)
        {
            string xPath;
            if (_controls.ContainsKey(control)) {
                xPath = _controls[control];
            } else {
                xPath = control;
            }
            return xPath;
        }

        public virtual string GetXPath(params string[] controls) {
            return string.Concat(controls.Select(GetXPath));
        }

        public virtual string FormatXPath(string control, object caption)
        {
            object[] captionArray = Cast.AsArray<object>(caption, emptyOnNull: true);
            return FormatXPath(control, captionArray);
        }

        public virtual string FormatXPath(string control, params object[] captions)
        {
            if (_controls.ContainsKey(control)) {
                control = _controls[control];
            }
            captions = LocalizeCaption(captions);
            var xPath = string.Format(control, captions);
            return xPath;
        }

        #endregion Controls

        #region Form Controls

        protected List<XElement> _forms;

        protected virtual XElement GetXForm(string formControl)
        {
            var formControls = _forms.SelectMany(form => form.Elements("WebControl"));
            var formContainerControl =
                formControls.FirstOrDefault(
                    fc =>
                    ((fc.GetAttributeValue("form-usage") == "container")
                     && (fc.Elements("WebControlType").Single().Value == formControl))
                    );
            if (formContainerControl == null) {
                return null;
            }
            return formContainerControl.Parent;
        }

        public virtual string GetFormUsageControl(string formControl, string usage)
        {
            var xForm = GetXForm(formControl);
            if (xForm == null) {
                return null;
            }
            var formControls = xForm.Elements("WebControl");
            var formUsageControl = formControls.FirstOrDefault(control => (control.GetAttributeValue("form-usage") == usage));
            if (formUsageControl == null) {
                return null;
            }
            var formUsageControlType = formUsageControl.Elements("WebControlType").Single().Value;
            return formUsageControlType;
        }

        public virtual bool? IsFormSelfBody(string formControl)
        {
            var formBodyControl = GetFormUsageControl(formControl, usage: "body");
            if (formBodyControl == null) {
                return null;
            }
            var formBodyPattern = GetXPath(formBodyControl);
            var isFormSelfBody =
                ((formBodyPattern == WebControlPattern.self)
                 || (formBodyPattern == string.Empty)
                );
            return isFormSelfBody;
        }


        protected List<XElement> _pages;

        protected virtual XElement GetXPage(string pageControl)
        {
            var pageControls = _pages.SelectMany(page => page.Elements("WebControl"));
            var pageBodyControl =
                pageControls.FirstOrDefault(
                    pc =>
                    ((pc.GetAttributeValue("form-usage") == "body")
                     && (pc.Elements("WebControlType").Single().Value == pageControl))
                    );
            if (pageBodyControl == null) {
                return null;
            }
            return pageBodyControl.Parent;
        }
        
        public virtual string GetPageUrl(string pageControl)
        {
            var xPage = GetXPage(pageControl);
            var url = xPage.GetAttributeValue<string>("url");
            return url;
        }

        #endregion Form Controls

        #region Pages

        protected readonly Dictionary<string, WebPage> Pages = (new Dictionary<string, WebPage>());
        protected virtual WebPage MainPage { get { return Pages[WebBrowser.MainWindowHandle]; } }
        protected virtual WebPage CurrentPage { get { return Pages[WebBrowser.CurrentWindowHandle]; } }

        protected virtual WebPage GetPage(string alias)
        {
            alias = alias.ToUpper();
            var webPage = Pages.Values.FirstOrDefault(page => (page.Alias == alias));
            Assert.IsNotNull(webPage, CantFindWebPageByAliasException, alias);
            return webPage;
        }

        #region LoadPage

        public virtual bool
            IsPageLoaded(
                string control,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            Assert.IsTrue(IsLoaded, CannotNavigateNotLoadedWebSiteException, control, FullName);
            if (!Pages.ContainsKey(WebBrowser.CurrentWindowHandle)) {
                return false;
            }
            var currentPage = Pages[WebBrowser.CurrentWindowHandle];
            var isPageLoaded = ((currentPage.Control == control) && currentPage.IsLoaded(force, timeout));
            return isPageLoaded;
        }

        public virtual WebPage
            LoadPageFromUrl(
                string url,
                string control = _.Page,
                string alias = null,
                ulong timeout = ulong.MinValue
            ) {
            if (alias == null) {
                alias = ((control != _.Page) ? control : url);
            }
            alias = alias.ToUpper();
            Assert.IsTrue(IsLoaded, CannotNavigateNotLoadedWebSiteException, alias, FullName);
            var webPage = (new WebPage(alias, WebBrowser.CurrentWindowHandle, control, url));
            WebBrowser.Navigate(webPage.Url);
            webPage.WaitLoad(force: true, timeout: timeout);
            Pages.Set(webPage.WindowHandle, webPage);
            return webPage;
        }

        public virtual WebPage
            LoadPage(
                string control,
                string alias = null,
                ulong timeout = ulong.MinValue
            ) { return LoadPageFromUrl(GetPageUrl(control), control, alias, timeout); }

        public virtual WebPage
            WaitPageLoaded(
                string control = _.Page,
                string alias = null,
                ulong timeout = ulong.MinValue
            ) {
            if (alias == null) {
                alias = control;
            }
            alias = alias.ToUpper();
            Assert.IsTrue(IsLoaded, CannotNavigateNotLoadedWebSiteException, alias, FullName);
            var webPage = (new WebPage(alias, WebBrowser.CurrentWindowHandle, control));
            webPage.WaitLoad(force: true, timeout: timeout);
            Pages.Set(webPage.WindowHandle,webPage);
            return webPage;
        }

        public virtual WebPage
            WaitPageOpened(
                string control = _.Page,
                string alias = null,
                ulong timeout = ulong.MinValue
            ) {
            if (alias == null) {
                alias = control;
            }
            alias = alias.ToUpper();
            Assert.IsTrue(IsLoaded, CannotNavigateNotLoadedWebSiteException, alias, FullName);
            string windowHandle;
            var isWindowOpened = WebBrowser.SwitchToOpenedWindow(out windowHandle, timeout);
            Assert.IsTrue(isWindowOpened, WebPageNotOpenedException, alias);
            var webPage = (new WebPage(alias, windowHandle, control));
            webPage.WaitLoad(force: true, timeout: timeout);
            webPage.Container.Click(timeout, throwNotFound: false);
            Pages.Add(webPage.WindowHandle, webPage);
            return webPage;
        }

        #endregion LoadPage

        #region SwitchToPage

        public virtual WebPage
            Page(
                bool waitLoad = false,
                bool force = false,
                ulong timeout = ulong.MinValue
            ) {
            var currentPage = CurrentPage;
            if (waitLoad) {
                currentPage.WaitLoad(force, timeout);
            } else {
                currentPage.SwitchToForm();
            }
            return currentPage;
        }

        public virtual WebPage
            SwitchToPage(
                string alias,
                bool waitLoad = true,
                bool force = true,
                ulong timeout = ulong.MinValue
            ) {
            var webPage = GetPage(alias);
            SwitchToPage(webPage, waitLoad, force, timeout);
            return webPage;
        }

        public virtual WebPage
            SwitchToMainPage(
                bool waitLoad = true,
                bool force = true,
                ulong timeout = ulong.MinValue
            ) {
            var mainPage = MainPage;
            SwitchToPage(mainPage, waitLoad, force, timeout);
            return mainPage;
        }

        public virtual bool
            SwitchToPage(
                WebPage webPage,
                bool waitLoad = true,
                bool force = true,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            Assert.IsTrue(IsLoaded, CannotNavigateNotLoadedWebSiteException, webPage.Alias, FullName);
            var isPageReady = WebBrowser.SwitchToWindow(webPage.WindowHandle, timeout, throwTimedOut);
            var isPageLoaded = !waitLoad;
            if (!isPageLoaded) {
                if (throwTimedOut) {
                    webPage.WaitLoad(force, timeout);
                    isPageLoaded = true;
                } else {
                    isPageLoaded = webPage.IsLoaded(force, timeout);
                }
            }
            isPageReady = (isPageReady && isPageLoaded);
            return isPageReady;
        }

        #endregion SwitchToPage

        #region ClosePage

        public virtual WebSite
            ClosePage(
                string alias,
                ulong timeout = ulong.MinValue
            ) { ClosePage(GetPage(alias), timeout); return this; }

        public virtual WebSite
            ClosePage(
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) { ClosePage(CurrentPage, timeout); return this; }

        public virtual bool
            ClosePage(
                WebPage webPage,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            Assert.IsTrue(
                IsLoaded,
                CannotNavigateNotLoadedWebSiteException,
                webPage.Alias, FullName
                );            
            var windowHandle = webPage.WindowHandle;
            var windowClosed = WebBrowser.CloseWindow(windowHandle, timeout, throwTimedOut);
            var pageFinalized = Pages.Remove(windowHandle);
            var pageClosed = (windowClosed && pageFinalized);
            return pageClosed;
        }


        public virtual WebSite
            WaitPageClosed(
                string alias,
                ulong timeout = ulong.MinValue
            ) { WaitPageClosed(GetPage(alias), timeout); return this; }

        public virtual bool
            WaitPageClosed(
                WebPage webPage,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) {
            Assert.IsTrue(IsLoaded, CannotNavigateNotLoadedWebSiteException, webPage.Alias, FullName);
            var windowHandle = webPage.WindowHandle;
            var windowClosed = WebBrowser.WaitWindowClosed(windowHandle, timeout, throwTimedOut);
            var pageFinalized = Pages.Remove(windowHandle);
            var pageClosed = (windowClosed && pageFinalized);
            return pageClosed;
        }

        #endregion ClosePage

        #endregion Pages

        #region Forms

        protected internal virtual bool
            WaitWebFormLoaded(
                WebForm webForm,
                ulong timeout = ulong.MinValue,
                bool throwTimedOut = true
            ) { return true; }

        #endregion Forms
    }
}