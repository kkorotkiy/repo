﻿using System;


namespace UtilityComponents
{
    public static class ArrayExt
    {
        public static void Add<TIn>(ref TIn[] array, params TIn[] items)
        {
            var itemsLength = items.Length;
            if (itemsLength < 1) {
                return;
            }
            var arrayLength = array.Length;
            var arrayNewLength = (arrayLength + itemsLength);
            Array.Resize(ref array, arrayNewLength);
            Array.Copy(items, 0, array, arrayLength, itemsLength);
        }

        public static void Insert<TIn>(ref TIn[] array, int index, params TIn[] items)
        {
            var itemsLength = items.Length;
            if (itemsLength < 1) {
                return;
            }
            var arrayLength = array.Length;
            if (arrayLength < 1) {
                Add(ref array, items);
                return;
            }
            if ((index < 0) || (arrayLength <= index)) {
                throw (new IndexOutOfRangeException());
            }
            var arrayNewLength = (arrayLength + itemsLength);
            var shiftLength = (arrayLength - index);
            Array.Resize(ref array, arrayNewLength);
            Array.Reverse(array);
            Array.Copy(array, itemsLength, array, 0, shiftLength);
            Array.Reverse(array);
            Array.Copy(items, 0, array, index, itemsLength);
        }

        public static void RemoveAt<TIn>(ref TIn[] array, int index)
        {
            var arrayLength = array.Length;
            if ((index < 0) || (arrayLength <= index)) {
                throw (new IndexOutOfRangeException());
            }
            var arrayNewLength = (arrayLength - 1);
            var shiftLength = (arrayNewLength - index);
            var shiftIndex = (index + 1);
            Array.Copy(array, shiftIndex, array, index, shiftLength);
            Array.Resize(ref array, arrayNewLength);
        }

        public static TIn[] Copy<TIn>(this TIn[] array)
        {
            var arrayLength = array.Length;
            var arrayCopy = (new TIn[arrayLength]);
            Array.Copy(array, arrayCopy, arrayLength);
            return arrayCopy;
        }

        public static void Expand<TIn>(ref TIn[] array)
        {
            for (var index = 0; index < array.Length; index++) {
                var item = array[index];
                if (!ReferenceEquals(item, null) && item.GetType().IsArray) {
                    var itemArray = Cast.AsArray<TIn>(item);
                    Insert(ref array, index, itemArray);
                    var shiftIndex = (index + itemArray.Length);
                    RemoveAt(ref array, shiftIndex);
                    --index;
                }
            }
        }
    }
}
