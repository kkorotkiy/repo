﻿using System;
using System.ComponentModel;
using System.ServiceProcess;


namespace UtilityComponents
{
    public static class ServiceExt
    {
        #region Start

        public static ServiceControllerStatus
            Start(
                string machineName,
                string serviceName,
                ulong timeout,
                bool throwTimedOut = true,
                params string[] args
            ) {
            var timespan = TimeSpan.FromMilliseconds(timeout);
            using (var service = (new ServiceController(serviceName, machineName))) {
                service.Refresh();
                var serviceStatus = service.Status;
                switch (serviceStatus) {
                    case ServiceControllerStatus.Running: {
                        return serviceStatus;
                    }
                    case ServiceControllerStatus.StartPending:
                    case ServiceControllerStatus.ContinuePending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Running, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                        }
                        break;
                    }
                    case ServiceControllerStatus.PausePending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Paused, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                            break;
                        }
                        goto case ServiceControllerStatus.Paused;
                    }
                    case ServiceControllerStatus.StopPending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Stopped, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                            break;
                        }
                        goto case ServiceControllerStatus.Stopped;
                    }
                    case ServiceControllerStatus.Paused: {
                        try {
                            service.Continue();
                            service.WaitForStatus(ServiceControllerStatus.Running, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                        }
                        break;
                    }
                    case ServiceControllerStatus.Stopped: {
                        try {
                            service.Start(args);
                            service.WaitForStatus(ServiceControllerStatus.Running, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                        }
                        break;
                    }
                    default: {
// ReSharper disable NotResolvedInText
                        throw (new InvalidEnumArgumentException("serviceStatus", (int)serviceStatus, typeof(ServiceControllerStatus)));
// ReSharper restore NotResolvedInText
                    }
                }
                service.Refresh();
                serviceStatus = service.Status;
                return serviceStatus;
            }
        }

        public static ServiceControllerStatus
            StartLocal(
                string serviceName,
                ulong timeout,
                bool throwTimedOut = true,
                params string[] args
            ) { return Start(Environment.MachineName, serviceName, timeout, throwTimedOut, args); }

        #endregion Start

        #region Pause

        public static ServiceControllerStatus
            Pause(
                string machineName,
                string serviceName,
                ulong timeout,
                bool throwTimedOut = true
            ) {
            var timespan = TimeSpan.FromMilliseconds(timeout);
            using (var service = (new ServiceController(serviceName, machineName))) {
                service.Refresh();
                var serviceStatus = service.Status;
                switch (serviceStatus) {
                    case ServiceControllerStatus.Stopped:
                    case ServiceControllerStatus.Paused: {
                        return serviceStatus;
                    }
                    case ServiceControllerStatus.StartPending:
                    case ServiceControllerStatus.ContinuePending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Running, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                            break;
                        }
                        goto case ServiceControllerStatus.Running;
                    }
                    case ServiceControllerStatus.PausePending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Paused, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                        }
                        break;
                    }
                    case ServiceControllerStatus.StopPending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Stopped, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                        }
                        break;
                    }
                    case ServiceControllerStatus.Running: {
                        try {
                            service.Pause();
                            service.WaitForStatus(ServiceControllerStatus.Paused, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                        }
                        break;
                    }
                    default: {
// ReSharper disable NotResolvedInText
                        throw (new InvalidEnumArgumentException("serviceStatus", (int)serviceStatus, typeof(ServiceControllerStatus)));
// ReSharper restore NotResolvedInText
                    }
                }
                service.Refresh();
                serviceStatus = service.Status;
                return serviceStatus;
            }
        }

        public static ServiceControllerStatus
            PauseLocal(
                string serviceName,
                ulong timeout,
                bool throwTimedOut = true
            ) { return Pause(Environment.MachineName, serviceName, timeout, throwTimedOut); }

        #endregion Pause

        #region Resume

        public static ServiceControllerStatus
            Resume(
                string machineName,
                string serviceName,
                ulong timeout,
                bool throwTimedOut = true
            ) {
            var timespan = TimeSpan.FromMilliseconds(timeout);
            using (var service = (new ServiceController(serviceName, machineName))) {
                service.Refresh();
                var serviceStatus = service.Status;
                switch (serviceStatus) {
                    case ServiceControllerStatus.Stopped:
                    case ServiceControllerStatus.Running: {
                        return serviceStatus;
                    }
                    case ServiceControllerStatus.StartPending:
                    case ServiceControllerStatus.ContinuePending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Running, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                        }
                        break;
                    }
                    case ServiceControllerStatus.PausePending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Paused, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                            break;
                        }
                        goto case ServiceControllerStatus.Paused;
                    }
                    case ServiceControllerStatus.StopPending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Stopped, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                        }
                        break;
                    }
                    case ServiceControllerStatus.Paused: {
                        try {
                            service.Continue();
                            service.WaitForStatus(ServiceControllerStatus.Running, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                        }
                        break;
                    }
                    default: {
// ReSharper disable NotResolvedInText
                        throw (new InvalidEnumArgumentException("serviceStatus", (int)serviceStatus, typeof(ServiceControllerStatus)));
// ReSharper restore NotResolvedInText
                    }
                }
                service.Refresh();
                serviceStatus = service.Status;
                return serviceStatus;
            }
        }

        public static ServiceControllerStatus
            ResumeLocal(
                string serviceName,
                ulong timeout,
                bool throwTimedOut = true
            ) { return Resume(Environment.MachineName, serviceName, timeout, throwTimedOut); }

        #endregion Resume

        #region Stop

        public static ServiceControllerStatus
            Stop(
                string machineName,
                string serviceName,
                ulong timeout,
                bool throwTimedOut = true
            ) {
            var timespan = TimeSpan.FromMilliseconds(timeout);
            using (var service = (new ServiceController(serviceName, machineName))) {
                service.Refresh();
                var serviceStatus = service.Status;
                switch (serviceStatus) {
                    case ServiceControllerStatus.Stopped: {
                        return serviceStatus;
                    }
                    case ServiceControllerStatus.StopPending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Stopped, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                        }
                        break;
                    }
                    case ServiceControllerStatus.PausePending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Paused, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                            break;
                        }
                        goto case ServiceControllerStatus.Paused;
                    }
                    case ServiceControllerStatus.StartPending:
                    case ServiceControllerStatus.ContinuePending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Running, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                            break;
                        }
                        goto case ServiceControllerStatus.Running;
                    }
                    case ServiceControllerStatus.Paused:
                    case ServiceControllerStatus.Running: {
                        try {
                            service.Stop();
                            service.WaitForStatus(ServiceControllerStatus.Stopped, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                        }
                        break;
                    }
                    default: {
// ReSharper disable NotResolvedInText
                        throw (new InvalidEnumArgumentException("serviceStatus", (int)serviceStatus, typeof(ServiceControllerStatus)));
// ReSharper restore NotResolvedInText
                    }
                }
                service.Refresh();
                serviceStatus = service.Status;
                return serviceStatus;
            }
        }

        public static ServiceControllerStatus
            StopLocal(
                string serviceName,
                ulong timeout,
                bool throwTimedOut = true
            ) { return Stop(Environment.MachineName, serviceName, timeout, throwTimedOut); }

        #endregion Stop

        #region Restart

        public static ServiceControllerStatus
            Restart(
                string machineName,
                string serviceName,
                ulong timeout,
                bool throwTimedOut = true,
                params string[] args
            ) {
            var timespan = TimeSpan.FromMilliseconds(timeout);
            using (var service = (new ServiceController(serviceName, machineName))) {
                service.Refresh();
                var serviceStatus = service.Status;
                switch (serviceStatus) {
                    case ServiceControllerStatus.Paused:
                    case ServiceControllerStatus.Running: {
                        try {
                            service.Stop();
                            service.WaitForStatus(ServiceControllerStatus.Stopped, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                            break;
                        }
                        goto case ServiceControllerStatus.Stopped;
                    }
                    case ServiceControllerStatus.StartPending:
                    case ServiceControllerStatus.ContinuePending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Running, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                            break;
                        }
                        goto case ServiceControllerStatus.Running;
                    }
                    case ServiceControllerStatus.PausePending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Paused, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                            break;
                        }
                        goto case ServiceControllerStatus.Paused;
                    }
                    case ServiceControllerStatus.StopPending: {
                        try {
                            service.WaitForStatus(ServiceControllerStatus.Stopped, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                            break;
                        }
                        goto case ServiceControllerStatus.Stopped;
                    }
                    case ServiceControllerStatus.Stopped: {
                        try {
                            service.Start(args);
                            service.WaitForStatus(ServiceControllerStatus.Running, timeout: timespan);
                        } catch (System.ServiceProcess.TimeoutException) {
                            if (throwTimedOut) {
                                throw;
                            }
                        }
                        service.Refresh();
                        return service.Status;
                    }
                    default: {
// ReSharper disable NotResolvedInText
                        throw (new InvalidEnumArgumentException("serviceStatus", (int)serviceStatus, typeof(ServiceControllerStatus)));
// ReSharper restore NotResolvedInText
                    }
                }
                service.Refresh();
                serviceStatus = service.Status;
                return serviceStatus;
            }
        }

        public static ServiceControllerStatus
            RestartLocal(
                string serviceName,
                ulong timeout,
                bool throwTimedOut = true,
                params string[] args
            ) { return Restart(Environment.MachineName, serviceName, timeout, throwTimedOut, args); }

        #endregion Restart
    }
}