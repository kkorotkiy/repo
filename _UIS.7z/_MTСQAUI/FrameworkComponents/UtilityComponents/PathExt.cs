﻿using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;


namespace UtilityComponents
{
    public static class PathExt
    {
        #region Extension

        public static string AddExtension(string path, string extension)
        {
            if (string.IsNullOrWhiteSpace(extension)) {
                return path;
            }
            var pathEndsWithDot = (!string.IsNullOrWhiteSpace(path) && path.EndsWith("."));
            var extensionStartsWithDot = extension.StartsWith(".");
            if (pathEndsWithDot) {
                if (extensionStartsWithDot) {
                    extension = extension.Substring(1);
                }
            } else if (!extensionStartsWithDot) {
                extension = ("." + extension);
            }
            path += extension;
            return path;
        }

        #endregion Extension

        #region Normalize

        public static string
            Normalize(
                string path,
                IEnumerable<char> invalidChars,
                string replacement = "_",
                RegexOptions options = default(RegexOptions)
            ) {
            var pattern = ("["+string.Join(",", invalidChars)+"]+?");
            path = Regex.Replace(path, pattern, replacement, options);
            return path;
        }

        public static string
            Normalize(
                string path,
                string replacement = "_",
                RegexOptions options = default(RegexOptions)
            ) { return Normalize(path, Path.GetInvalidPathChars(), replacement, options); }

        public static string
            NormalizeFileName(
                string path,
                string replacement = "_",
                RegexOptions options = default(RegexOptions)
            ) { return Normalize(path, Path.GetInvalidFileNameChars(), replacement, options); }

        #endregion Normalize

        #region Exists

        public static bool
            WaitFileExists(
                string path,
                bool exists = true,
                int timeout = 60000
            ) {
            var elapsedTime = 0;
            do {
                var actualExists = File.Exists(path);
                if (actualExists == exists) {
                    return true;
                }
                Thread.Sleep(100);
                elapsedTime += 100;
            }
            while (elapsedTime < timeout);
            return false;
        }

        public static bool
            WaitDirectoryExists(
                string path,
                bool exists = true,
                int timeout = 60000
            ) {
            var elapsedTime = 0;
            do {
                var actualExists = Directory.Exists(path);
                if (actualExists == exists) {
                    return true;
                }
                Thread.Sleep(100);
                elapsedTime += 100;
            }
            while (elapsedTime < timeout);
            return false;
        }

        #endregion Exists
    }
}
