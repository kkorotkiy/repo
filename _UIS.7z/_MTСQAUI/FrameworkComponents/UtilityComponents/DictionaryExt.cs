﻿using System.Linq;
using System.Collections.Generic;


namespace UtilityComponents
{
    public static class DictionaryExt
    {
        public static TValue
            Get<TKey,
                TValue>(
                this Dictionary<TKey[], TValue> dictionary,
                TKey key
            ) {
            foreach (var item in dictionary) {
                var keyArray = item.Key;
                if (keyArray.Contains(key)) {
                    return item.Value;
                }
            }
            throw (new KeyNotFoundException());
        }

        public static void
            Set<TKey,
                TValue>(
                this Dictionary<TKey, TValue> dictionary,
                TKey key,
                TValue value
            ) {
            if (dictionary.ContainsKey(key)) {
                dictionary[key] = value;
            } else {
                dictionary.Add(key, value);
            }
        }
    }
}
