﻿using System.Xml.Linq;


namespace UtilityComponents
{
    public static class XmlExt
    {
        #region XElement

        public static TOut
            GetAttributeValue<
                TOut>(
                this XElement xElement,
                XName xName
            ) { return Cast.As<TOut>(GetAttributeValue(xElement, xName)); }

        public static string GetAttributeValue(this XElement xElement, XName xName)
        {
            var xAttribute = xElement.Attribute(xName);
            var attributeValue = ((xAttribute != null) ? xAttribute.Value : default(string));
            return attributeValue;
        }


        public static void SetValue(this XElement xElement, object value, bool cdata)
        {
            xElement.SetValue(value);
            if (!cdata) {
                return;
            }
            var xElementValue = xElement.Value;
            if (string.IsNullOrWhiteSpace(xElementValue)) {
                return;
            }
            var xCData = (new XCData(xElementValue));
            xElement.ReplaceNodes(xCData);
        }

        #endregion XElement
    }
}
