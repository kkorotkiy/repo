﻿

namespace UtilityComponents.Native
{
    public static class WindowMessages {
        public const uint _SETFOCUS = 0x0007;
        public const uint _SETTEXT = 0x000C;

        public const uint _CLOSE = 0x0010;

        public const uint _KEYDOWN = 0x0100;
        public const uint _KEYUP = 0x0101;

        public const uint _SYSKEYDOWN = 0x0104;
        public const uint _SYSKEYUP = 0x0105;

        public const uint _NCACTIVATE = 0x0086;
    }


    public static class ButtonMessages {
        public const uint _CLICK = 0x00F5;
    }


    public static class MOUSEEVENTF {
        public const uint _ABSOLUTE = 0x8000;
        public const uint _LEFTDOWN = 0x0002;
        public const uint _LEFTUP = 0x0004;
        public const uint _MIDDLEDOWN = 0x0020;
        public const uint _MIDDLEUP = 0x0040;
        public const uint _MOVE = 0x0001;
        public const uint _RIGHTDOWN = 0x0008;
        public const uint _RIGHTUP = 0x0010;
        public const uint _WHEEL = 0x0800;
        public const uint _XDOWN = 0x0080;
        public const uint _XUP = 0x0100;
        public const uint _HWHEEL = 0x01000;
    }
}
