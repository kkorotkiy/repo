﻿using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using WM = UtilityComponents.Native.WindowMessages;
using BM = UtilityComponents.Native.ButtonMessages;


namespace UtilityComponents.Native
{
    public static class User32
    {
        #region Constants

        /// <summary>
        /// Function [LRESULT WINAPI SendMessageTimeout] parameter[_In_  UINT fuFlags] possible values.
        /// </summary>
        public static class fuFlags_Param {
            public const uint _NORMAL = 0x0000;
            public const uint _BLOCK = 0x0001;
            public const uint _ABORTIFHUNG = 0x0002;
            public const uint _NOTIMEOUTIFNOTHUNG = 0x0008;
            public const uint _ERRORONEXIT = 0x0020;
        }

        /// <summary>
        /// Function [HWND WINAPI GetWindow] parameter[_In_  UINT uCmd] possible values.
        /// </summary>
        public static class uCmd_Param {
            public const uint _HWNDFIRST = 0;
            public const uint _HWNDLAST = 1;
            public const uint _HWNDNEXT = 2;
            public const uint _HWNDPREV = 3;
            public const uint _OWNER = 4;
            public const uint _CHILD = 5;
            public const uint _ENABLEDPOPUP = 6;
        }

        /// <summary>
        /// Function [VOID WINAPI mouse_event] parameter[_In_  DWORD dwData] possible values.
        /// </summary>
        public static class dwData_Param {
            public const uint XBUTTON1 = 0x0001;
            public const uint XBUTTON2 = 0x0002;
        }


        [StructLayout(LayoutKind.Sequential)]
        public struct RECT {
            public int X;
            public int Y;
            public int Width;
            public int Height;
        }

        #endregion Constants

        #region Find Window

/*      HWND WINAPI FindWindow(
            _In_opt_  LPCTSTR lpClassName,
            _In_opt_  LPCTSTR lpWindowName
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr
            FindWindow(
                string lpClassName,
                string lpWindowName
            );

/*      HWND WINAPI FindWindowEx(
            _In_opt_  HWND hwndParent,
            _In_opt_  HWND hwndChildAfter,
            _In_opt_  LPCTSTR lpszClass,
            _In_opt_  LPCTSTR lpszWindow
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr
            FindWindowEx(
                IntPtr hwndParent,
                IntPtr hwndChildAfter,
                string lpszClass,
                string lpszWindow
            );

        public static IntPtr
            WaitWindow(
                string lpClassName,
                string lpWindowName,
                int timeout,
                int delay = 100
            ) {
            IntPtr hWnd;
            double waittime;
            var now = DateTime.Now;
            do {
                Thread.Sleep(delay);
                hWnd = FindWindow(lpClassName, lpWindowName);
                if (hWnd != IntPtr.Zero) {
                    break;
                }
                waittime = (DateTime.Now - now).TotalMilliseconds;
            } while (waittime < timeout);
            return hWnd;
        }

        #endregion Find Window

        #region Get Window

/*      HWND WINAPI GetNextWindow(
            _In_  HWND hWnd,
            _In_  UINT wCmd
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr
            GetWindow(
                IntPtr hWnd,
                uint wCmd
            );

/*      int WINAPI GetWindowText(
            _In_   HWND hWnd,
            _Out_  LPTSTR lpString,
            _In_   int nMaxCount
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern int
            GetWindowText(
                IntPtr hWnd,
                StringBuilder lpString,
                int nMaxCount
            );

/*      BOOL WINAPI GetWindowRect(
            _In_   HWND hWnd,
            _Out_  LPRECT lpRect
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool
            GetWindowRect(
                IntPtr hWnd,
                out RECT Rect
            );

        #endregion Get Window

        #region Activate Window

/*      HWND WINAPI GetActiveWindow(void);*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr
            GetActiveWindow(
            );

/*      HWND WINAPI GetForegroundWindow(void);*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr
            GetForegroundWindow(
            );


/*      HWND WINAPI SetActiveWindow(
            _In_  HWND hWnd
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr
            SetActiveWindow(
                IntPtr hWnd
            );

/*      BOOL WINAPI SetForegroundWindow(
            _In_  HWND hWnd
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool
            SetForegroundWindow(
                IntPtr hWnd
            );

        public static bool
            IsForegroundWindow(
                IntPtr hWnd
            ) { return (GetForegroundWindow() == hWnd); }

        #endregion Activate Window

        #region Enable Window

/*      BOOL WINAPI EnableWindow(
            _In_  HWND hWnd,
            _In_  BOOL bEnable
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern IntPtr
            EnableWindow(
                IntPtr hWnd,
                bool bEnable
            );

        #endregion Enable Window

        #region SendMessage

/*      LRESULT WINAPI SendMessage(
            _In_  HWND hWnd,
            _In_  UINT Msg,
            _In_  WPARAM wParam,
            _In_  LPARAM lParam
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern long
            SendMessage(
                IntPtr hWnd,
                uint Msg,
                uint wParam,
                StringBuilder lParam
            );

/*      LRESULT WINAPI SendMessageTimeout(
            _In_       HWND hWnd,
            _In_       UINT Msg,
            _In_       WPARAM wParam,
            _In_       LPARAM lParam,
            _In_       UINT fuFlags,
            _In_       UINT uTimeout,
            _Out_opt_  PDWORD_PTR lpdwResult
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern long
            SendMessageTimeout(
                IntPtr hWnd,
                uint Msg,
                uint wParam,
                StringBuilder lParam,
                uint fuFlags,
                uint uTimeout,
                out uint lpdwResult
            );

        #endregion SendMessage

        #region SendKeys

        public static void
            SendKeys(
                int ProcessId,
                string keys,
                bool wait = true
            ) {
            Microsoft.VisualBasic.Interaction.AppActivate(ProcessId);
            SendKeys(keys, wait);
        }

        public static void
            SendKeys(
                IntPtr hWnd,
                string keys,
                bool wait = true
            ) {
            SetForegroundWindow(hWnd);
            SendKeys(keys, wait);
        }

        public static void
            SendKeys(
                string keys,
                bool wait = true
            ) {
            if (wait) {
                System.Windows.Forms.SendKeys.SendWait(keys);
            } else {
                System.Windows.Forms.SendKeys.Send(keys);
            }
        }

        #endregion

        #region mouse_event

/*      VOID WINAPI mouse_event(
            _In_  DWORD dwFlags,
            _In_  DWORD dx,
            _In_  DWORD dy,
            _In_  DWORD dwData,
            _In_  ULONG_PTR dwExtraInfo
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern void
            mouse_event(
                uint dwFlags,
                uint dx,
                uint dy,
                uint dwData,
                UIntPtr dwExtraInfo
            );

        public static void
            MoveTo(
                Point position
            ) { Cursor.Position = position; }

        public static bool
            IsMouseOver(
                Rectangle rect
            ) {
            var topX = rect.X;
            var topY = rect.Y;
            var bottomX = (rect.X + rect.Width);
            var bottomY = (rect.Y + rect.Height);
            var cursorPosition = Cursor.Position;
            var isMouseOver =
                ((topX < cursorPosition.X)
                 && (cursorPosition.X < bottomX)
                 && (topY < cursorPosition.Y)
                 && (cursorPosition.Y < bottomY)
                );
            return isMouseOver;
        }

        #endregion mouse_event

        #region Click

        public static void
            Click(
                Point point,
                MouseButtons button = MouseButtons.Left,
                bool doubleClick = false
            ) {
            // TODO-BEGIN: REMOVE THIS HACK
            Cursor.Position = point;
            uint dx = 0, dy = 0;
            // TODO-END: REMOVE THIS HACK
            var dwFlags = MOUSEEVENTF._ABSOLUTE;
            var dwData = uint.MinValue;
            switch (button) {
                case MouseButtons.Left: {
                    dwFlags |= (MOUSEEVENTF._LEFTDOWN|MOUSEEVENTF._LEFTUP);
                    break;
                }
                case MouseButtons.Middle: {
                    dwFlags |= (MOUSEEVENTF._MIDDLEDOWN|MOUSEEVENTF._MIDDLEUP);
                    break;
                }
                case MouseButtons.Right: {
                    dwFlags |= (MOUSEEVENTF._RIGHTDOWN|MOUSEEVENTF._RIGHTUP);
                    break;
                }
                case MouseButtons.XButton1: {
                    dwFlags |= (MOUSEEVENTF._XDOWN|MOUSEEVENTF._XUP);
                    dwData = dwData_Param.XBUTTON1;
                    break;
                }
                case MouseButtons.XButton2: {
                    dwFlags |= (MOUSEEVENTF._XDOWN|MOUSEEVENTF._XUP);
                    dwData = dwData_Param.XBUTTON2;
                    break;
                }
            }
            mouse_event(dwFlags, dx, dy, dwData, UIntPtr.Zero);
            if (doubleClick) {
                mouse_event(dwFlags, dx, dy, dwData, UIntPtr.Zero);
            }
        }

        public static void
            Click(
                int ProcessId,
                Point point,
                MouseButtons button = MouseButtons.Left,
                bool doubleClick = false
            ) {
            Microsoft.VisualBasic.Interaction.AppActivate(ProcessId);
            Click(point, button, doubleClick);
        }

        public static void
            Click(
                IntPtr hWnd,
                Point point,
                MouseButtons button = MouseButtons.Left,
                bool doubleClick = false
            ) {
            SetForegroundWindow(hWnd);
            Click(point, button, doubleClick);
        }

        public static void
            Click(
                IntPtr hWnd
            ) {
            SendMessage(hWnd, WM._SETFOCUS, 0, null);
            Thread.Sleep(256);
            SendMessage(hWnd, BM._CLICK, 0, null);
        }

        public static void
            ClickTimeout(
                IntPtr hWnd,
                uint fuFlags,
                uint uTimeout
            ) {
            uint lpdwResult;
            SendMessageTimeout(hWnd, WM._SETFOCUS, 0, null, fuFlags, uTimeout, out lpdwResult);
            Thread.Sleep(256);
            SendMessageTimeout(hWnd, BM._CLICK, 0, null, fuFlags, uTimeout, out lpdwResult);
        }

        #endregion Click

        #region Close Window

/*      BOOL WINAPI CloseWindow(
            _In_  HWND hWnd
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool
            CloseWindow(
                IntPtr hWnd
            );

/*      BOOL WINAPI DestroyWindow(
            _In_  HWND hWnd
        );*/
        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool
            DestroyWindow(
                IntPtr hWnd
            );

        #endregion Close Window
    }
}
