﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;


namespace UtilityComponents
{
    public static class ProcessExt
    {
        #region FormatArguments

        public static string
            FormatArguments<
                TArgument>(
                params TArgument[] args
            ) {
            var argsBuilder = (new StringBuilder());
            foreach (var arg in args) {
                var argStr = Convert.ToString(arg);
                if (string.IsNullOrWhiteSpace(argStr)) {
                    continue;
                }
                if (argStr.Any(c => (char.IsSeparator(c) || char.IsWhiteSpace(c)))) {
                    argStr = ('"'+argStr+'"');
                }
                argStr += ' ';
                argsBuilder.Append(argStr);
            }
            var argsStrLength = (argsBuilder.Length - 1);
            var argsStr = argsBuilder.ToString(0, argsStrLength);
            return argsStr;
        }

        public static string
            FormatArguments(
                params object[] args
            ) { return FormatArguments<object>(args); }

        #endregion FormatArguments

        #region Start

        public static void Start(ProcessStartInfo startInfo) {
            using (var process = (new Process {StartInfo = startInfo})) { process.Start(); }
        }

        public static void
            Start(
                string fileName,
                string arguments,
                bool noWindow = false
            ) {
            var startInfo =
                (new ProcessStartInfo {
                    FileName = fileName,
                    Arguments = arguments,
                    CreateNoWindow = noWindow
                });
            Start(startInfo);
        }

        public static void
            Start<
                TArgument>(
                string fileName,
                TArgument[] args,
                bool noWindow = false
            ) { Start(fileName, FormatArguments(args), noWindow); }

        #endregion Start

        #region StartAndWaitForExit

        public static int?
            StartAndWaitForExit(
                ProcessStartInfo startInfo,
                int timeout
            ) {
            using (var process = (new Process {StartInfo = startInfo})) {
                process.Start();
                process.WaitForExit(timeout);
                process.Refresh();
                if (!process.HasExited) {
                    return null;
                }
                return process.ExitCode;
            }            
        }

        public static int?
            StartAndWaitForExit(
                string fileName,
                string arguments,
                int timeout,
                bool noWindow = false
            ) {
            var startInfo = 
                (new ProcessStartInfo {
                    FileName = fileName,
                    Arguments = arguments,
                    CreateNoWindow = noWindow
                });
            return StartAndWaitForExit(startInfo, timeout);
        }

        public static int?
            StartAndWaitForExit<
                TArgument>(
                string fileName,
                TArgument[] args,
                int timeout,
                bool noWindow = false
            ) { return StartAndWaitForExit(fileName, FormatArguments(args), timeout, noWindow); }

        #endregion StartAndWaitForExit

        #region Kill

        private const int KillTimeout = 60000;

        public static void Kill(params Process[] processes) {
            foreach (var process in processes) { Kill(process, KillTimeout); }
        }

        public static int? Kill(Process process, int timeout)
        {
            process.Refresh();
            if (!process.HasExited) {
                process.Kill();
                process.WaitForExit(timeout);
                process.Refresh();
                if (!process.HasExited) {
                    return null;
                }
            }
            return process.ExitCode;
        }

        #endregion Kill

        #region Get

        public static Process[]
            GetProcesses(
                string name,
                IEnumerable<Process> exceptList
            ) {
            var allProcesses = Process.GetProcessesByName(name);
            var exceptIds = exceptList.Select(proc => proc.Id);
            var filteredIds = allProcesses.Select(proc => proc.Id).Except(exceptIds);
            var processes = allProcesses.Where(proc => filteredIds.Contains(proc.Id)).ToArray();
            return processes;
        }

        public static Process
            GetSingleProcessWithMainWindowTitle(
                string name,
                IEnumerable<Process> exceptList
            ) {
            var processes = GetProcesses(name, exceptList);
            var process = processes.Single(proc => !string.IsNullOrWhiteSpace(proc.MainWindowTitle));
            return process;
        }

        #endregion Get
    }
}
