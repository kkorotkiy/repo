﻿using System;
using System.Collections;
using System.Collections.Generic;


namespace UtilityComponents
{
    public static class Cast
    {
        public static TOut As<TOut>(object value)
        {
            object castedValue;
            Type outType = typeof(TOut);
            Type underlyingType;
            bool isNullable;
            var isEnum = IsEnum(outType, out underlyingType, out isNullable);
            if (isEnum) {
                castedValue = AsEnum(underlyingType, value, isNullable);
            } else if (isNullable) {
                try {
                    castedValue = Convert.ChangeType(value, underlyingType);
                } catch {
                    castedValue = null;
                }
            } else {
                castedValue = Convert.ChangeType(value, outType);
            }
            return ((TOut) castedValue);
        }

        #region Enum

        public static bool
            IsEnum<
                T>(
                out Type underlyingType,
                out bool isNullable
            ) { return IsEnum(typeof(T), out underlyingType, out isNullable); }

        public static bool
            IsEnum(
                this Type type,
                out Type underlyingType,
                out bool isNullable
            ) {
            bool isEnum;
            if (type.IsEnum) {
                underlyingType = type;
                isEnum = true;
                isNullable = false;
            } else {
                isNullable = IsNullable(type, out underlyingType);
                isEnum = (isNullable && underlyingType.IsEnum);
            }
            return isEnum;
        }

        public static TEnum AsEnum<TEnum>(object value)
        {
            bool isNullable;
            Type enumType;
            if (!IsEnum<TEnum>(out enumType, out isNullable)) {
// ReSharper disable NotResolvedInText
                throw (new ArgumentException("Type provided must be an Enum.", "TEnum"));
// ReSharper restore NotResolvedInText
            }
            var enumValue = AsEnum(enumType, value, isNullable);
            return ((TEnum) enumValue);
        }

        private static object
            AsEnum(
                Type enumType,
                object value,
                bool isNullable
            ) {
            object enumValue;
            try {
                var strValue = (value as string);
                if (strValue != null) {
                    enumValue = Enum.Parse(enumType, strValue, ignoreCase: true);
                } else {
                    enumValue = Enum.ToObject(enumType, value);
                }
            } catch {
                if (isNullable) {
                    enumValue = null;
                } else {
                    throw;
                }
            }
            return enumValue;
        }

        #endregion Enum

        #region Nullable

        public static bool IsNullable<T>() { return IsNullable(typeof(T)); }

        public static bool IsNullable<T>(out Type underlyingType) { return IsNullable(typeof(T), out underlyingType); }

        public static bool IsNullable(this Type type)
        {
            Type underlyingType;
            return IsNullable(type, out underlyingType);
        }

        public static bool IsNullable(this Type type, out Type underlyingType)
        {
            underlyingType = Nullable.GetUnderlyingType(type);
            var isNullable = !ReferenceEquals(underlyingType, null);
            return isNullable;
        }

        #endregion Nullable

        #region Boolean

        public static bool IsTrue(this bool? @value) { return (@value.HasValue && @value.Value); }

        public static bool IsFalse(this bool? @value) { return (@value.HasValue && !@value.Value); }

        public static bool AsBool(this bool? @value) { return IsTrue(@value); }

        public static string AsString(this bool? @value, string @true, string @false) { return (IsTrue(@value) ? @true : @false); }

        public static string AsString(this bool @value, string @true, string @false) { return (@value ? @true : @false); }

        #endregion Boolean

        #region Array

        public static bool IsArray(this Type type, out Type elementType)
        {
            var isArray = type.IsArray;
            elementType = (isArray ? type.GetElementType() : null);
            return isArray;
        }

        public static TOut[] AsArray<TOut>(object obj, bool emptyOnNull = false)
        {
            TOut[] array;
            if (ReferenceEquals(obj, null)) {
                array = (emptyOnNull ? (new TOut[0]) : null);
            } else {
                var objType = obj.GetType();
                Type elementType;
                if (IsArray(objType, out elementType)) {
                    if (elementType.IsValueType) {
                        var objArray = ((Array) obj);
                        var length = objArray.Length;
                        array = (new TOut[length]);
                        Array.Copy(objArray, array, length);
                    } else {
                        array = ((TOut[]) obj);
                    }
                } else {
                    array = (new[] {As<TOut>(obj)});
                }
            }
            return array;
        }

        #endregion Array

        #region Enumerable

        public static bool IsEnumerable<T>(out Type elementType) { return IsEnumerable(typeof(T), out elementType); }

        public static bool IsEnumerable(this Type type, out Type elementType)
        {
            bool isEnumerable;
            if (type.IsArray) {
                elementType = type.GetElementType();
                isEnumerable = true;
            } else {
                var genericIEnumerableTypeDef = typeof(IEnumerable<>);
                var genericIEnumerableType = type.GetInterface(genericIEnumerableTypeDef.FullName);
                if (genericIEnumerableType != null) {
                    elementType = genericIEnumerableType.GetGenericArguments()[0];
                    isEnumerable = true;
                } else {
                    var iEnumerableTypeDef = typeof(IEnumerable);
                    var iEnumerableType = type.GetInterface(iEnumerableTypeDef.FullName);
                    if (iEnumerableType != null) {
                        elementType = typeof(object);
                        isEnumerable = true;
                    } else {
                        elementType = null;
                        isEnumerable = false;
                    }
                }
            }
            return isEnumerable;
        }

        #endregion Enumerable
    }
}