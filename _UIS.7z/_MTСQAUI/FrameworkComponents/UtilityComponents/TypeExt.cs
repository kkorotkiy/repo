﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;


namespace UtilityComponents
{
    public static class TypeExt
    {
        public static IEnumerable<TAttribute>
            GetCustomAttributes<
                TAttribute>(
                this Type type,
                bool inherit = true
            ) where TAttribute : Attribute {
            var attributeType = typeof(TAttribute);
            var typeCustomAttrs = type.GetCustomAttributes(attributeType, inherit);
            var attrs = typeCustomAttrs.Cast<TAttribute>();
            return attrs;
        }


        public static IEnumerable<TAttribute>
            GetCustomAttributes<
                TAttribute>(
                this MemberInfo memberInfo,
                bool inherit = true
            ) where TAttribute : Attribute {
            var attributeType = typeof(TAttribute);
            var memberCustomAttrs = memberInfo.GetCustomAttributes(attributeType, inherit);
            var attrs = memberCustomAttrs.Cast<TAttribute>();
            return attrs;
        }
    }
}
